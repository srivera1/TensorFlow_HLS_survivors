// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2019.2.1 (64-bit)
// Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef XNN_MODEL_TOP_H
#define XNN_MODEL_TOP_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xnn_model_top_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
#else
typedef struct {
    u16 DeviceId;
    u32 Control_BaseAddress;
} XNn_model_top_Config;
#endif

typedef struct {
    u32 Control_BaseAddress;
    u32 IsReady;
} XNn_model_top;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XNn_model_top_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XNn_model_top_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XNn_model_top_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XNn_model_top_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
int XNn_model_top_Initialize(XNn_model_top *InstancePtr, u16 DeviceId);
XNn_model_top_Config* XNn_model_top_LookupConfig(u16 DeviceId);
int XNn_model_top_CfgInitialize(XNn_model_top *InstancePtr, XNn_model_top_Config *ConfigPtr);
#else
int XNn_model_top_Initialize(XNn_model_top *InstancePtr, const char* InstanceName);
int XNn_model_top_Release(XNn_model_top *InstancePtr);
#endif

void XNn_model_top_Start(XNn_model_top *InstancePtr);
u32 XNn_model_top_IsDone(XNn_model_top *InstancePtr);
u32 XNn_model_top_IsIdle(XNn_model_top *InstancePtr);
u32 XNn_model_top_IsReady(XNn_model_top *InstancePtr);
void XNn_model_top_EnableAutoRestart(XNn_model_top *InstancePtr);
void XNn_model_top_DisableAutoRestart(XNn_model_top *InstancePtr);
u32 XNn_model_top_Get_return(XNn_model_top *InstancePtr);

void XNn_model_top_Set_Input_input(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Input_input(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2508_conv2d_2508(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2508_conv2d_2508(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_1745_max_pooling2d_1745(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_1745_max_pooling2d_1745(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1969_dense_1969(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1969_dense_1969(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2509_conv2d_2509(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2509_conv2d_2509(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_1746_max_pooling2d_1746(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_1746_max_pooling2d_1746(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1970_dense_1970(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1970_dense_1970(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2510_conv2d_2510(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2510_conv2d_2510(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_1747_max_pooling2d_1747(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_1747_max_pooling2d_1747(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1971_dense_1971(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1971_dense_1971(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_1748_max_pooling2d_1748(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_1748_max_pooling2d_1748(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1972_dense_1972(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1972_dense_1972(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1973_dense_1973(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1973_dense_1973(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1974_dense_1974(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1974_dense_1974(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1975_dense_1975(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1975_dense_1975(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1976_dense_1976(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1976_dense_1976(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1977_dense_1977(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1977_dense_1977(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1978_dense_1978(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1978_dense_1978(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1979_dense_1979(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1979_dense_1979(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Flatten_122_flatten_122(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Flatten_122_flatten_122(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1980_dense_1980(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1980_dense_1980(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1981_dense_1981(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1981_dense_1981(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2508_weight_conv2d_2508_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2508_weight_conv2d_2508_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2508_bias_conv2d_2508_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2508_bias_conv2d_2508_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1969_weight_dense_1969_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1969_weight_dense_1969_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1969_bias_dense_1969_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1969_bias_dense_1969_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2509_weight_conv2d_2509_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2509_weight_conv2d_2509_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2509_bias_conv2d_2509_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2509_bias_conv2d_2509_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1970_weight_dense_1970_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1970_weight_dense_1970_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1970_bias_dense_1970_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1970_bias_dense_1970_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2510_weight_conv2d_2510_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2510_weight_conv2d_2510_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2510_bias_conv2d_2510_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2510_bias_conv2d_2510_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1971_weight_dense_1971_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1971_weight_dense_1971_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1971_bias_dense_1971_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1971_bias_dense_1971_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1972_weight_dense_1972_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1972_weight_dense_1972_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1972_bias_dense_1972_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1972_bias_dense_1972_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1973_weight_dense_1973_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1973_weight_dense_1973_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1973_bias_dense_1973_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1973_bias_dense_1973_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1974_weight_dense_1974_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1974_weight_dense_1974_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1974_bias_dense_1974_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1974_bias_dense_1974_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1975_weight_dense_1975_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1975_weight_dense_1975_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1975_bias_dense_1975_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1975_bias_dense_1975_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1976_weight_dense_1976_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1976_weight_dense_1976_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1976_bias_dense_1976_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1976_bias_dense_1976_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1977_weight_dense_1977_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1977_weight_dense_1977_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1977_bias_dense_1977_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1977_bias_dense_1977_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1978_weight_dense_1978_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1978_weight_dense_1978_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1978_bias_dense_1978_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1978_bias_dense_1978_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1979_weight_dense_1979_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1979_weight_dense_1979_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1979_bias_dense_1979_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1979_bias_dense_1979_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1980_weight_dense_1980_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1980_weight_dense_1980_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1980_bias_dense_1980_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1980_bias_dense_1980_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1981_weight_dense_1981_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1981_weight_dense_1981_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1981_bias_dense_1981_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1981_bias_dense_1981_bias(XNn_model_top *InstancePtr);

void XNn_model_top_InterruptGlobalEnable(XNn_model_top *InstancePtr);
void XNn_model_top_InterruptGlobalDisable(XNn_model_top *InstancePtr);
void XNn_model_top_InterruptEnable(XNn_model_top *InstancePtr, u32 Mask);
void XNn_model_top_InterruptDisable(XNn_model_top *InstancePtr, u32 Mask);
void XNn_model_top_InterruptClear(XNn_model_top *InstancePtr, u32 Mask);
u32 XNn_model_top_InterruptGetEnabled(XNn_model_top *InstancePtr);
u32 XNn_model_top_InterruptGetStatus(XNn_model_top *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
