// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2019.2.1 (64-bit)
// Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
// ==============================================================
/***************************** Include Files *********************************/
#include "xnn_model_top.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XNn_model_top_CfgInitialize(XNn_model_top *InstancePtr, XNn_model_top_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XNn_model_top_Start(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_AP_CTRL) & 0x80;
    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XNn_model_top_IsDone(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XNn_model_top_IsIdle(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XNn_model_top_IsReady(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XNn_model_top_EnableAutoRestart(XNn_model_top *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XNn_model_top_DisableAutoRestart(XNn_model_top *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_AP_CTRL, 0);
}

u32 XNn_model_top_Get_return(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_AP_RETURN);
    return Data;
}
void XNn_model_top_Set_Input1_input1(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_INPUT1_INPUT1_DATA, Data);
}

u32 XNn_model_top_Get_Input1_input1(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_INPUT1_INPUT1_DATA);
    return Data;
}

void XNn_model_top_Set_Input2_input2(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_INPUT2_INPUT2_DATA, Data);
}

u32 XNn_model_top_Get_Input2_input2(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_INPUT2_INPUT2_DATA);
    return Data;
}

void XNn_model_top_Set_Conv2d_4054_conv2d_4054(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_4054_CONV2D_4054_DATA, Data);
}

u32 XNn_model_top_Get_Conv2d_4054_conv2d_4054(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_4054_CONV2D_4054_DATA);
    return Data;
}

void XNn_model_top_Set_Conv2d_4056_conv2d_4056(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_4056_CONV2D_4056_DATA, Data);
}

u32 XNn_model_top_Get_Conv2d_4056_conv2d_4056(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_4056_CONV2D_4056_DATA);
    return Data;
}

void XNn_model_top_Set_Max_pooling2d_3433_max_pooling2d_3433(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_MAX_POOLING2D_3433_MAX_POOLING2D_3433_DATA, Data);
}

u32 XNn_model_top_Get_Max_pooling2d_3433_max_pooling2d_3433(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_MAX_POOLING2D_3433_MAX_POOLING2D_3433_DATA);
    return Data;
}

void XNn_model_top_Set_Max_pooling2d_3434_max_pooling2d_3434(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_MAX_POOLING2D_3434_MAX_POOLING2D_3434_DATA, Data);
}

u32 XNn_model_top_Get_Max_pooling2d_3434_max_pooling2d_3434(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_MAX_POOLING2D_3434_MAX_POOLING2D_3434_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_3281_dense_3281(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_3281_DENSE_3281_DATA, Data);
}

u32 XNn_model_top_Get_Dense_3281_dense_3281(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_3281_DENSE_3281_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_3282_dense_3282(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_3282_DENSE_3282_DATA, Data);
}

u32 XNn_model_top_Get_Dense_3282_dense_3282(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_3282_DENSE_3282_DATA);
    return Data;
}

void XNn_model_top_Set_Conv2d_4055_conv2d_4055(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_4055_CONV2D_4055_DATA, Data);
}

u32 XNn_model_top_Get_Conv2d_4055_conv2d_4055(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_4055_CONV2D_4055_DATA);
    return Data;
}

void XNn_model_top_Set_Conv2d_4057_conv2d_4057(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_4057_CONV2D_4057_DATA, Data);
}

u32 XNn_model_top_Get_Conv2d_4057_conv2d_4057(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_4057_CONV2D_4057_DATA);
    return Data;
}

void XNn_model_top_Set_Concatenate_707_concatenate_707(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONCATENATE_707_CONCATENATE_707_DATA, Data);
}

u32 XNn_model_top_Get_Concatenate_707_concatenate_707(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONCATENATE_707_CONCATENATE_707_DATA);
    return Data;
}

void XNn_model_top_Set_Conv2d_4058_conv2d_4058(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_4058_CONV2D_4058_DATA, Data);
}

u32 XNn_model_top_Get_Conv2d_4058_conv2d_4058(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_4058_CONV2D_4058_DATA);
    return Data;
}

void XNn_model_top_Set_Max_pooling2d_3435_max_pooling2d_3435(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_MAX_POOLING2D_3435_MAX_POOLING2D_3435_DATA, Data);
}

u32 XNn_model_top_Get_Max_pooling2d_3435_max_pooling2d_3435(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_MAX_POOLING2D_3435_MAX_POOLING2D_3435_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_3283_dense_3283(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_3283_DENSE_3283_DATA, Data);
}

u32 XNn_model_top_Get_Dense_3283_dense_3283(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_3283_DENSE_3283_DATA);
    return Data;
}

void XNn_model_top_Set_Conv2d_4059_conv2d_4059(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_4059_CONV2D_4059_DATA, Data);
}

u32 XNn_model_top_Get_Conv2d_4059_conv2d_4059(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_4059_CONV2D_4059_DATA);
    return Data;
}

void XNn_model_top_Set_Max_pooling2d_3436_max_pooling2d_3436(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_MAX_POOLING2D_3436_MAX_POOLING2D_3436_DATA, Data);
}

u32 XNn_model_top_Get_Max_pooling2d_3436_max_pooling2d_3436(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_MAX_POOLING2D_3436_MAX_POOLING2D_3436_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_3284_dense_3284(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_3284_DENSE_3284_DATA, Data);
}

u32 XNn_model_top_Get_Dense_3284_dense_3284(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_3284_DENSE_3284_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_3285_dense_3285(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_3285_DENSE_3285_DATA, Data);
}

u32 XNn_model_top_Get_Dense_3285_dense_3285(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_3285_DENSE_3285_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_3286_dense_3286(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_3286_DENSE_3286_DATA, Data);
}

u32 XNn_model_top_Get_Dense_3286_dense_3286(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_3286_DENSE_3286_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_3287_dense_3287(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_3287_DENSE_3287_DATA, Data);
}

u32 XNn_model_top_Get_Dense_3287_dense_3287(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_3287_DENSE_3287_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_3288_dense_3288(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_3288_DENSE_3288_DATA, Data);
}

u32 XNn_model_top_Get_Dense_3288_dense_3288(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_3288_DENSE_3288_DATA);
    return Data;
}

void XNn_model_top_Set_Flatten_366_flatten_366(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_FLATTEN_366_FLATTEN_366_DATA, Data);
}

u32 XNn_model_top_Get_Flatten_366_flatten_366(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_FLATTEN_366_FLATTEN_366_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_3289_dense_3289(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_3289_DENSE_3289_DATA, Data);
}

u32 XNn_model_top_Get_Dense_3289_dense_3289(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_3289_DENSE_3289_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_3290_dense_3290(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_3290_DENSE_3290_DATA, Data);
}

u32 XNn_model_top_Get_Dense_3290_dense_3290(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_3290_DENSE_3290_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_3291_dense_3291(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_3291_DENSE_3291_DATA, Data);
}

u32 XNn_model_top_Get_Dense_3291_dense_3291(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_3291_DENSE_3291_DATA);
    return Data;
}

void XNn_model_top_Set_Conv2d_4054_weight_conv2d_4054_weight(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_4054_WEIGHT_CONV2D_4054_WEIGHT_DATA, Data);
}

u32 XNn_model_top_Get_Conv2d_4054_weight_conv2d_4054_weight(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_4054_WEIGHT_CONV2D_4054_WEIGHT_DATA);
    return Data;
}

void XNn_model_top_Set_Conv2d_4054_bias_conv2d_4054_bias(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_4054_BIAS_CONV2D_4054_BIAS_DATA, Data);
}

u32 XNn_model_top_Get_Conv2d_4054_bias_conv2d_4054_bias(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_4054_BIAS_CONV2D_4054_BIAS_DATA);
    return Data;
}

void XNn_model_top_Set_Conv2d_4056_weight_conv2d_4056_weight(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_4056_WEIGHT_CONV2D_4056_WEIGHT_DATA, Data);
}

u32 XNn_model_top_Get_Conv2d_4056_weight_conv2d_4056_weight(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_4056_WEIGHT_CONV2D_4056_WEIGHT_DATA);
    return Data;
}

void XNn_model_top_Set_Conv2d_4056_bias_conv2d_4056_bias(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_4056_BIAS_CONV2D_4056_BIAS_DATA, Data);
}

u32 XNn_model_top_Get_Conv2d_4056_bias_conv2d_4056_bias(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_4056_BIAS_CONV2D_4056_BIAS_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_3281_weight_dense_3281_weight(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_3281_WEIGHT_DENSE_3281_WEIGHT_DATA, Data);
}

u32 XNn_model_top_Get_Dense_3281_weight_dense_3281_weight(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_3281_WEIGHT_DENSE_3281_WEIGHT_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_3281_bias_dense_3281_bias(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_3281_BIAS_DENSE_3281_BIAS_DATA, Data);
}

u32 XNn_model_top_Get_Dense_3281_bias_dense_3281_bias(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_3281_BIAS_DENSE_3281_BIAS_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_3282_weight_dense_3282_weight(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_3282_WEIGHT_DENSE_3282_WEIGHT_DATA, Data);
}

u32 XNn_model_top_Get_Dense_3282_weight_dense_3282_weight(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_3282_WEIGHT_DENSE_3282_WEIGHT_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_3282_bias_dense_3282_bias(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_3282_BIAS_DENSE_3282_BIAS_DATA, Data);
}

u32 XNn_model_top_Get_Dense_3282_bias_dense_3282_bias(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_3282_BIAS_DENSE_3282_BIAS_DATA);
    return Data;
}

void XNn_model_top_Set_Conv2d_4055_weight_conv2d_4055_weight(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_4055_WEIGHT_CONV2D_4055_WEIGHT_DATA, Data);
}

u32 XNn_model_top_Get_Conv2d_4055_weight_conv2d_4055_weight(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_4055_WEIGHT_CONV2D_4055_WEIGHT_DATA);
    return Data;
}

void XNn_model_top_Set_Conv2d_4055_bias_conv2d_4055_bias(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_4055_BIAS_CONV2D_4055_BIAS_DATA, Data);
}

u32 XNn_model_top_Get_Conv2d_4055_bias_conv2d_4055_bias(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_4055_BIAS_CONV2D_4055_BIAS_DATA);
    return Data;
}

void XNn_model_top_Set_Conv2d_4057_weight_conv2d_4057_weight(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_4057_WEIGHT_CONV2D_4057_WEIGHT_DATA, Data);
}

u32 XNn_model_top_Get_Conv2d_4057_weight_conv2d_4057_weight(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_4057_WEIGHT_CONV2D_4057_WEIGHT_DATA);
    return Data;
}

void XNn_model_top_Set_Conv2d_4057_bias_conv2d_4057_bias(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_4057_BIAS_CONV2D_4057_BIAS_DATA, Data);
}

u32 XNn_model_top_Get_Conv2d_4057_bias_conv2d_4057_bias(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_4057_BIAS_CONV2D_4057_BIAS_DATA);
    return Data;
}

void XNn_model_top_Set_Conv2d_4058_weight_conv2d_4058_weight(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_4058_WEIGHT_CONV2D_4058_WEIGHT_DATA, Data);
}

u32 XNn_model_top_Get_Conv2d_4058_weight_conv2d_4058_weight(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_4058_WEIGHT_CONV2D_4058_WEIGHT_DATA);
    return Data;
}

void XNn_model_top_Set_Conv2d_4058_bias_conv2d_4058_bias(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_4058_BIAS_CONV2D_4058_BIAS_DATA, Data);
}

u32 XNn_model_top_Get_Conv2d_4058_bias_conv2d_4058_bias(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_4058_BIAS_CONV2D_4058_BIAS_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_3283_weight_dense_3283_weight(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_3283_WEIGHT_DENSE_3283_WEIGHT_DATA, Data);
}

u32 XNn_model_top_Get_Dense_3283_weight_dense_3283_weight(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_3283_WEIGHT_DENSE_3283_WEIGHT_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_3283_bias_dense_3283_bias(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_3283_BIAS_DENSE_3283_BIAS_DATA, Data);
}

u32 XNn_model_top_Get_Dense_3283_bias_dense_3283_bias(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_3283_BIAS_DENSE_3283_BIAS_DATA);
    return Data;
}

void XNn_model_top_Set_Conv2d_4059_weight_conv2d_4059_weight(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_4059_WEIGHT_CONV2D_4059_WEIGHT_DATA, Data);
}

u32 XNn_model_top_Get_Conv2d_4059_weight_conv2d_4059_weight(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_4059_WEIGHT_CONV2D_4059_WEIGHT_DATA);
    return Data;
}

void XNn_model_top_Set_Conv2d_4059_bias_conv2d_4059_bias(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_4059_BIAS_CONV2D_4059_BIAS_DATA, Data);
}

u32 XNn_model_top_Get_Conv2d_4059_bias_conv2d_4059_bias(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_4059_BIAS_CONV2D_4059_BIAS_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_3284_weight_dense_3284_weight(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_3284_WEIGHT_DENSE_3284_WEIGHT_DATA, Data);
}

u32 XNn_model_top_Get_Dense_3284_weight_dense_3284_weight(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_3284_WEIGHT_DENSE_3284_WEIGHT_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_3284_bias_dense_3284_bias(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_3284_BIAS_DENSE_3284_BIAS_DATA, Data);
}

u32 XNn_model_top_Get_Dense_3284_bias_dense_3284_bias(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_3284_BIAS_DENSE_3284_BIAS_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_3285_weight_dense_3285_weight(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_3285_WEIGHT_DENSE_3285_WEIGHT_DATA, Data);
}

u32 XNn_model_top_Get_Dense_3285_weight_dense_3285_weight(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_3285_WEIGHT_DENSE_3285_WEIGHT_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_3285_bias_dense_3285_bias(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_3285_BIAS_DENSE_3285_BIAS_DATA, Data);
}

u32 XNn_model_top_Get_Dense_3285_bias_dense_3285_bias(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_3285_BIAS_DENSE_3285_BIAS_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_3286_weight_dense_3286_weight(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_3286_WEIGHT_DENSE_3286_WEIGHT_DATA, Data);
}

u32 XNn_model_top_Get_Dense_3286_weight_dense_3286_weight(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_3286_WEIGHT_DENSE_3286_WEIGHT_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_3286_bias_dense_3286_bias(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_3286_BIAS_DENSE_3286_BIAS_DATA, Data);
}

u32 XNn_model_top_Get_Dense_3286_bias_dense_3286_bias(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_3286_BIAS_DENSE_3286_BIAS_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_3287_weight_dense_3287_weight(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_3287_WEIGHT_DENSE_3287_WEIGHT_DATA, Data);
}

u32 XNn_model_top_Get_Dense_3287_weight_dense_3287_weight(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_3287_WEIGHT_DENSE_3287_WEIGHT_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_3287_bias_dense_3287_bias(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_3287_BIAS_DENSE_3287_BIAS_DATA, Data);
}

u32 XNn_model_top_Get_Dense_3287_bias_dense_3287_bias(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_3287_BIAS_DENSE_3287_BIAS_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_3288_weight_dense_3288_weight(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_3288_WEIGHT_DENSE_3288_WEIGHT_DATA, Data);
}

u32 XNn_model_top_Get_Dense_3288_weight_dense_3288_weight(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_3288_WEIGHT_DENSE_3288_WEIGHT_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_3288_bias_dense_3288_bias(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_3288_BIAS_DENSE_3288_BIAS_DATA, Data);
}

u32 XNn_model_top_Get_Dense_3288_bias_dense_3288_bias(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_3288_BIAS_DENSE_3288_BIAS_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_3289_weight_dense_3289_weight(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_3289_WEIGHT_DENSE_3289_WEIGHT_DATA, Data);
}

u32 XNn_model_top_Get_Dense_3289_weight_dense_3289_weight(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_3289_WEIGHT_DENSE_3289_WEIGHT_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_3289_bias_dense_3289_bias(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_3289_BIAS_DENSE_3289_BIAS_DATA, Data);
}

u32 XNn_model_top_Get_Dense_3289_bias_dense_3289_bias(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_3289_BIAS_DENSE_3289_BIAS_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_3290_weight_dense_3290_weight(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_3290_WEIGHT_DENSE_3290_WEIGHT_DATA, Data);
}

u32 XNn_model_top_Get_Dense_3290_weight_dense_3290_weight(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_3290_WEIGHT_DENSE_3290_WEIGHT_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_3290_bias_dense_3290_bias(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_3290_BIAS_DENSE_3290_BIAS_DATA, Data);
}

u32 XNn_model_top_Get_Dense_3290_bias_dense_3290_bias(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_3290_BIAS_DENSE_3290_BIAS_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_3291_weight_dense_3291_weight(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_3291_WEIGHT_DENSE_3291_WEIGHT_DATA, Data);
}

u32 XNn_model_top_Get_Dense_3291_weight_dense_3291_weight(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_3291_WEIGHT_DENSE_3291_WEIGHT_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_3291_bias_dense_3291_bias(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_3291_BIAS_DENSE_3291_BIAS_DATA, Data);
}

u32 XNn_model_top_Get_Dense_3291_bias_dense_3291_bias(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_3291_BIAS_DENSE_3291_BIAS_DATA);
    return Data;
}

void XNn_model_top_InterruptGlobalEnable(XNn_model_top *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_GIE, 1);
}

void XNn_model_top_InterruptGlobalDisable(XNn_model_top *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_GIE, 0);
}

void XNn_model_top_InterruptEnable(XNn_model_top *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_IER);
    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_IER, Register | Mask);
}

void XNn_model_top_InterruptDisable(XNn_model_top *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_IER);
    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_IER, Register & (~Mask));
}

void XNn_model_top_InterruptClear(XNn_model_top *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_ISR, Mask);
}

u32 XNn_model_top_InterruptGetEnabled(XNn_model_top *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_IER);
}

u32 XNn_model_top_InterruptGetStatus(XNn_model_top *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_ISR);
}

