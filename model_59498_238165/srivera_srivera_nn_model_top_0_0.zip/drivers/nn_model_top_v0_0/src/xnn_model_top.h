// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2019.2.1 (64-bit)
// Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef XNN_MODEL_TOP_H
#define XNN_MODEL_TOP_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xnn_model_top_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
#else
typedef struct {
    u16 DeviceId;
    u32 Control_BaseAddress;
} XNn_model_top_Config;
#endif

typedef struct {
    u32 Control_BaseAddress;
    u32 IsReady;
} XNn_model_top;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XNn_model_top_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XNn_model_top_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XNn_model_top_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XNn_model_top_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
int XNn_model_top_Initialize(XNn_model_top *InstancePtr, u16 DeviceId);
XNn_model_top_Config* XNn_model_top_LookupConfig(u16 DeviceId);
int XNn_model_top_CfgInitialize(XNn_model_top *InstancePtr, XNn_model_top_Config *ConfigPtr);
#else
int XNn_model_top_Initialize(XNn_model_top *InstancePtr, const char* InstanceName);
int XNn_model_top_Release(XNn_model_top *InstancePtr);
#endif

void XNn_model_top_Start(XNn_model_top *InstancePtr);
u32 XNn_model_top_IsDone(XNn_model_top *InstancePtr);
u32 XNn_model_top_IsIdle(XNn_model_top *InstancePtr);
u32 XNn_model_top_IsReady(XNn_model_top *InstancePtr);
void XNn_model_top_EnableAutoRestart(XNn_model_top *InstancePtr);
void XNn_model_top_DisableAutoRestart(XNn_model_top *InstancePtr);
u32 XNn_model_top_Get_return(XNn_model_top *InstancePtr);

void XNn_model_top_Set_Input_input(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Input_input(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2554_conv2d_2554(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2554_conv2d_2554(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2559_conv2d_2559(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2559_conv2d_2559(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_2076_max_pooling2d_2076(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_2076_max_pooling2d_2076(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_2080_max_pooling2d_2080(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_2080_max_pooling2d_2080(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1942_dense_1942(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1942_dense_1942(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2560_conv2d_2560(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2560_conv2d_2560(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2555_conv2d_2555(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2555_conv2d_2555(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_2081_max_pooling2d_2081(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_2081_max_pooling2d_2081(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_2077_max_pooling2d_2077(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_2077_max_pooling2d_2077(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1945_dense_1945(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1945_dense_1945(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1943_dense_1943(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1943_dense_1943(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2561_conv2d_2561(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2561_conv2d_2561(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2556_conv2d_2556(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2556_conv2d_2556(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_2082_max_pooling2d_2082(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_2082_max_pooling2d_2082(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_2078_max_pooling2d_2078(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_2078_max_pooling2d_2078(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1946_dense_1946(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1946_dense_1946(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1944_dense_1944(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1944_dense_1944(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_2083_max_pooling2d_2083(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_2083_max_pooling2d_2083(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_2079_max_pooling2d_2079(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_2079_max_pooling2d_2079(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1947_dense_1947(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1947_dense_1947(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Concatenate_168_concatenate_168(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Concatenate_168_concatenate_168(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Flatten_56_flatten_56(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Flatten_56_flatten_56(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1948_dense_1948(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1948_dense_1948(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1949_dense_1949(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1949_dense_1949(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2554_weight_conv2d_2554_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2554_weight_conv2d_2554_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2554_bias_conv2d_2554_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2554_bias_conv2d_2554_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2559_weight_conv2d_2559_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2559_weight_conv2d_2559_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2559_bias_conv2d_2559_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2559_bias_conv2d_2559_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1942_weight_dense_1942_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1942_weight_dense_1942_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1942_bias_dense_1942_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1942_bias_dense_1942_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2560_weight_conv2d_2560_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2560_weight_conv2d_2560_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2560_bias_conv2d_2560_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2560_bias_conv2d_2560_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2555_weight_conv2d_2555_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2555_weight_conv2d_2555_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2555_bias_conv2d_2555_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2555_bias_conv2d_2555_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1945_weight_dense_1945_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1945_weight_dense_1945_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1945_bias_dense_1945_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1945_bias_dense_1945_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1943_weight_dense_1943_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1943_weight_dense_1943_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1943_bias_dense_1943_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1943_bias_dense_1943_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2561_weight_conv2d_2561_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2561_weight_conv2d_2561_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2561_bias_conv2d_2561_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2561_bias_conv2d_2561_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2556_weight_conv2d_2556_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2556_weight_conv2d_2556_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2556_bias_conv2d_2556_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2556_bias_conv2d_2556_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1946_weight_dense_1946_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1946_weight_dense_1946_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1946_bias_dense_1946_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1946_bias_dense_1946_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1944_weight_dense_1944_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1944_weight_dense_1944_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1944_bias_dense_1944_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1944_bias_dense_1944_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1947_weight_dense_1947_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1947_weight_dense_1947_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1947_bias_dense_1947_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1947_bias_dense_1947_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1948_weight_dense_1948_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1948_weight_dense_1948_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1948_bias_dense_1948_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1948_bias_dense_1948_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1949_weight_dense_1949_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1949_weight_dense_1949_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1949_bias_dense_1949_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1949_bias_dense_1949_bias(XNn_model_top *InstancePtr);

void XNn_model_top_InterruptGlobalEnable(XNn_model_top *InstancePtr);
void XNn_model_top_InterruptGlobalDisable(XNn_model_top *InstancePtr);
void XNn_model_top_InterruptEnable(XNn_model_top *InstancePtr, u32 Mask);
void XNn_model_top_InterruptDisable(XNn_model_top *InstancePtr, u32 Mask);
void XNn_model_top_InterruptClear(XNn_model_top *InstancePtr, u32 Mask);
u32 XNn_model_top_InterruptGetEnabled(XNn_model_top *InstancePtr);
u32 XNn_model_top_InterruptGetStatus(XNn_model_top *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
