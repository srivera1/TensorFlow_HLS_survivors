// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2019.2.1 (64-bit)
// Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef XNN_MODEL_TOP_H
#define XNN_MODEL_TOP_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xnn_model_top_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
#else
typedef struct {
    u16 DeviceId;
    u32 Control_BaseAddress;
} XNn_model_top_Config;
#endif

typedef struct {
    u32 Control_BaseAddress;
    u32 IsReady;
} XNn_model_top;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XNn_model_top_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XNn_model_top_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XNn_model_top_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XNn_model_top_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
int XNn_model_top_Initialize(XNn_model_top *InstancePtr, u16 DeviceId);
XNn_model_top_Config* XNn_model_top_LookupConfig(u16 DeviceId);
int XNn_model_top_CfgInitialize(XNn_model_top *InstancePtr, XNn_model_top_Config *ConfigPtr);
#else
int XNn_model_top_Initialize(XNn_model_top *InstancePtr, const char* InstanceName);
int XNn_model_top_Release(XNn_model_top *InstancePtr);
#endif

void XNn_model_top_Start(XNn_model_top *InstancePtr);
u32 XNn_model_top_IsDone(XNn_model_top *InstancePtr);
u32 XNn_model_top_IsIdle(XNn_model_top *InstancePtr);
u32 XNn_model_top_IsReady(XNn_model_top *InstancePtr);
void XNn_model_top_EnableAutoRestart(XNn_model_top *InstancePtr);
void XNn_model_top_DisableAutoRestart(XNn_model_top *InstancePtr);
u32 XNn_model_top_Get_return(XNn_model_top *InstancePtr);

void XNn_model_top_Set_Input1_input1(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Input1_input1(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Input2_input2(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Input2_input2(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_4351_dense_4351(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_4351_dense_4351(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_4355_dense_4355(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_4355_dense_4355(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_4352_dense_4352(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_4352_dense_4352(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_4356_dense_4356(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_4356_dense_4356(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_4353_dense_4353(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_4353_dense_4353(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_4357_dense_4357(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_4357_dense_4357(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_4354_dense_4354(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_4354_dense_4354(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_4358_dense_4358(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_4358_dense_4358(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_1296_conv2d_1296(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_1296_conv2d_1296(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_1297_conv2d_1297(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_1297_conv2d_1297(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Concatenate_3588_concatenate_3588(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Concatenate_3588_concatenate_3588(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_1302_conv2d_1302(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_1302_conv2d_1302(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_1303_conv2d_1303(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_1303_conv2d_1303(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_566_max_pooling2d_566(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_566_max_pooling2d_566(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_1304_conv2d_1304(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_1304_conv2d_1304(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_1305_conv2d_1305(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_1305_conv2d_1305(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_567_max_pooling2d_567(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_567_max_pooling2d_567(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_1306_conv2d_1306(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_1306_conv2d_1306(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_568_max_pooling2d_568(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_568_max_pooling2d_568(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Flatten_128_flatten_128(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Flatten_128_flatten_128(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_4385_dense_4385(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_4385_dense_4385(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_4386_dense_4386(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_4386_dense_4386(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_4351_weight_dense_4351_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_4351_weight_dense_4351_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_4351_bias_dense_4351_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_4351_bias_dense_4351_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_4355_weight_dense_4355_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_4355_weight_dense_4355_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_4355_bias_dense_4355_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_4355_bias_dense_4355_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_4352_weight_dense_4352_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_4352_weight_dense_4352_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_4352_bias_dense_4352_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_4352_bias_dense_4352_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_4356_weight_dense_4356_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_4356_weight_dense_4356_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_4356_bias_dense_4356_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_4356_bias_dense_4356_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_4353_weight_dense_4353_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_4353_weight_dense_4353_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_4353_bias_dense_4353_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_4353_bias_dense_4353_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_4357_weight_dense_4357_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_4357_weight_dense_4357_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_4357_bias_dense_4357_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_4357_bias_dense_4357_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_4354_weight_dense_4354_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_4354_weight_dense_4354_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_4354_bias_dense_4354_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_4354_bias_dense_4354_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_4358_weight_dense_4358_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_4358_weight_dense_4358_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_4358_bias_dense_4358_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_4358_bias_dense_4358_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_1296_weight_conv2d_1296_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_1296_weight_conv2d_1296_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_1296_bias_conv2d_1296_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_1296_bias_conv2d_1296_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_1297_weight_conv2d_1297_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_1297_weight_conv2d_1297_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_1297_bias_conv2d_1297_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_1297_bias_conv2d_1297_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_1302_weight_conv2d_1302_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_1302_weight_conv2d_1302_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_1302_bias_conv2d_1302_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_1302_bias_conv2d_1302_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_1303_weight_conv2d_1303_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_1303_weight_conv2d_1303_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_1303_bias_conv2d_1303_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_1303_bias_conv2d_1303_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_1304_weight_conv2d_1304_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_1304_weight_conv2d_1304_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_1304_bias_conv2d_1304_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_1304_bias_conv2d_1304_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_1305_weight_conv2d_1305_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_1305_weight_conv2d_1305_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_1305_bias_conv2d_1305_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_1305_bias_conv2d_1305_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_1306_weight_conv2d_1306_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_1306_weight_conv2d_1306_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_1306_bias_conv2d_1306_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_1306_bias_conv2d_1306_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_4385_weight_dense_4385_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_4385_weight_dense_4385_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_4385_bias_dense_4385_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_4385_bias_dense_4385_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_4386_weight_dense_4386_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_4386_weight_dense_4386_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_4386_bias_dense_4386_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_4386_bias_dense_4386_bias(XNn_model_top *InstancePtr);

void XNn_model_top_InterruptGlobalEnable(XNn_model_top *InstancePtr);
void XNn_model_top_InterruptGlobalDisable(XNn_model_top *InstancePtr);
void XNn_model_top_InterruptEnable(XNn_model_top *InstancePtr, u32 Mask);
void XNn_model_top_InterruptDisable(XNn_model_top *InstancePtr, u32 Mask);
void XNn_model_top_InterruptClear(XNn_model_top *InstancePtr, u32 Mask);
u32 XNn_model_top_InterruptGetEnabled(XNn_model_top *InstancePtr);
u32 XNn_model_top_InterruptGetStatus(XNn_model_top *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
