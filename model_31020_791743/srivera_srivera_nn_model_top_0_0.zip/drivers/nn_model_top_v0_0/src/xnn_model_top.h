// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2019.2.1 (64-bit)
// Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef XNN_MODEL_TOP_H
#define XNN_MODEL_TOP_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xnn_model_top_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
#else
typedef struct {
    u16 DeviceId;
    u32 Control_BaseAddress;
} XNn_model_top_Config;
#endif

typedef struct {
    u32 Control_BaseAddress;
    u32 IsReady;
} XNn_model_top;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XNn_model_top_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XNn_model_top_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XNn_model_top_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XNn_model_top_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
int XNn_model_top_Initialize(XNn_model_top *InstancePtr, u16 DeviceId);
XNn_model_top_Config* XNn_model_top_LookupConfig(u16 DeviceId);
int XNn_model_top_CfgInitialize(XNn_model_top *InstancePtr, XNn_model_top_Config *ConfigPtr);
#else
int XNn_model_top_Initialize(XNn_model_top *InstancePtr, const char* InstanceName);
int XNn_model_top_Release(XNn_model_top *InstancePtr);
#endif

void XNn_model_top_Start(XNn_model_top *InstancePtr);
u32 XNn_model_top_IsDone(XNn_model_top *InstancePtr);
u32 XNn_model_top_IsIdle(XNn_model_top *InstancePtr);
u32 XNn_model_top_IsReady(XNn_model_top *InstancePtr);
void XNn_model_top_EnableAutoRestart(XNn_model_top *InstancePtr);
void XNn_model_top_DisableAutoRestart(XNn_model_top *InstancePtr);
u32 XNn_model_top_Get_return(XNn_model_top *InstancePtr);

void XNn_model_top_Set_Input1_input1(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Input1_input1(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Input2_input2(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Input2_input2(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3479_conv2d_3479(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3479_conv2d_3479(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3481_conv2d_3481(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3481_conv2d_3481(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_2941_max_pooling2d_2941(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_2941_max_pooling2d_2941(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_2942_max_pooling2d_2942(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_2942_max_pooling2d_2942(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2808_dense_2808(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2808_dense_2808(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2809_dense_2809(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2809_dense_2809(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3480_conv2d_3480(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3480_conv2d_3480(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3482_conv2d_3482(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3482_conv2d_3482(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Concatenate_606_concatenate_606(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Concatenate_606_concatenate_606(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3487_conv2d_3487(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3487_conv2d_3487(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3486_conv2d_3486(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3486_conv2d_3486(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_2946_max_pooling2d_2946(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_2946_max_pooling2d_2946(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_2945_max_pooling2d_2945(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_2945_max_pooling2d_2945(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2811_dense_2811(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2811_dense_2811(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Concatenate_608_concatenate_608(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Concatenate_608_concatenate_608(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3488_conv2d_3488(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3488_conv2d_3488(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_2947_max_pooling2d_2947(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_2947_max_pooling2d_2947(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2812_dense_2812(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2812_dense_2812(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2813_dense_2813(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2813_dense_2813(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Flatten_312_flatten_312(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Flatten_312_flatten_312(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2814_dense_2814(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2814_dense_2814(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2815_dense_2815(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2815_dense_2815(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3479_weight_conv2d_3479_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3479_weight_conv2d_3479_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3479_bias_conv2d_3479_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3479_bias_conv2d_3479_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3481_weight_conv2d_3481_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3481_weight_conv2d_3481_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3481_bias_conv2d_3481_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3481_bias_conv2d_3481_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2808_weight_dense_2808_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2808_weight_dense_2808_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2808_bias_dense_2808_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2808_bias_dense_2808_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2809_weight_dense_2809_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2809_weight_dense_2809_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2809_bias_dense_2809_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2809_bias_dense_2809_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3480_weight_conv2d_3480_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3480_weight_conv2d_3480_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3480_bias_conv2d_3480_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3480_bias_conv2d_3480_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3482_weight_conv2d_3482_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3482_weight_conv2d_3482_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3482_bias_conv2d_3482_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3482_bias_conv2d_3482_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3487_weight_conv2d_3487_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3487_weight_conv2d_3487_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3487_bias_conv2d_3487_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3487_bias_conv2d_3487_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3486_weight_conv2d_3486_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3486_weight_conv2d_3486_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3486_bias_conv2d_3486_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3486_bias_conv2d_3486_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2811_weight_dense_2811_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2811_weight_dense_2811_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2811_bias_dense_2811_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2811_bias_dense_2811_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3488_weight_conv2d_3488_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3488_weight_conv2d_3488_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3488_bias_conv2d_3488_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3488_bias_conv2d_3488_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2812_weight_dense_2812_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2812_weight_dense_2812_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2812_bias_dense_2812_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2812_bias_dense_2812_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2813_weight_dense_2813_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2813_weight_dense_2813_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2813_bias_dense_2813_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2813_bias_dense_2813_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2814_weight_dense_2814_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2814_weight_dense_2814_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2814_bias_dense_2814_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2814_bias_dense_2814_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2815_weight_dense_2815_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2815_weight_dense_2815_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2815_bias_dense_2815_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2815_bias_dense_2815_bias(XNn_model_top *InstancePtr);

void XNn_model_top_InterruptGlobalEnable(XNn_model_top *InstancePtr);
void XNn_model_top_InterruptGlobalDisable(XNn_model_top *InstancePtr);
void XNn_model_top_InterruptEnable(XNn_model_top *InstancePtr, u32 Mask);
void XNn_model_top_InterruptDisable(XNn_model_top *InstancePtr, u32 Mask);
void XNn_model_top_InterruptClear(XNn_model_top *InstancePtr, u32 Mask);
u32 XNn_model_top_InterruptGetEnabled(XNn_model_top *InstancePtr);
u32 XNn_model_top_InterruptGetStatus(XNn_model_top *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
