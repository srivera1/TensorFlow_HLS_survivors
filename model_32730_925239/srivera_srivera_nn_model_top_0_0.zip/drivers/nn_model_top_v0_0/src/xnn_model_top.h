// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2019.2.1 (64-bit)
// Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef XNN_MODEL_TOP_H
#define XNN_MODEL_TOP_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xnn_model_top_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
#else
typedef struct {
    u16 DeviceId;
    u32 Control_BaseAddress;
} XNn_model_top_Config;
#endif

typedef struct {
    u32 Control_BaseAddress;
    u32 IsReady;
} XNn_model_top;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XNn_model_top_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XNn_model_top_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XNn_model_top_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XNn_model_top_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
int XNn_model_top_Initialize(XNn_model_top *InstancePtr, u16 DeviceId);
XNn_model_top_Config* XNn_model_top_LookupConfig(u16 DeviceId);
int XNn_model_top_CfgInitialize(XNn_model_top *InstancePtr, XNn_model_top_Config *ConfigPtr);
#else
int XNn_model_top_Initialize(XNn_model_top *InstancePtr, const char* InstanceName);
int XNn_model_top_Release(XNn_model_top *InstancePtr);
#endif

void XNn_model_top_Start(XNn_model_top *InstancePtr);
u32 XNn_model_top_IsDone(XNn_model_top *InstancePtr);
u32 XNn_model_top_IsIdle(XNn_model_top *InstancePtr);
u32 XNn_model_top_IsReady(XNn_model_top *InstancePtr);
void XNn_model_top_EnableAutoRestart(XNn_model_top *InstancePtr);
void XNn_model_top_DisableAutoRestart(XNn_model_top *InstancePtr);
u32 XNn_model_top_Get_return(XNn_model_top *InstancePtr);

void XNn_model_top_Set_Input1_input1(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Input1_input1(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Input2_input2(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Input2_input2(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_4065_conv2d_4065(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_4065_conv2d_4065(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_4067_conv2d_4067(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_4067_conv2d_4067(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_3442_max_pooling2d_3442(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_3442_max_pooling2d_3442(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_3443_max_pooling2d_3443(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_3443_max_pooling2d_3443(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_3292_dense_3292(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_3292_dense_3292(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_3293_dense_3293(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_3293_dense_3293(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_4066_conv2d_4066(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_4066_conv2d_4066(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_4068_conv2d_4068(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_4068_conv2d_4068(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Concatenate_708_concatenate_708(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Concatenate_708_concatenate_708(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_4069_conv2d_4069(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_4069_conv2d_4069(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_3444_max_pooling2d_3444(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_3444_max_pooling2d_3444(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_3294_dense_3294(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_3294_dense_3294(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_4070_conv2d_4070(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_4070_conv2d_4070(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_3445_max_pooling2d_3445(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_3445_max_pooling2d_3445(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_3295_dense_3295(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_3295_dense_3295(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_3296_dense_3296(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_3296_dense_3296(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_3297_dense_3297(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_3297_dense_3297(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Concatenate_709_concatenate_709(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Concatenate_709_concatenate_709(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_3298_dense_3298(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_3298_dense_3298(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_3299_dense_3299(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_3299_dense_3299(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_3300_dense_3300(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_3300_dense_3300(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_3301_dense_3301(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_3301_dense_3301(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Concatenate_710_concatenate_710(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Concatenate_710_concatenate_710(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Flatten_367_flatten_367(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Flatten_367_flatten_367(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_3302_dense_3302(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_3302_dense_3302(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_3303_dense_3303(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_3303_dense_3303(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_4065_weight_conv2d_4065_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_4065_weight_conv2d_4065_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_4065_bias_conv2d_4065_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_4065_bias_conv2d_4065_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_4067_weight_conv2d_4067_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_4067_weight_conv2d_4067_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_4067_bias_conv2d_4067_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_4067_bias_conv2d_4067_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_3292_weight_dense_3292_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_3292_weight_dense_3292_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_3292_bias_dense_3292_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_3292_bias_dense_3292_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_3293_weight_dense_3293_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_3293_weight_dense_3293_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_3293_bias_dense_3293_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_3293_bias_dense_3293_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_4066_weight_conv2d_4066_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_4066_weight_conv2d_4066_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_4066_bias_conv2d_4066_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_4066_bias_conv2d_4066_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_4068_weight_conv2d_4068_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_4068_weight_conv2d_4068_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_4068_bias_conv2d_4068_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_4068_bias_conv2d_4068_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_4069_weight_conv2d_4069_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_4069_weight_conv2d_4069_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_4069_bias_conv2d_4069_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_4069_bias_conv2d_4069_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_3294_weight_dense_3294_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_3294_weight_dense_3294_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_3294_bias_dense_3294_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_3294_bias_dense_3294_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_4070_weight_conv2d_4070_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_4070_weight_conv2d_4070_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_4070_bias_conv2d_4070_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_4070_bias_conv2d_4070_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_3295_weight_dense_3295_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_3295_weight_dense_3295_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_3295_bias_dense_3295_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_3295_bias_dense_3295_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_3296_weight_dense_3296_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_3296_weight_dense_3296_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_3296_bias_dense_3296_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_3296_bias_dense_3296_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_3297_weight_dense_3297_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_3297_weight_dense_3297_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_3297_bias_dense_3297_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_3297_bias_dense_3297_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_3298_weight_dense_3298_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_3298_weight_dense_3298_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_3298_bias_dense_3298_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_3298_bias_dense_3298_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_3299_weight_dense_3299_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_3299_weight_dense_3299_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_3299_bias_dense_3299_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_3299_bias_dense_3299_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_3300_weight_dense_3300_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_3300_weight_dense_3300_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_3300_bias_dense_3300_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_3300_bias_dense_3300_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_3301_weight_dense_3301_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_3301_weight_dense_3301_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_3301_bias_dense_3301_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_3301_bias_dense_3301_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_3302_weight_dense_3302_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_3302_weight_dense_3302_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_3302_bias_dense_3302_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_3302_bias_dense_3302_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_3303_weight_dense_3303_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_3303_weight_dense_3303_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_3303_bias_dense_3303_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_3303_bias_dense_3303_bias(XNn_model_top *InstancePtr);

void XNn_model_top_InterruptGlobalEnable(XNn_model_top *InstancePtr);
void XNn_model_top_InterruptGlobalDisable(XNn_model_top *InstancePtr);
void XNn_model_top_InterruptEnable(XNn_model_top *InstancePtr, u32 Mask);
void XNn_model_top_InterruptDisable(XNn_model_top *InstancePtr, u32 Mask);
void XNn_model_top_InterruptClear(XNn_model_top *InstancePtr, u32 Mask);
u32 XNn_model_top_InterruptGetEnabled(XNn_model_top *InstancePtr);
u32 XNn_model_top_InterruptGetStatus(XNn_model_top *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
