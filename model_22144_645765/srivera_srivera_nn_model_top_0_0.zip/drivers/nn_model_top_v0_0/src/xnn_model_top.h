// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2019.2.1 (64-bit)
// Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef XNN_MODEL_TOP_H
#define XNN_MODEL_TOP_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xnn_model_top_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
#else
typedef struct {
    u16 DeviceId;
    u32 Control_BaseAddress;
} XNn_model_top_Config;
#endif

typedef struct {
    u32 Control_BaseAddress;
    u32 IsReady;
} XNn_model_top;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XNn_model_top_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XNn_model_top_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XNn_model_top_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XNn_model_top_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
int XNn_model_top_Initialize(XNn_model_top *InstancePtr, u16 DeviceId);
XNn_model_top_Config* XNn_model_top_LookupConfig(u16 DeviceId);
int XNn_model_top_CfgInitialize(XNn_model_top *InstancePtr, XNn_model_top_Config *ConfigPtr);
#else
int XNn_model_top_Initialize(XNn_model_top *InstancePtr, const char* InstanceName);
int XNn_model_top_Release(XNn_model_top *InstancePtr);
#endif

void XNn_model_top_Start(XNn_model_top *InstancePtr);
u32 XNn_model_top_IsDone(XNn_model_top *InstancePtr);
u32 XNn_model_top_IsIdle(XNn_model_top *InstancePtr);
u32 XNn_model_top_IsReady(XNn_model_top *InstancePtr);
void XNn_model_top_EnableAutoRestart(XNn_model_top *InstancePtr);
void XNn_model_top_DisableAutoRestart(XNn_model_top *InstancePtr);
u32 XNn_model_top_Get_return(XNn_model_top *InstancePtr);

void XNn_model_top_Set_Input1_input1(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Input1_input1(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Input2_input2(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Input2_input2(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2959_conv2d_2959(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2959_conv2d_2959(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2962_conv2d_2962(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2962_conv2d_2962(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_2496_max_pooling2d_2496(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_2496_max_pooling2d_2496(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_2498_max_pooling2d_2498(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_2498_max_pooling2d_2498(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2389_dense_2389(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2389_dense_2389(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2391_dense_2391(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2391_dense_2391(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2960_conv2d_2960(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2960_conv2d_2960(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2963_conv2d_2963(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2963_conv2d_2963(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_2497_max_pooling2d_2497(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_2497_max_pooling2d_2497(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_2499_max_pooling2d_2499(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_2499_max_pooling2d_2499(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2390_dense_2390(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2390_dense_2390(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2392_dense_2392(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2392_dense_2392(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2961_conv2d_2961(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2961_conv2d_2961(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2964_conv2d_2964(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2964_conv2d_2964(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Concatenate_524_concatenate_524(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Concatenate_524_concatenate_524(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2965_conv2d_2965(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2965_conv2d_2965(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_2500_max_pooling2d_2500(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_2500_max_pooling2d_2500(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2393_dense_2393(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2393_dense_2393(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2394_dense_2394(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2394_dense_2394(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2395_dense_2395(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2395_dense_2395(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2396_dense_2396(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2396_dense_2396(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Flatten_265_flatten_265(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Flatten_265_flatten_265(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2397_dense_2397(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2397_dense_2397(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2398_dense_2398(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2398_dense_2398(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2959_weight_conv2d_2959_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2959_weight_conv2d_2959_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2959_bias_conv2d_2959_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2959_bias_conv2d_2959_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2962_weight_conv2d_2962_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2962_weight_conv2d_2962_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2962_bias_conv2d_2962_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2962_bias_conv2d_2962_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2389_weight_dense_2389_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2389_weight_dense_2389_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2389_bias_dense_2389_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2389_bias_dense_2389_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2391_weight_dense_2391_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2391_weight_dense_2391_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2391_bias_dense_2391_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2391_bias_dense_2391_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2960_weight_conv2d_2960_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2960_weight_conv2d_2960_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2960_bias_conv2d_2960_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2960_bias_conv2d_2960_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2963_weight_conv2d_2963_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2963_weight_conv2d_2963_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2963_bias_conv2d_2963_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2963_bias_conv2d_2963_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2390_weight_dense_2390_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2390_weight_dense_2390_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2390_bias_dense_2390_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2390_bias_dense_2390_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2392_weight_dense_2392_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2392_weight_dense_2392_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2392_bias_dense_2392_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2392_bias_dense_2392_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2961_weight_conv2d_2961_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2961_weight_conv2d_2961_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2961_bias_conv2d_2961_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2961_bias_conv2d_2961_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2964_weight_conv2d_2964_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2964_weight_conv2d_2964_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2964_bias_conv2d_2964_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2964_bias_conv2d_2964_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2965_weight_conv2d_2965_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2965_weight_conv2d_2965_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2965_bias_conv2d_2965_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2965_bias_conv2d_2965_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2393_weight_dense_2393_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2393_weight_dense_2393_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2393_bias_dense_2393_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2393_bias_dense_2393_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2394_weight_dense_2394_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2394_weight_dense_2394_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2394_bias_dense_2394_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2394_bias_dense_2394_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2395_weight_dense_2395_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2395_weight_dense_2395_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2395_bias_dense_2395_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2395_bias_dense_2395_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2396_weight_dense_2396_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2396_weight_dense_2396_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2396_bias_dense_2396_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2396_bias_dense_2396_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2397_weight_dense_2397_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2397_weight_dense_2397_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2397_bias_dense_2397_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2397_bias_dense_2397_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2398_weight_dense_2398_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2398_weight_dense_2398_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2398_bias_dense_2398_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2398_bias_dense_2398_bias(XNn_model_top *InstancePtr);

void XNn_model_top_InterruptGlobalEnable(XNn_model_top *InstancePtr);
void XNn_model_top_InterruptGlobalDisable(XNn_model_top *InstancePtr);
void XNn_model_top_InterruptEnable(XNn_model_top *InstancePtr, u32 Mask);
void XNn_model_top_InterruptDisable(XNn_model_top *InstancePtr, u32 Mask);
void XNn_model_top_InterruptClear(XNn_model_top *InstancePtr, u32 Mask);
u32 XNn_model_top_InterruptGetEnabled(XNn_model_top *InstancePtr);
u32 XNn_model_top_InterruptGetStatus(XNn_model_top *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
