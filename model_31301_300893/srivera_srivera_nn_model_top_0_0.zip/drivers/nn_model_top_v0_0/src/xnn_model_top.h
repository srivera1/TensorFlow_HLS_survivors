// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2019.2.1 (64-bit)
// Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef XNN_MODEL_TOP_H
#define XNN_MODEL_TOP_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xnn_model_top_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
#else
typedef struct {
    u16 DeviceId;
    u32 Control_BaseAddress;
} XNn_model_top_Config;
#endif

typedef struct {
    u32 Control_BaseAddress;
    u32 IsReady;
} XNn_model_top;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XNn_model_top_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XNn_model_top_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XNn_model_top_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XNn_model_top_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
int XNn_model_top_Initialize(XNn_model_top *InstancePtr, u16 DeviceId);
XNn_model_top_Config* XNn_model_top_LookupConfig(u16 DeviceId);
int XNn_model_top_CfgInitialize(XNn_model_top *InstancePtr, XNn_model_top_Config *ConfigPtr);
#else
int XNn_model_top_Initialize(XNn_model_top *InstancePtr, const char* InstanceName);
int XNn_model_top_Release(XNn_model_top *InstancePtr);
#endif

void XNn_model_top_Start(XNn_model_top *InstancePtr);
u32 XNn_model_top_IsDone(XNn_model_top *InstancePtr);
u32 XNn_model_top_IsIdle(XNn_model_top *InstancePtr);
u32 XNn_model_top_IsReady(XNn_model_top *InstancePtr);
void XNn_model_top_EnableAutoRestart(XNn_model_top *InstancePtr);
void XNn_model_top_DisableAutoRestart(XNn_model_top *InstancePtr);
u32 XNn_model_top_Get_return(XNn_model_top *InstancePtr);

void XNn_model_top_Set_Input1_input1(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Input1_input1(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Input2_input2(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Input2_input2(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_839_conv2d_839(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_839_conv2d_839(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_841_conv2d_841(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_841_conv2d_841(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_706_max_pooling2d_706(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_706_max_pooling2d_706(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_708_max_pooling2d_708(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_708_max_pooling2d_708(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_693_dense_693(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_693_dense_693(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_695_dense_695(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_695_dense_695(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_840_conv2d_840(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_840_conv2d_840(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_842_conv2d_842(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_842_conv2d_842(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_707_max_pooling2d_707(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_707_max_pooling2d_707(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_709_max_pooling2d_709(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_709_max_pooling2d_709(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_694_dense_694(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_694_dense_694(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_696_dense_696(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_696_dense_696(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Concatenate_150_concatenate_150(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Concatenate_150_concatenate_150(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_843_conv2d_843(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_843_conv2d_843(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_710_max_pooling2d_710(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_710_max_pooling2d_710(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_697_dense_697(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_697_dense_697(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_711_max_pooling2d_711(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_711_max_pooling2d_711(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_698_dense_698(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_698_dense_698(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Flatten_78_flatten_78(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Flatten_78_flatten_78(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_699_dense_699(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_699_dense_699(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_700_dense_700(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_700_dense_700(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_839_weight_conv2d_839_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_839_weight_conv2d_839_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_839_bias_conv2d_839_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_839_bias_conv2d_839_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_841_weight_conv2d_841_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_841_weight_conv2d_841_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_841_bias_conv2d_841_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_841_bias_conv2d_841_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_693_weight_dense_693_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_693_weight_dense_693_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_693_bias_dense_693_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_693_bias_dense_693_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_695_weight_dense_695_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_695_weight_dense_695_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_695_bias_dense_695_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_695_bias_dense_695_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_840_weight_conv2d_840_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_840_weight_conv2d_840_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_840_bias_conv2d_840_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_840_bias_conv2d_840_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_842_weight_conv2d_842_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_842_weight_conv2d_842_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_842_bias_conv2d_842_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_842_bias_conv2d_842_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_694_weight_dense_694_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_694_weight_dense_694_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_694_bias_dense_694_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_694_bias_dense_694_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_696_weight_dense_696_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_696_weight_dense_696_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_696_bias_dense_696_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_696_bias_dense_696_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_843_weight_conv2d_843_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_843_weight_conv2d_843_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_843_bias_conv2d_843_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_843_bias_conv2d_843_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_697_weight_dense_697_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_697_weight_dense_697_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_697_bias_dense_697_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_697_bias_dense_697_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_698_weight_dense_698_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_698_weight_dense_698_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_698_bias_dense_698_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_698_bias_dense_698_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_699_weight_dense_699_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_699_weight_dense_699_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_699_bias_dense_699_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_699_bias_dense_699_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_700_weight_dense_700_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_700_weight_dense_700_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_700_bias_dense_700_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_700_bias_dense_700_bias(XNn_model_top *InstancePtr);

void XNn_model_top_InterruptGlobalEnable(XNn_model_top *InstancePtr);
void XNn_model_top_InterruptGlobalDisable(XNn_model_top *InstancePtr);
void XNn_model_top_InterruptEnable(XNn_model_top *InstancePtr, u32 Mask);
void XNn_model_top_InterruptDisable(XNn_model_top *InstancePtr, u32 Mask);
void XNn_model_top_InterruptClear(XNn_model_top *InstancePtr, u32 Mask);
u32 XNn_model_top_InterruptGetEnabled(XNn_model_top *InstancePtr);
u32 XNn_model_top_InterruptGetStatus(XNn_model_top *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
