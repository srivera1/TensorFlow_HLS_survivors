// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2019.2.1 (64-bit)
// Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef XNN_MODEL_TOP_H
#define XNN_MODEL_TOP_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xnn_model_top_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
#else
typedef struct {
    u16 DeviceId;
    u32 Control_BaseAddress;
} XNn_model_top_Config;
#endif

typedef struct {
    u32 Control_BaseAddress;
    u32 IsReady;
} XNn_model_top;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XNn_model_top_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XNn_model_top_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XNn_model_top_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XNn_model_top_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
int XNn_model_top_Initialize(XNn_model_top *InstancePtr, u16 DeviceId);
XNn_model_top_Config* XNn_model_top_LookupConfig(u16 DeviceId);
int XNn_model_top_CfgInitialize(XNn_model_top *InstancePtr, XNn_model_top_Config *ConfigPtr);
#else
int XNn_model_top_Initialize(XNn_model_top *InstancePtr, const char* InstanceName);
int XNn_model_top_Release(XNn_model_top *InstancePtr);
#endif

void XNn_model_top_Start(XNn_model_top *InstancePtr);
u32 XNn_model_top_IsDone(XNn_model_top *InstancePtr);
u32 XNn_model_top_IsIdle(XNn_model_top *InstancePtr);
u32 XNn_model_top_IsReady(XNn_model_top *InstancePtr);
void XNn_model_top_EnableAutoRestart(XNn_model_top *InstancePtr);
void XNn_model_top_DisableAutoRestart(XNn_model_top *InstancePtr);
u32 XNn_model_top_Get_return(XNn_model_top *InstancePtr);

void XNn_model_top_Set_Input1_input1(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Input1_input1(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Input2_input2(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Input2_input2(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2985_conv2d_2985(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2985_conv2d_2985(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2988_conv2d_2988(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2988_conv2d_2988(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_2517_max_pooling2d_2517(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_2517_max_pooling2d_2517(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_2519_max_pooling2d_2519(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_2519_max_pooling2d_2519(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2411_dense_2411(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2411_dense_2411(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2413_dense_2413(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2413_dense_2413(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2986_conv2d_2986(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2986_conv2d_2986(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2989_conv2d_2989(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2989_conv2d_2989(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_2518_max_pooling2d_2518(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_2518_max_pooling2d_2518(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_2520_max_pooling2d_2520(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_2520_max_pooling2d_2520(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2412_dense_2412(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2412_dense_2412(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2414_dense_2414(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2414_dense_2414(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2987_conv2d_2987(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2987_conv2d_2987(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2990_conv2d_2990(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2990_conv2d_2990(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Concatenate_527_concatenate_527(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Concatenate_527_concatenate_527(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2991_conv2d_2991(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2991_conv2d_2991(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_2521_max_pooling2d_2521(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_2521_max_pooling2d_2521(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2415_dense_2415(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2415_dense_2415(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2416_dense_2416(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2416_dense_2416(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2417_dense_2417(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2417_dense_2417(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2418_dense_2418(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2418_dense_2418(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2419_dense_2419(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2419_dense_2419(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2420_dense_2420(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2420_dense_2420(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Flatten_268_flatten_268(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Flatten_268_flatten_268(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2421_dense_2421(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2421_dense_2421(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2422_dense_2422(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2422_dense_2422(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2423_dense_2423(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2423_dense_2423(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2985_weight_conv2d_2985_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2985_weight_conv2d_2985_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2985_bias_conv2d_2985_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2985_bias_conv2d_2985_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2988_weight_conv2d_2988_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2988_weight_conv2d_2988_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2988_bias_conv2d_2988_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2988_bias_conv2d_2988_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2411_weight_dense_2411_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2411_weight_dense_2411_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2411_bias_dense_2411_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2411_bias_dense_2411_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2413_weight_dense_2413_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2413_weight_dense_2413_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2413_bias_dense_2413_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2413_bias_dense_2413_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2986_weight_conv2d_2986_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2986_weight_conv2d_2986_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2986_bias_conv2d_2986_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2986_bias_conv2d_2986_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2989_weight_conv2d_2989_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2989_weight_conv2d_2989_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2989_bias_conv2d_2989_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2989_bias_conv2d_2989_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2412_weight_dense_2412_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2412_weight_dense_2412_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2412_bias_dense_2412_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2412_bias_dense_2412_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2414_weight_dense_2414_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2414_weight_dense_2414_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2414_bias_dense_2414_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2414_bias_dense_2414_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2987_weight_conv2d_2987_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2987_weight_conv2d_2987_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2987_bias_conv2d_2987_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2987_bias_conv2d_2987_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2990_weight_conv2d_2990_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2990_weight_conv2d_2990_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2990_bias_conv2d_2990_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2990_bias_conv2d_2990_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2991_weight_conv2d_2991_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2991_weight_conv2d_2991_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2991_bias_conv2d_2991_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2991_bias_conv2d_2991_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2415_weight_dense_2415_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2415_weight_dense_2415_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2415_bias_dense_2415_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2415_bias_dense_2415_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2416_weight_dense_2416_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2416_weight_dense_2416_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2416_bias_dense_2416_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2416_bias_dense_2416_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2417_weight_dense_2417_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2417_weight_dense_2417_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2417_bias_dense_2417_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2417_bias_dense_2417_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2418_weight_dense_2418_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2418_weight_dense_2418_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2418_bias_dense_2418_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2418_bias_dense_2418_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2419_weight_dense_2419_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2419_weight_dense_2419_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2419_bias_dense_2419_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2419_bias_dense_2419_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2420_weight_dense_2420_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2420_weight_dense_2420_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2420_bias_dense_2420_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2420_bias_dense_2420_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2421_weight_dense_2421_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2421_weight_dense_2421_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2421_bias_dense_2421_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2421_bias_dense_2421_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2422_weight_dense_2422_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2422_weight_dense_2422_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2422_bias_dense_2422_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2422_bias_dense_2422_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2423_weight_dense_2423_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2423_weight_dense_2423_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2423_bias_dense_2423_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2423_bias_dense_2423_bias(XNn_model_top *InstancePtr);

void XNn_model_top_InterruptGlobalEnable(XNn_model_top *InstancePtr);
void XNn_model_top_InterruptGlobalDisable(XNn_model_top *InstancePtr);
void XNn_model_top_InterruptEnable(XNn_model_top *InstancePtr, u32 Mask);
void XNn_model_top_InterruptDisable(XNn_model_top *InstancePtr, u32 Mask);
void XNn_model_top_InterruptClear(XNn_model_top *InstancePtr, u32 Mask);
u32 XNn_model_top_InterruptGetEnabled(XNn_model_top *InstancePtr);
u32 XNn_model_top_InterruptGetStatus(XNn_model_top *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
