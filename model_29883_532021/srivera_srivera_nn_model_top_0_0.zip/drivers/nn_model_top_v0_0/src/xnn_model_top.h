// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2019.2.1 (64-bit)
// Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef XNN_MODEL_TOP_H
#define XNN_MODEL_TOP_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xnn_model_top_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
#else
typedef struct {
    u16 DeviceId;
    u32 Control_BaseAddress;
} XNn_model_top_Config;
#endif

typedef struct {
    u32 Control_BaseAddress;
    u32 IsReady;
} XNn_model_top;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XNn_model_top_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XNn_model_top_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XNn_model_top_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XNn_model_top_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
int XNn_model_top_Initialize(XNn_model_top *InstancePtr, u16 DeviceId);
XNn_model_top_Config* XNn_model_top_LookupConfig(u16 DeviceId);
int XNn_model_top_CfgInitialize(XNn_model_top *InstancePtr, XNn_model_top_Config *ConfigPtr);
#else
int XNn_model_top_Initialize(XNn_model_top *InstancePtr, const char* InstanceName);
int XNn_model_top_Release(XNn_model_top *InstancePtr);
#endif

void XNn_model_top_Start(XNn_model_top *InstancePtr);
u32 XNn_model_top_IsDone(XNn_model_top *InstancePtr);
u32 XNn_model_top_IsIdle(XNn_model_top *InstancePtr);
u32 XNn_model_top_IsReady(XNn_model_top *InstancePtr);
void XNn_model_top_EnableAutoRestart(XNn_model_top *InstancePtr);
void XNn_model_top_DisableAutoRestart(XNn_model_top *InstancePtr);
u32 XNn_model_top_Get_return(XNn_model_top *InstancePtr);

void XNn_model_top_Set_Input1_input1(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Input1_input1(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Input2_input2(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Input2_input2(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_555_conv2d_555(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_555_conv2d_555(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_558_conv2d_558(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_558_conv2d_558(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_472_max_pooling2d_472(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_472_max_pooling2d_472(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_474_max_pooling2d_474(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_474_max_pooling2d_474(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_454_dense_454(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_454_dense_454(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_456_dense_456(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_456_dense_456(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_556_conv2d_556(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_556_conv2d_556(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_559_conv2d_559(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_559_conv2d_559(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_473_max_pooling2d_473(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_473_max_pooling2d_473(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_475_max_pooling2d_475(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_475_max_pooling2d_475(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_455_dense_455(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_455_dense_455(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_457_dense_457(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_457_dense_457(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_557_conv2d_557(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_557_conv2d_557(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_560_conv2d_560(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_560_conv2d_560(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Concatenate_102_concatenate_102(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Concatenate_102_concatenate_102(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_561_conv2d_561(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_561_conv2d_561(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_476_max_pooling2d_476(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_476_max_pooling2d_476(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Flatten_53_flatten_53(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Flatten_53_flatten_53(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_458_dense_458(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_458_dense_458(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_459_dense_459(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_459_dense_459(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_555_weight_conv2d_555_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_555_weight_conv2d_555_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_555_bias_conv2d_555_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_555_bias_conv2d_555_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_558_weight_conv2d_558_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_558_weight_conv2d_558_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_558_bias_conv2d_558_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_558_bias_conv2d_558_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_454_weight_dense_454_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_454_weight_dense_454_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_454_bias_dense_454_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_454_bias_dense_454_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_456_weight_dense_456_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_456_weight_dense_456_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_456_bias_dense_456_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_456_bias_dense_456_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_556_weight_conv2d_556_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_556_weight_conv2d_556_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_556_bias_conv2d_556_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_556_bias_conv2d_556_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_559_weight_conv2d_559_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_559_weight_conv2d_559_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_559_bias_conv2d_559_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_559_bias_conv2d_559_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_455_weight_dense_455_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_455_weight_dense_455_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_455_bias_dense_455_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_455_bias_dense_455_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_457_weight_dense_457_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_457_weight_dense_457_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_457_bias_dense_457_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_457_bias_dense_457_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_557_weight_conv2d_557_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_557_weight_conv2d_557_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_557_bias_conv2d_557_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_557_bias_conv2d_557_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_560_weight_conv2d_560_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_560_weight_conv2d_560_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_560_bias_conv2d_560_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_560_bias_conv2d_560_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_561_weight_conv2d_561_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_561_weight_conv2d_561_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_561_bias_conv2d_561_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_561_bias_conv2d_561_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_458_weight_dense_458_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_458_weight_dense_458_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_458_bias_dense_458_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_458_bias_dense_458_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_459_weight_dense_459_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_459_weight_dense_459_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_459_bias_dense_459_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_459_bias_dense_459_bias(XNn_model_top *InstancePtr);

void XNn_model_top_InterruptGlobalEnable(XNn_model_top *InstancePtr);
void XNn_model_top_InterruptGlobalDisable(XNn_model_top *InstancePtr);
void XNn_model_top_InterruptEnable(XNn_model_top *InstancePtr, u32 Mask);
void XNn_model_top_InterruptDisable(XNn_model_top *InstancePtr, u32 Mask);
void XNn_model_top_InterruptClear(XNn_model_top *InstancePtr, u32 Mask);
u32 XNn_model_top_InterruptGetEnabled(XNn_model_top *InstancePtr);
u32 XNn_model_top_InterruptGetStatus(XNn_model_top *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
