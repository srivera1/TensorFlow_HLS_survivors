// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2019.2.1 (64-bit)
// Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef XNN_MODEL_TOP_H
#define XNN_MODEL_TOP_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xnn_model_top_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
#else
typedef struct {
    u16 DeviceId;
    u32 Control_BaseAddress;
} XNn_model_top_Config;
#endif

typedef struct {
    u32 Control_BaseAddress;
    u32 IsReady;
} XNn_model_top;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XNn_model_top_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XNn_model_top_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XNn_model_top_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XNn_model_top_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
int XNn_model_top_Initialize(XNn_model_top *InstancePtr, u16 DeviceId);
XNn_model_top_Config* XNn_model_top_LookupConfig(u16 DeviceId);
int XNn_model_top_CfgInitialize(XNn_model_top *InstancePtr, XNn_model_top_Config *ConfigPtr);
#else
int XNn_model_top_Initialize(XNn_model_top *InstancePtr, const char* InstanceName);
int XNn_model_top_Release(XNn_model_top *InstancePtr);
#endif

void XNn_model_top_Start(XNn_model_top *InstancePtr);
u32 XNn_model_top_IsDone(XNn_model_top *InstancePtr);
u32 XNn_model_top_IsIdle(XNn_model_top *InstancePtr);
u32 XNn_model_top_IsReady(XNn_model_top *InstancePtr);
void XNn_model_top_EnableAutoRestart(XNn_model_top *InstancePtr);
void XNn_model_top_DisableAutoRestart(XNn_model_top *InstancePtr);
u32 XNn_model_top_Get_return(XNn_model_top *InstancePtr);

void XNn_model_top_Set_Input_input(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Input_input(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_4837_conv2d_4837(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_4837_conv2d_4837(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_4838_conv2d_4838(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_4838_conv2d_4838(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_3873_max_pooling2d_3873(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_3873_max_pooling2d_3873(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_4839_conv2d_4839(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_4839_conv2d_4839(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_4840_conv2d_4840(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_4840_conv2d_4840(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_3874_max_pooling2d_3874(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_3874_max_pooling2d_3874(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_4841_conv2d_4841(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_4841_conv2d_4841(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_4842_conv2d_4842(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_4842_conv2d_4842(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Flatten_103_flatten_103(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Flatten_103_flatten_103(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_3624_dense_3624(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_3624_dense_3624(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_3625_dense_3625(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_3625_dense_3625(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_4837_weight_conv2d_4837_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_4837_weight_conv2d_4837_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_4837_bias_conv2d_4837_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_4837_bias_conv2d_4837_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_4838_weight_conv2d_4838_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_4838_weight_conv2d_4838_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_4838_bias_conv2d_4838_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_4838_bias_conv2d_4838_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_4839_weight_conv2d_4839_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_4839_weight_conv2d_4839_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_4839_bias_conv2d_4839_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_4839_bias_conv2d_4839_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_4840_weight_conv2d_4840_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_4840_weight_conv2d_4840_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_4840_bias_conv2d_4840_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_4840_bias_conv2d_4840_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_4841_weight_conv2d_4841_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_4841_weight_conv2d_4841_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_4841_bias_conv2d_4841_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_4841_bias_conv2d_4841_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_4842_weight_conv2d_4842_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_4842_weight_conv2d_4842_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_4842_bias_conv2d_4842_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_4842_bias_conv2d_4842_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_3624_weight_dense_3624_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_3624_weight_dense_3624_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_3624_bias_dense_3624_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_3624_bias_dense_3624_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_3625_weight_dense_3625_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_3625_weight_dense_3625_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_3625_bias_dense_3625_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_3625_bias_dense_3625_bias(XNn_model_top *InstancePtr);

void XNn_model_top_InterruptGlobalEnable(XNn_model_top *InstancePtr);
void XNn_model_top_InterruptGlobalDisable(XNn_model_top *InstancePtr);
void XNn_model_top_InterruptEnable(XNn_model_top *InstancePtr, u32 Mask);
void XNn_model_top_InterruptDisable(XNn_model_top *InstancePtr, u32 Mask);
void XNn_model_top_InterruptClear(XNn_model_top *InstancePtr, u32 Mask);
u32 XNn_model_top_InterruptGetEnabled(XNn_model_top *InstancePtr);
u32 XNn_model_top_InterruptGetStatus(XNn_model_top *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
