// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2019.2.1 (64-bit)
// Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef XNN_MODEL_TOP_H
#define XNN_MODEL_TOP_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xnn_model_top_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
#else
typedef struct {
    u16 DeviceId;
    u32 Control_BaseAddress;
} XNn_model_top_Config;
#endif

typedef struct {
    u32 Control_BaseAddress;
    u32 IsReady;
} XNn_model_top;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XNn_model_top_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XNn_model_top_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XNn_model_top_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XNn_model_top_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
int XNn_model_top_Initialize(XNn_model_top *InstancePtr, u16 DeviceId);
XNn_model_top_Config* XNn_model_top_LookupConfig(u16 DeviceId);
int XNn_model_top_CfgInitialize(XNn_model_top *InstancePtr, XNn_model_top_Config *ConfigPtr);
#else
int XNn_model_top_Initialize(XNn_model_top *InstancePtr, const char* InstanceName);
int XNn_model_top_Release(XNn_model_top *InstancePtr);
#endif

void XNn_model_top_Start(XNn_model_top *InstancePtr);
u32 XNn_model_top_IsDone(XNn_model_top *InstancePtr);
u32 XNn_model_top_IsIdle(XNn_model_top *InstancePtr);
u32 XNn_model_top_IsReady(XNn_model_top *InstancePtr);
void XNn_model_top_EnableAutoRestart(XNn_model_top *InstancePtr);
void XNn_model_top_DisableAutoRestart(XNn_model_top *InstancePtr);
u32 XNn_model_top_Get_return(XNn_model_top *InstancePtr);

void XNn_model_top_Set_Input1_input1(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Input1_input1(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Input2_input2(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Input2_input2(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3708_conv2d_3708(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3708_conv2d_3708(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3710_conv2d_3710(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3710_conv2d_3710(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_3157_max_pooling2d_3157(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_3157_max_pooling2d_3157(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_3159_max_pooling2d_3159(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_3159_max_pooling2d_3159(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2999_dense_2999(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2999_dense_2999(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_3001_dense_3001(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_3001_dense_3001(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3709_conv2d_3709(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3709_conv2d_3709(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3711_conv2d_3711(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3711_conv2d_3711(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_3158_max_pooling2d_3158(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_3158_max_pooling2d_3158(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_3160_max_pooling2d_3160(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_3160_max_pooling2d_3160(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_3000_dense_3000(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_3000_dense_3000(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_3002_dense_3002(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_3002_dense_3002(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Concatenate_647_concatenate_647(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Concatenate_647_concatenate_647(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3712_conv2d_3712(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3712_conv2d_3712(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_3161_max_pooling2d_3161(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_3161_max_pooling2d_3161(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_3162_max_pooling2d_3162(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_3162_max_pooling2d_3162(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_3003_dense_3003(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_3003_dense_3003(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_3164_max_pooling2d_3164(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_3164_max_pooling2d_3164(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_3004_dense_3004(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_3004_dense_3004(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_3005_dense_3005(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_3005_dense_3005(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Concatenate_648_concatenate_648(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Concatenate_648_concatenate_648(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Flatten_337_flatten_337(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Flatten_337_flatten_337(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_3006_dense_3006(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_3006_dense_3006(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_3007_dense_3007(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_3007_dense_3007(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_3008_dense_3008(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_3008_dense_3008(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3708_weight_conv2d_3708_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3708_weight_conv2d_3708_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3708_bias_conv2d_3708_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3708_bias_conv2d_3708_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3710_weight_conv2d_3710_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3710_weight_conv2d_3710_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3710_bias_conv2d_3710_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3710_bias_conv2d_3710_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2999_weight_dense_2999_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2999_weight_dense_2999_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2999_bias_dense_2999_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2999_bias_dense_2999_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_3001_weight_dense_3001_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_3001_weight_dense_3001_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_3001_bias_dense_3001_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_3001_bias_dense_3001_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3709_weight_conv2d_3709_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3709_weight_conv2d_3709_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3709_bias_conv2d_3709_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3709_bias_conv2d_3709_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3711_weight_conv2d_3711_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3711_weight_conv2d_3711_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3711_bias_conv2d_3711_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3711_bias_conv2d_3711_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_3000_weight_dense_3000_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_3000_weight_dense_3000_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_3000_bias_dense_3000_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_3000_bias_dense_3000_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_3002_weight_dense_3002_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_3002_weight_dense_3002_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_3002_bias_dense_3002_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_3002_bias_dense_3002_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3712_weight_conv2d_3712_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3712_weight_conv2d_3712_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3712_bias_conv2d_3712_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3712_bias_conv2d_3712_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_3003_weight_dense_3003_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_3003_weight_dense_3003_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_3003_bias_dense_3003_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_3003_bias_dense_3003_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_3004_weight_dense_3004_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_3004_weight_dense_3004_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_3004_bias_dense_3004_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_3004_bias_dense_3004_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_3005_weight_dense_3005_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_3005_weight_dense_3005_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_3005_bias_dense_3005_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_3005_bias_dense_3005_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_3006_weight_dense_3006_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_3006_weight_dense_3006_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_3006_bias_dense_3006_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_3006_bias_dense_3006_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_3007_weight_dense_3007_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_3007_weight_dense_3007_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_3007_bias_dense_3007_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_3007_bias_dense_3007_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_3008_weight_dense_3008_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_3008_weight_dense_3008_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_3008_bias_dense_3008_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_3008_bias_dense_3008_bias(XNn_model_top *InstancePtr);

void XNn_model_top_InterruptGlobalEnable(XNn_model_top *InstancePtr);
void XNn_model_top_InterruptGlobalDisable(XNn_model_top *InstancePtr);
void XNn_model_top_InterruptEnable(XNn_model_top *InstancePtr, u32 Mask);
void XNn_model_top_InterruptDisable(XNn_model_top *InstancePtr, u32 Mask);
void XNn_model_top_InterruptClear(XNn_model_top *InstancePtr, u32 Mask);
u32 XNn_model_top_InterruptGetEnabled(XNn_model_top *InstancePtr);
u32 XNn_model_top_InterruptGetStatus(XNn_model_top *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
