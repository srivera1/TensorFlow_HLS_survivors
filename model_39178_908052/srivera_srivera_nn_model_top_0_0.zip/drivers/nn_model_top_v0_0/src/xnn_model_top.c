// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2019.2.1 (64-bit)
// Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
// ==============================================================
/***************************** Include Files *********************************/
#include "xnn_model_top.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XNn_model_top_CfgInitialize(XNn_model_top *InstancePtr, XNn_model_top_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XNn_model_top_Start(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_AP_CTRL) & 0x80;
    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XNn_model_top_IsDone(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XNn_model_top_IsIdle(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XNn_model_top_IsReady(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XNn_model_top_EnableAutoRestart(XNn_model_top *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XNn_model_top_DisableAutoRestart(XNn_model_top *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_AP_CTRL, 0);
}

u32 XNn_model_top_Get_return(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_AP_RETURN);
    return Data;
}
void XNn_model_top_Set_Input2_input2(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_INPUT2_INPUT2_DATA, Data);
}

u32 XNn_model_top_Get_Input2_input2(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_INPUT2_INPUT2_DATA);
    return Data;
}

void XNn_model_top_Set_Input1_input1(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_INPUT1_INPUT1_DATA, Data);
}

u32 XNn_model_top_Get_Input1_input1(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_INPUT1_INPUT1_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_77_dense_77(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_77_DENSE_77_DATA, Data);
}

u32 XNn_model_top_Get_Dense_77_dense_77(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_77_DENSE_77_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_75_dense_75(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_75_DENSE_75_DATA, Data);
}

u32 XNn_model_top_Get_Dense_75_dense_75(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_75_DENSE_75_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_78_dense_78(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_78_DENSE_78_DATA, Data);
}

u32 XNn_model_top_Get_Dense_78_dense_78(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_78_DENSE_78_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_76_dense_76(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_76_DENSE_76_DATA, Data);
}

u32 XNn_model_top_Get_Dense_76_dense_76(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_76_DENSE_76_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_79_dense_79(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_79_DENSE_79_DATA, Data);
}

u32 XNn_model_top_Get_Dense_79_dense_79(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_79_DENSE_79_DATA);
    return Data;
}

void XNn_model_top_Set_Conv2d_25_conv2d_25(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_25_CONV2D_25_DATA, Data);
}

u32 XNn_model_top_Get_Conv2d_25_conv2d_25(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_25_CONV2D_25_DATA);
    return Data;
}

void XNn_model_top_Set_Conv2d_26_conv2d_26(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_26_CONV2D_26_DATA, Data);
}

u32 XNn_model_top_Get_Conv2d_26_conv2d_26(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_26_CONV2D_26_DATA);
    return Data;
}

void XNn_model_top_Set_Concatenate_9_concatenate_9(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONCATENATE_9_CONCATENATE_9_DATA, Data);
}

u32 XNn_model_top_Get_Concatenate_9_concatenate_9(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONCATENATE_9_CONCATENATE_9_DATA);
    return Data;
}

void XNn_model_top_Set_Conv2d_30_conv2d_30(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_30_CONV2D_30_DATA, Data);
}

u32 XNn_model_top_Get_Conv2d_30_conv2d_30(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_30_CONV2D_30_DATA);
    return Data;
}

void XNn_model_top_Set_Conv2d_37_conv2d_37(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_37_CONV2D_37_DATA, Data);
}

u32 XNn_model_top_Get_Conv2d_37_conv2d_37(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_37_CONV2D_37_DATA);
    return Data;
}

void XNn_model_top_Set_Conv2d_38_conv2d_38(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_38_CONV2D_38_DATA, Data);
}

u32 XNn_model_top_Get_Conv2d_38_conv2d_38(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_38_CONV2D_38_DATA);
    return Data;
}

void XNn_model_top_Set_Max_pooling2d_19_max_pooling2d_19(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_MAX_POOLING2D_19_MAX_POOLING2D_19_DATA, Data);
}

u32 XNn_model_top_Get_Max_pooling2d_19_max_pooling2d_19(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_MAX_POOLING2D_19_MAX_POOLING2D_19_DATA);
    return Data;
}

void XNn_model_top_Set_Conv2d_39_conv2d_39(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_39_CONV2D_39_DATA, Data);
}

u32 XNn_model_top_Get_Conv2d_39_conv2d_39(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_39_CONV2D_39_DATA);
    return Data;
}

void XNn_model_top_Set_Conv2d_40_conv2d_40(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_40_CONV2D_40_DATA, Data);
}

u32 XNn_model_top_Get_Conv2d_40_conv2d_40(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_40_CONV2D_40_DATA);
    return Data;
}

void XNn_model_top_Set_Max_pooling2d_20_max_pooling2d_20(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_MAX_POOLING2D_20_MAX_POOLING2D_20_DATA, Data);
}

u32 XNn_model_top_Get_Max_pooling2d_20_max_pooling2d_20(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_MAX_POOLING2D_20_MAX_POOLING2D_20_DATA);
    return Data;
}

void XNn_model_top_Set_Conv2d_41_conv2d_41(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_41_CONV2D_41_DATA, Data);
}

u32 XNn_model_top_Get_Conv2d_41_conv2d_41(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_41_CONV2D_41_DATA);
    return Data;
}

void XNn_model_top_Set_Max_pooling2d_21_max_pooling2d_21(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_MAX_POOLING2D_21_MAX_POOLING2D_21_DATA, Data);
}

u32 XNn_model_top_Get_Max_pooling2d_21_max_pooling2d_21(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_MAX_POOLING2D_21_MAX_POOLING2D_21_DATA);
    return Data;
}

void XNn_model_top_Set_Flatten_5_flatten_5(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_FLATTEN_5_FLATTEN_5_DATA, Data);
}

u32 XNn_model_top_Get_Flatten_5_flatten_5(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_FLATTEN_5_FLATTEN_5_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_126_dense_126(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_126_DENSE_126_DATA, Data);
}

u32 XNn_model_top_Get_Dense_126_dense_126(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_126_DENSE_126_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_127_dense_127(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_127_DENSE_127_DATA, Data);
}

u32 XNn_model_top_Get_Dense_127_dense_127(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_127_DENSE_127_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_128_dense_128(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_128_DENSE_128_DATA, Data);
}

u32 XNn_model_top_Get_Dense_128_dense_128(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_128_DENSE_128_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_77_weight_dense_77_weight(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_77_WEIGHT_DENSE_77_WEIGHT_DATA, Data);
}

u32 XNn_model_top_Get_Dense_77_weight_dense_77_weight(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_77_WEIGHT_DENSE_77_WEIGHT_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_77_bias_dense_77_bias(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_77_BIAS_DENSE_77_BIAS_DATA, Data);
}

u32 XNn_model_top_Get_Dense_77_bias_dense_77_bias(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_77_BIAS_DENSE_77_BIAS_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_75_weight_dense_75_weight(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_75_WEIGHT_DENSE_75_WEIGHT_DATA, Data);
}

u32 XNn_model_top_Get_Dense_75_weight_dense_75_weight(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_75_WEIGHT_DENSE_75_WEIGHT_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_75_bias_dense_75_bias(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_75_BIAS_DENSE_75_BIAS_DATA, Data);
}

u32 XNn_model_top_Get_Dense_75_bias_dense_75_bias(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_75_BIAS_DENSE_75_BIAS_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_78_weight_dense_78_weight(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_78_WEIGHT_DENSE_78_WEIGHT_DATA, Data);
}

u32 XNn_model_top_Get_Dense_78_weight_dense_78_weight(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_78_WEIGHT_DENSE_78_WEIGHT_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_78_bias_dense_78_bias(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_78_BIAS_DENSE_78_BIAS_DATA, Data);
}

u32 XNn_model_top_Get_Dense_78_bias_dense_78_bias(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_78_BIAS_DENSE_78_BIAS_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_76_weight_dense_76_weight(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_76_WEIGHT_DENSE_76_WEIGHT_DATA, Data);
}

u32 XNn_model_top_Get_Dense_76_weight_dense_76_weight(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_76_WEIGHT_DENSE_76_WEIGHT_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_76_bias_dense_76_bias(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_76_BIAS_DENSE_76_BIAS_DATA, Data);
}

u32 XNn_model_top_Get_Dense_76_bias_dense_76_bias(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_76_BIAS_DENSE_76_BIAS_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_79_weight_dense_79_weight(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_79_WEIGHT_DENSE_79_WEIGHT_DATA, Data);
}

u32 XNn_model_top_Get_Dense_79_weight_dense_79_weight(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_79_WEIGHT_DENSE_79_WEIGHT_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_79_bias_dense_79_bias(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_79_BIAS_DENSE_79_BIAS_DATA, Data);
}

u32 XNn_model_top_Get_Dense_79_bias_dense_79_bias(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_79_BIAS_DENSE_79_BIAS_DATA);
    return Data;
}

void XNn_model_top_Set_Conv2d_25_weight_conv2d_25_weight(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_25_WEIGHT_CONV2D_25_WEIGHT_DATA, Data);
}

u32 XNn_model_top_Get_Conv2d_25_weight_conv2d_25_weight(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_25_WEIGHT_CONV2D_25_WEIGHT_DATA);
    return Data;
}

void XNn_model_top_Set_Conv2d_25_bias_conv2d_25_bias(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_25_BIAS_CONV2D_25_BIAS_DATA, Data);
}

u32 XNn_model_top_Get_Conv2d_25_bias_conv2d_25_bias(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_25_BIAS_CONV2D_25_BIAS_DATA);
    return Data;
}

void XNn_model_top_Set_Conv2d_26_weight_conv2d_26_weight(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_26_WEIGHT_CONV2D_26_WEIGHT_DATA, Data);
}

u32 XNn_model_top_Get_Conv2d_26_weight_conv2d_26_weight(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_26_WEIGHT_CONV2D_26_WEIGHT_DATA);
    return Data;
}

void XNn_model_top_Set_Conv2d_26_bias_conv2d_26_bias(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_26_BIAS_CONV2D_26_BIAS_DATA, Data);
}

u32 XNn_model_top_Get_Conv2d_26_bias_conv2d_26_bias(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_26_BIAS_CONV2D_26_BIAS_DATA);
    return Data;
}

void XNn_model_top_Set_Conv2d_30_weight_conv2d_30_weight(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_30_WEIGHT_CONV2D_30_WEIGHT_DATA, Data);
}

u32 XNn_model_top_Get_Conv2d_30_weight_conv2d_30_weight(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_30_WEIGHT_CONV2D_30_WEIGHT_DATA);
    return Data;
}

void XNn_model_top_Set_Conv2d_30_bias_conv2d_30_bias(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_30_BIAS_CONV2D_30_BIAS_DATA, Data);
}

u32 XNn_model_top_Get_Conv2d_30_bias_conv2d_30_bias(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_30_BIAS_CONV2D_30_BIAS_DATA);
    return Data;
}

void XNn_model_top_Set_Conv2d_37_weight_conv2d_37_weight(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_37_WEIGHT_CONV2D_37_WEIGHT_DATA, Data);
}

u32 XNn_model_top_Get_Conv2d_37_weight_conv2d_37_weight(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_37_WEIGHT_CONV2D_37_WEIGHT_DATA);
    return Data;
}

void XNn_model_top_Set_Conv2d_37_bias_conv2d_37_bias(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_37_BIAS_CONV2D_37_BIAS_DATA, Data);
}

u32 XNn_model_top_Get_Conv2d_37_bias_conv2d_37_bias(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_37_BIAS_CONV2D_37_BIAS_DATA);
    return Data;
}

void XNn_model_top_Set_Conv2d_38_weight_conv2d_38_weight(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_38_WEIGHT_CONV2D_38_WEIGHT_DATA, Data);
}

u32 XNn_model_top_Get_Conv2d_38_weight_conv2d_38_weight(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_38_WEIGHT_CONV2D_38_WEIGHT_DATA);
    return Data;
}

void XNn_model_top_Set_Conv2d_38_bias_conv2d_38_bias(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_38_BIAS_CONV2D_38_BIAS_DATA, Data);
}

u32 XNn_model_top_Get_Conv2d_38_bias_conv2d_38_bias(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_38_BIAS_CONV2D_38_BIAS_DATA);
    return Data;
}

void XNn_model_top_Set_Conv2d_39_weight_conv2d_39_weight(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_39_WEIGHT_CONV2D_39_WEIGHT_DATA, Data);
}

u32 XNn_model_top_Get_Conv2d_39_weight_conv2d_39_weight(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_39_WEIGHT_CONV2D_39_WEIGHT_DATA);
    return Data;
}

void XNn_model_top_Set_Conv2d_39_bias_conv2d_39_bias(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_39_BIAS_CONV2D_39_BIAS_DATA, Data);
}

u32 XNn_model_top_Get_Conv2d_39_bias_conv2d_39_bias(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_39_BIAS_CONV2D_39_BIAS_DATA);
    return Data;
}

void XNn_model_top_Set_Conv2d_40_weight_conv2d_40_weight(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_40_WEIGHT_CONV2D_40_WEIGHT_DATA, Data);
}

u32 XNn_model_top_Get_Conv2d_40_weight_conv2d_40_weight(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_40_WEIGHT_CONV2D_40_WEIGHT_DATA);
    return Data;
}

void XNn_model_top_Set_Conv2d_40_bias_conv2d_40_bias(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_40_BIAS_CONV2D_40_BIAS_DATA, Data);
}

u32 XNn_model_top_Get_Conv2d_40_bias_conv2d_40_bias(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_40_BIAS_CONV2D_40_BIAS_DATA);
    return Data;
}

void XNn_model_top_Set_Conv2d_41_weight_conv2d_41_weight(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_41_WEIGHT_CONV2D_41_WEIGHT_DATA, Data);
}

u32 XNn_model_top_Get_Conv2d_41_weight_conv2d_41_weight(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_41_WEIGHT_CONV2D_41_WEIGHT_DATA);
    return Data;
}

void XNn_model_top_Set_Conv2d_41_bias_conv2d_41_bias(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_41_BIAS_CONV2D_41_BIAS_DATA, Data);
}

u32 XNn_model_top_Get_Conv2d_41_bias_conv2d_41_bias(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_41_BIAS_CONV2D_41_BIAS_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_126_weight_dense_126_weight(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_126_WEIGHT_DENSE_126_WEIGHT_DATA, Data);
}

u32 XNn_model_top_Get_Dense_126_weight_dense_126_weight(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_126_WEIGHT_DENSE_126_WEIGHT_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_126_bias_dense_126_bias(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_126_BIAS_DENSE_126_BIAS_DATA, Data);
}

u32 XNn_model_top_Get_Dense_126_bias_dense_126_bias(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_126_BIAS_DENSE_126_BIAS_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_127_weight_dense_127_weight(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_127_WEIGHT_DENSE_127_WEIGHT_DATA, Data);
}

u32 XNn_model_top_Get_Dense_127_weight_dense_127_weight(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_127_WEIGHT_DENSE_127_WEIGHT_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_127_bias_dense_127_bias(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_127_BIAS_DENSE_127_BIAS_DATA, Data);
}

u32 XNn_model_top_Get_Dense_127_bias_dense_127_bias(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_127_BIAS_DENSE_127_BIAS_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_128_weight_dense_128_weight(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_128_WEIGHT_DENSE_128_WEIGHT_DATA, Data);
}

u32 XNn_model_top_Get_Dense_128_weight_dense_128_weight(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_128_WEIGHT_DENSE_128_WEIGHT_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_128_bias_dense_128_bias(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_128_BIAS_DENSE_128_BIAS_DATA, Data);
}

u32 XNn_model_top_Get_Dense_128_bias_dense_128_bias(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_128_BIAS_DENSE_128_BIAS_DATA);
    return Data;
}

void XNn_model_top_InterruptGlobalEnable(XNn_model_top *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_GIE, 1);
}

void XNn_model_top_InterruptGlobalDisable(XNn_model_top *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_GIE, 0);
}

void XNn_model_top_InterruptEnable(XNn_model_top *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_IER);
    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_IER, Register | Mask);
}

void XNn_model_top_InterruptDisable(XNn_model_top *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_IER);
    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_IER, Register & (~Mask));
}

void XNn_model_top_InterruptClear(XNn_model_top *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_ISR, Mask);
}

u32 XNn_model_top_InterruptGetEnabled(XNn_model_top *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_IER);
}

u32 XNn_model_top_InterruptGetStatus(XNn_model_top *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_ISR);
}

