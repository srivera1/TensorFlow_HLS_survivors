// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2019.2.1 (64-bit)
// Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef XNN_MODEL_TOP_H
#define XNN_MODEL_TOP_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xnn_model_top_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
#else
typedef struct {
    u16 DeviceId;
    u32 Control_BaseAddress;
} XNn_model_top_Config;
#endif

typedef struct {
    u32 Control_BaseAddress;
    u32 IsReady;
} XNn_model_top;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XNn_model_top_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XNn_model_top_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XNn_model_top_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XNn_model_top_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
int XNn_model_top_Initialize(XNn_model_top *InstancePtr, u16 DeviceId);
XNn_model_top_Config* XNn_model_top_LookupConfig(u16 DeviceId);
int XNn_model_top_CfgInitialize(XNn_model_top *InstancePtr, XNn_model_top_Config *ConfigPtr);
#else
int XNn_model_top_Initialize(XNn_model_top *InstancePtr, const char* InstanceName);
int XNn_model_top_Release(XNn_model_top *InstancePtr);
#endif

void XNn_model_top_Start(XNn_model_top *InstancePtr);
u32 XNn_model_top_IsDone(XNn_model_top *InstancePtr);
u32 XNn_model_top_IsIdle(XNn_model_top *InstancePtr);
u32 XNn_model_top_IsReady(XNn_model_top *InstancePtr);
void XNn_model_top_EnableAutoRestart(XNn_model_top *InstancePtr);
void XNn_model_top_DisableAutoRestart(XNn_model_top *InstancePtr);
u32 XNn_model_top_Get_return(XNn_model_top *InstancePtr);

void XNn_model_top_Set_Input1_input1(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Input1_input1(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Input2_input2(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Input2_input2(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_762_conv2d_762(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_762_conv2d_762(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_764_conv2d_764(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_764_conv2d_764(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_640_max_pooling2d_640(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_640_max_pooling2d_640(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_642_max_pooling2d_642(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_642_max_pooling2d_642(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_625_dense_625(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_625_dense_625(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_627_dense_627(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_627_dense_627(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_763_conv2d_763(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_763_conv2d_763(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_765_conv2d_765(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_765_conv2d_765(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_641_max_pooling2d_641(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_641_max_pooling2d_641(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_643_max_pooling2d_643(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_643_max_pooling2d_643(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_626_dense_626(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_626_dense_626(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_628_dense_628(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_628_dense_628(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Concatenate_139_concatenate_139(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Concatenate_139_concatenate_139(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_766_conv2d_766(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_766_conv2d_766(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_644_max_pooling2d_644(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_644_max_pooling2d_644(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_629_dense_629(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_629_dense_629(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_645_max_pooling2d_645(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_645_max_pooling2d_645(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_630_dense_630(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_630_dense_630(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_631_dense_631(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_631_dense_631(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_632_dense_632(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_632_dense_632(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_633_dense_633(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_633_dense_633(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_634_dense_634(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_634_dense_634(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Flatten_70_flatten_70(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Flatten_70_flatten_70(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_635_dense_635(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_635_dense_635(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_636_dense_636(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_636_dense_636(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_637_dense_637(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_637_dense_637(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_762_weight_conv2d_762_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_762_weight_conv2d_762_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_762_bias_conv2d_762_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_762_bias_conv2d_762_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_764_weight_conv2d_764_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_764_weight_conv2d_764_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_764_bias_conv2d_764_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_764_bias_conv2d_764_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_625_weight_dense_625_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_625_weight_dense_625_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_625_bias_dense_625_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_625_bias_dense_625_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_627_weight_dense_627_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_627_weight_dense_627_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_627_bias_dense_627_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_627_bias_dense_627_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_763_weight_conv2d_763_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_763_weight_conv2d_763_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_763_bias_conv2d_763_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_763_bias_conv2d_763_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_765_weight_conv2d_765_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_765_weight_conv2d_765_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_765_bias_conv2d_765_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_765_bias_conv2d_765_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_626_weight_dense_626_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_626_weight_dense_626_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_626_bias_dense_626_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_626_bias_dense_626_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_628_weight_dense_628_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_628_weight_dense_628_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_628_bias_dense_628_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_628_bias_dense_628_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_766_weight_conv2d_766_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_766_weight_conv2d_766_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_766_bias_conv2d_766_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_766_bias_conv2d_766_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_629_weight_dense_629_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_629_weight_dense_629_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_629_bias_dense_629_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_629_bias_dense_629_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_630_weight_dense_630_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_630_weight_dense_630_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_630_bias_dense_630_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_630_bias_dense_630_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_631_weight_dense_631_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_631_weight_dense_631_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_631_bias_dense_631_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_631_bias_dense_631_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_632_weight_dense_632_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_632_weight_dense_632_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_632_bias_dense_632_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_632_bias_dense_632_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_633_weight_dense_633_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_633_weight_dense_633_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_633_bias_dense_633_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_633_bias_dense_633_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_634_weight_dense_634_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_634_weight_dense_634_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_634_bias_dense_634_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_634_bias_dense_634_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_635_weight_dense_635_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_635_weight_dense_635_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_635_bias_dense_635_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_635_bias_dense_635_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_636_weight_dense_636_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_636_weight_dense_636_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_636_bias_dense_636_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_636_bias_dense_636_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_637_weight_dense_637_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_637_weight_dense_637_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_637_bias_dense_637_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_637_bias_dense_637_bias(XNn_model_top *InstancePtr);

void XNn_model_top_InterruptGlobalEnable(XNn_model_top *InstancePtr);
void XNn_model_top_InterruptGlobalDisable(XNn_model_top *InstancePtr);
void XNn_model_top_InterruptEnable(XNn_model_top *InstancePtr, u32 Mask);
void XNn_model_top_InterruptDisable(XNn_model_top *InstancePtr, u32 Mask);
void XNn_model_top_InterruptClear(XNn_model_top *InstancePtr, u32 Mask);
u32 XNn_model_top_InterruptGetEnabled(XNn_model_top *InstancePtr);
u32 XNn_model_top_InterruptGetStatus(XNn_model_top *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
