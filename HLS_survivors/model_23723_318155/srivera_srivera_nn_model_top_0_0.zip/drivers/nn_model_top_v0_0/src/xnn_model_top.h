// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2019.2.1 (64-bit)
// Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef XNN_MODEL_TOP_H
#define XNN_MODEL_TOP_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xnn_model_top_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
#else
typedef struct {
    u16 DeviceId;
    u32 Control_BaseAddress;
} XNn_model_top_Config;
#endif

typedef struct {
    u32 Control_BaseAddress;
    u32 IsReady;
} XNn_model_top;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XNn_model_top_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XNn_model_top_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XNn_model_top_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XNn_model_top_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
int XNn_model_top_Initialize(XNn_model_top *InstancePtr, u16 DeviceId);
XNn_model_top_Config* XNn_model_top_LookupConfig(u16 DeviceId);
int XNn_model_top_CfgInitialize(XNn_model_top *InstancePtr, XNn_model_top_Config *ConfigPtr);
#else
int XNn_model_top_Initialize(XNn_model_top *InstancePtr, const char* InstanceName);
int XNn_model_top_Release(XNn_model_top *InstancePtr);
#endif

void XNn_model_top_Start(XNn_model_top *InstancePtr);
u32 XNn_model_top_IsDone(XNn_model_top *InstancePtr);
u32 XNn_model_top_IsIdle(XNn_model_top *InstancePtr);
u32 XNn_model_top_IsReady(XNn_model_top *InstancePtr);
void XNn_model_top_EnableAutoRestart(XNn_model_top *InstancePtr);
void XNn_model_top_DisableAutoRestart(XNn_model_top *InstancePtr);
u32 XNn_model_top_Get_return(XNn_model_top *InstancePtr);

void XNn_model_top_Set_Input1_input1(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Input1_input1(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Input2_input2(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Input2_input2(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3043_conv2d_3043(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3043_conv2d_3043(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3045_conv2d_3045(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3045_conv2d_3045(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_2560_max_pooling2d_2560(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_2560_max_pooling2d_2560(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_2562_max_pooling2d_2562(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_2562_max_pooling2d_2562(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2456_dense_2456(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2456_dense_2456(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2458_dense_2458(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2458_dense_2458(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3044_conv2d_3044(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3044_conv2d_3044(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3046_conv2d_3046(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3046_conv2d_3046(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_2561_max_pooling2d_2561(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_2561_max_pooling2d_2561(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_2563_max_pooling2d_2563(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_2563_max_pooling2d_2563(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2457_dense_2457(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2457_dense_2457(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2459_dense_2459(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2459_dense_2459(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Concatenate_535_concatenate_535(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Concatenate_535_concatenate_535(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3047_conv2d_3047(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3047_conv2d_3047(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_2564_max_pooling2d_2564(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_2564_max_pooling2d_2564(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_2565_max_pooling2d_2565(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_2565_max_pooling2d_2565(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2460_dense_2460(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2460_dense_2460(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2461_dense_2461(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2461_dense_2461(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Flatten_273_flatten_273(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Flatten_273_flatten_273(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2462_dense_2462(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2462_dense_2462(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2463_dense_2463(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2463_dense_2463(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2464_dense_2464(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2464_dense_2464(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3043_weight_conv2d_3043_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3043_weight_conv2d_3043_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3043_bias_conv2d_3043_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3043_bias_conv2d_3043_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3045_weight_conv2d_3045_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3045_weight_conv2d_3045_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3045_bias_conv2d_3045_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3045_bias_conv2d_3045_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2456_weight_dense_2456_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2456_weight_dense_2456_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2456_bias_dense_2456_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2456_bias_dense_2456_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2458_weight_dense_2458_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2458_weight_dense_2458_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2458_bias_dense_2458_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2458_bias_dense_2458_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3044_weight_conv2d_3044_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3044_weight_conv2d_3044_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3044_bias_conv2d_3044_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3044_bias_conv2d_3044_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3046_weight_conv2d_3046_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3046_weight_conv2d_3046_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3046_bias_conv2d_3046_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3046_bias_conv2d_3046_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2457_weight_dense_2457_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2457_weight_dense_2457_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2457_bias_dense_2457_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2457_bias_dense_2457_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2459_weight_dense_2459_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2459_weight_dense_2459_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2459_bias_dense_2459_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2459_bias_dense_2459_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3047_weight_conv2d_3047_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3047_weight_conv2d_3047_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3047_bias_conv2d_3047_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3047_bias_conv2d_3047_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2460_weight_dense_2460_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2460_weight_dense_2460_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2460_bias_dense_2460_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2460_bias_dense_2460_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2461_weight_dense_2461_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2461_weight_dense_2461_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2461_bias_dense_2461_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2461_bias_dense_2461_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2462_weight_dense_2462_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2462_weight_dense_2462_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2462_bias_dense_2462_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2462_bias_dense_2462_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2463_weight_dense_2463_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2463_weight_dense_2463_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2463_bias_dense_2463_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2463_bias_dense_2463_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2464_weight_dense_2464_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2464_weight_dense_2464_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2464_bias_dense_2464_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2464_bias_dense_2464_bias(XNn_model_top *InstancePtr);

void XNn_model_top_InterruptGlobalEnable(XNn_model_top *InstancePtr);
void XNn_model_top_InterruptGlobalDisable(XNn_model_top *InstancePtr);
void XNn_model_top_InterruptEnable(XNn_model_top *InstancePtr, u32 Mask);
void XNn_model_top_InterruptDisable(XNn_model_top *InstancePtr, u32 Mask);
void XNn_model_top_InterruptClear(XNn_model_top *InstancePtr, u32 Mask);
u32 XNn_model_top_InterruptGetEnabled(XNn_model_top *InstancePtr);
u32 XNn_model_top_InterruptGetStatus(XNn_model_top *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
