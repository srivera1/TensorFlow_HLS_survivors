// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2019.2.1 (64-bit)
// Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef XNN_MODEL_TOP_H
#define XNN_MODEL_TOP_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xnn_model_top_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
#else
typedef struct {
    u16 DeviceId;
    u32 Control_BaseAddress;
} XNn_model_top_Config;
#endif

typedef struct {
    u32 Control_BaseAddress;
    u32 IsReady;
} XNn_model_top;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XNn_model_top_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XNn_model_top_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XNn_model_top_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XNn_model_top_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
int XNn_model_top_Initialize(XNn_model_top *InstancePtr, u16 DeviceId);
XNn_model_top_Config* XNn_model_top_LookupConfig(u16 DeviceId);
int XNn_model_top_CfgInitialize(XNn_model_top *InstancePtr, XNn_model_top_Config *ConfigPtr);
#else
int XNn_model_top_Initialize(XNn_model_top *InstancePtr, const char* InstanceName);
int XNn_model_top_Release(XNn_model_top *InstancePtr);
#endif

void XNn_model_top_Start(XNn_model_top *InstancePtr);
u32 XNn_model_top_IsDone(XNn_model_top *InstancePtr);
u32 XNn_model_top_IsIdle(XNn_model_top *InstancePtr);
u32 XNn_model_top_IsReady(XNn_model_top *InstancePtr);
void XNn_model_top_EnableAutoRestart(XNn_model_top *InstancePtr);
void XNn_model_top_DisableAutoRestart(XNn_model_top *InstancePtr);
u32 XNn_model_top_Get_return(XNn_model_top *InstancePtr);

void XNn_model_top_Set_Input1_input1(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Input1_input1(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Input2_input2(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Input2_input2(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_633_conv2d_633(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_633_conv2d_633(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_635_conv2d_635(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_635_conv2d_635(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_537_max_pooling2d_537(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_537_max_pooling2d_537(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_538_max_pooling2d_538(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_538_max_pooling2d_538(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_521_dense_521(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_521_dense_521(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_522_dense_522(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_522_dense_522(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_634_conv2d_634(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_634_conv2d_634(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_636_conv2d_636(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_636_conv2d_636(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Concatenate_116_concatenate_116(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Concatenate_116_concatenate_116(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_637_conv2d_637(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_637_conv2d_637(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_539_max_pooling2d_539(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_539_max_pooling2d_539(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_638_conv2d_638(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_638_conv2d_638(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_540_max_pooling2d_540(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_540_max_pooling2d_540(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_523_dense_523(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_523_dense_523(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_524_dense_524(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_524_dense_524(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_525_dense_525(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_525_dense_525(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_527_dense_527(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_527_dense_527(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_526_dense_526(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_526_dense_526(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_528_dense_528(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_528_dense_528(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Concatenate_117_concatenate_117(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Concatenate_117_concatenate_117(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_529_dense_529(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_529_dense_529(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_530_dense_530(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_530_dense_530(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Flatten_60_flatten_60(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Flatten_60_flatten_60(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_531_dense_531(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_531_dense_531(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_532_dense_532(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_532_dense_532(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_533_dense_533(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_533_dense_533(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_633_weight_conv2d_633_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_633_weight_conv2d_633_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_633_bias_conv2d_633_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_633_bias_conv2d_633_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_635_weight_conv2d_635_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_635_weight_conv2d_635_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_635_bias_conv2d_635_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_635_bias_conv2d_635_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_521_weight_dense_521_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_521_weight_dense_521_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_521_bias_dense_521_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_521_bias_dense_521_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_522_weight_dense_522_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_522_weight_dense_522_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_522_bias_dense_522_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_522_bias_dense_522_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_634_weight_conv2d_634_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_634_weight_conv2d_634_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_634_bias_conv2d_634_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_634_bias_conv2d_634_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_636_weight_conv2d_636_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_636_weight_conv2d_636_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_636_bias_conv2d_636_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_636_bias_conv2d_636_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_637_weight_conv2d_637_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_637_weight_conv2d_637_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_637_bias_conv2d_637_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_637_bias_conv2d_637_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_638_weight_conv2d_638_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_638_weight_conv2d_638_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_638_bias_conv2d_638_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_638_bias_conv2d_638_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_523_weight_dense_523_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_523_weight_dense_523_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_523_bias_dense_523_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_523_bias_dense_523_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_524_weight_dense_524_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_524_weight_dense_524_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_524_bias_dense_524_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_524_bias_dense_524_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_525_weight_dense_525_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_525_weight_dense_525_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_525_bias_dense_525_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_525_bias_dense_525_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_527_weight_dense_527_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_527_weight_dense_527_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_527_bias_dense_527_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_527_bias_dense_527_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_526_weight_dense_526_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_526_weight_dense_526_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_526_bias_dense_526_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_526_bias_dense_526_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_528_weight_dense_528_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_528_weight_dense_528_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_528_bias_dense_528_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_528_bias_dense_528_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_529_weight_dense_529_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_529_weight_dense_529_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_529_bias_dense_529_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_529_bias_dense_529_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_530_weight_dense_530_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_530_weight_dense_530_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_530_bias_dense_530_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_530_bias_dense_530_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_531_weight_dense_531_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_531_weight_dense_531_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_531_bias_dense_531_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_531_bias_dense_531_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_532_weight_dense_532_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_532_weight_dense_532_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_532_bias_dense_532_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_532_bias_dense_532_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_533_weight_dense_533_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_533_weight_dense_533_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_533_bias_dense_533_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_533_bias_dense_533_bias(XNn_model_top *InstancePtr);

void XNn_model_top_InterruptGlobalEnable(XNn_model_top *InstancePtr);
void XNn_model_top_InterruptGlobalDisable(XNn_model_top *InstancePtr);
void XNn_model_top_InterruptEnable(XNn_model_top *InstancePtr, u32 Mask);
void XNn_model_top_InterruptDisable(XNn_model_top *InstancePtr, u32 Mask);
void XNn_model_top_InterruptClear(XNn_model_top *InstancePtr, u32 Mask);
u32 XNn_model_top_InterruptGetEnabled(XNn_model_top *InstancePtr);
u32 XNn_model_top_InterruptGetStatus(XNn_model_top *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
