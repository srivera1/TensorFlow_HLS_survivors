// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2019.2.1 (64-bit)
// Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
// ==============================================================
/***************************** Include Files *********************************/
#include "xnn_model_top.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XNn_model_top_CfgInitialize(XNn_model_top *InstancePtr, XNn_model_top_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XNn_model_top_Start(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_AP_CTRL) & 0x80;
    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XNn_model_top_IsDone(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XNn_model_top_IsIdle(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XNn_model_top_IsReady(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XNn_model_top_EnableAutoRestart(XNn_model_top *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XNn_model_top_DisableAutoRestart(XNn_model_top *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_AP_CTRL, 0);
}

u32 XNn_model_top_Get_return(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_AP_RETURN);
    return Data;
}
void XNn_model_top_Set_Input1_input1(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_INPUT1_INPUT1_DATA, Data);
}

u32 XNn_model_top_Get_Input1_input1(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_INPUT1_INPUT1_DATA);
    return Data;
}

void XNn_model_top_Set_Input2_input2(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_INPUT2_INPUT2_DATA, Data);
}

u32 XNn_model_top_Get_Input2_input2(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_INPUT2_INPUT2_DATA);
    return Data;
}

void XNn_model_top_Set_Conv2d_2652_conv2d_2652(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_2652_CONV2D_2652_DATA, Data);
}

u32 XNn_model_top_Get_Conv2d_2652_conv2d_2652(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_2652_CONV2D_2652_DATA);
    return Data;
}

void XNn_model_top_Set_Conv2d_2654_conv2d_2654(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_2654_CONV2D_2654_DATA, Data);
}

u32 XNn_model_top_Get_Conv2d_2654_conv2d_2654(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_2654_CONV2D_2654_DATA);
    return Data;
}

void XNn_model_top_Set_Max_pooling2d_2233_max_pooling2d_2233(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_MAX_POOLING2D_2233_MAX_POOLING2D_2233_DATA, Data);
}

u32 XNn_model_top_Get_Max_pooling2d_2233_max_pooling2d_2233(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_MAX_POOLING2D_2233_MAX_POOLING2D_2233_DATA);
    return Data;
}

void XNn_model_top_Set_Max_pooling2d_2235_max_pooling2d_2235(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_MAX_POOLING2D_2235_MAX_POOLING2D_2235_DATA, Data);
}

u32 XNn_model_top_Get_Max_pooling2d_2235_max_pooling2d_2235(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_MAX_POOLING2D_2235_MAX_POOLING2D_2235_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_2150_dense_2150(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_2150_DENSE_2150_DATA, Data);
}

u32 XNn_model_top_Get_Dense_2150_dense_2150(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_2150_DENSE_2150_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_2152_dense_2152(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_2152_DENSE_2152_DATA, Data);
}

u32 XNn_model_top_Get_Dense_2152_dense_2152(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_2152_DENSE_2152_DATA);
    return Data;
}

void XNn_model_top_Set_Conv2d_2653_conv2d_2653(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_2653_CONV2D_2653_DATA, Data);
}

u32 XNn_model_top_Get_Conv2d_2653_conv2d_2653(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_2653_CONV2D_2653_DATA);
    return Data;
}

void XNn_model_top_Set_Conv2d_2655_conv2d_2655(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_2655_CONV2D_2655_DATA, Data);
}

u32 XNn_model_top_Get_Conv2d_2655_conv2d_2655(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_2655_CONV2D_2655_DATA);
    return Data;
}

void XNn_model_top_Set_Max_pooling2d_2234_max_pooling2d_2234(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_MAX_POOLING2D_2234_MAX_POOLING2D_2234_DATA, Data);
}

u32 XNn_model_top_Get_Max_pooling2d_2234_max_pooling2d_2234(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_MAX_POOLING2D_2234_MAX_POOLING2D_2234_DATA);
    return Data;
}

void XNn_model_top_Set_Max_pooling2d_2236_max_pooling2d_2236(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_MAX_POOLING2D_2236_MAX_POOLING2D_2236_DATA, Data);
}

u32 XNn_model_top_Get_Max_pooling2d_2236_max_pooling2d_2236(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_MAX_POOLING2D_2236_MAX_POOLING2D_2236_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_2151_dense_2151(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_2151_DENSE_2151_DATA, Data);
}

u32 XNn_model_top_Get_Dense_2151_dense_2151(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_2151_DENSE_2151_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_2153_dense_2153(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_2153_DENSE_2153_DATA, Data);
}

u32 XNn_model_top_Get_Dense_2153_dense_2153(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_2153_DENSE_2153_DATA);
    return Data;
}

void XNn_model_top_Set_Concatenate_467_concatenate_467(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONCATENATE_467_CONCATENATE_467_DATA, Data);
}

u32 XNn_model_top_Get_Concatenate_467_concatenate_467(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONCATENATE_467_CONCATENATE_467_DATA);
    return Data;
}

void XNn_model_top_Set_Conv2d_2656_conv2d_2656(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_2656_CONV2D_2656_DATA, Data);
}

u32 XNn_model_top_Get_Conv2d_2656_conv2d_2656(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_2656_CONV2D_2656_DATA);
    return Data;
}

void XNn_model_top_Set_Conv2d_2657_conv2d_2657(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_2657_CONV2D_2657_DATA, Data);
}

u32 XNn_model_top_Get_Conv2d_2657_conv2d_2657(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_2657_CONV2D_2657_DATA);
    return Data;
}

void XNn_model_top_Set_Max_pooling2d_2237_max_pooling2d_2237(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_MAX_POOLING2D_2237_MAX_POOLING2D_2237_DATA, Data);
}

u32 XNn_model_top_Get_Max_pooling2d_2237_max_pooling2d_2237(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_MAX_POOLING2D_2237_MAX_POOLING2D_2237_DATA);
    return Data;
}

void XNn_model_top_Set_Max_pooling2d_2238_max_pooling2d_2238(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_MAX_POOLING2D_2238_MAX_POOLING2D_2238_DATA, Data);
}

u32 XNn_model_top_Get_Max_pooling2d_2238_max_pooling2d_2238(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_MAX_POOLING2D_2238_MAX_POOLING2D_2238_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_2154_dense_2154(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_2154_DENSE_2154_DATA, Data);
}

u32 XNn_model_top_Get_Dense_2154_dense_2154(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_2154_DENSE_2154_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_2155_dense_2155(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_2155_DENSE_2155_DATA, Data);
}

u32 XNn_model_top_Get_Dense_2155_dense_2155(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_2155_DENSE_2155_DATA);
    return Data;
}

void XNn_model_top_Set_Concatenate_468_concatenate_468(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONCATENATE_468_CONCATENATE_468_DATA, Data);
}

u32 XNn_model_top_Get_Concatenate_468_concatenate_468(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONCATENATE_468_CONCATENATE_468_DATA);
    return Data;
}

void XNn_model_top_Set_Max_pooling2d_2239_max_pooling2d_2239(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_MAX_POOLING2D_2239_MAX_POOLING2D_2239_DATA, Data);
}

u32 XNn_model_top_Get_Max_pooling2d_2239_max_pooling2d_2239(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_MAX_POOLING2D_2239_MAX_POOLING2D_2239_DATA);
    return Data;
}

void XNn_model_top_Set_Flatten_240_flatten_240(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_FLATTEN_240_FLATTEN_240_DATA, Data);
}

u32 XNn_model_top_Get_Flatten_240_flatten_240(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_FLATTEN_240_FLATTEN_240_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_2156_dense_2156(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_2156_DENSE_2156_DATA, Data);
}

u32 XNn_model_top_Get_Dense_2156_dense_2156(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_2156_DENSE_2156_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_2157_dense_2157(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_2157_DENSE_2157_DATA, Data);
}

u32 XNn_model_top_Get_Dense_2157_dense_2157(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_2157_DENSE_2157_DATA);
    return Data;
}

void XNn_model_top_Set_Conv2d_2652_weight_conv2d_2652_weight(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_2652_WEIGHT_CONV2D_2652_WEIGHT_DATA, Data);
}

u32 XNn_model_top_Get_Conv2d_2652_weight_conv2d_2652_weight(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_2652_WEIGHT_CONV2D_2652_WEIGHT_DATA);
    return Data;
}

void XNn_model_top_Set_Conv2d_2652_bias_conv2d_2652_bias(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_2652_BIAS_CONV2D_2652_BIAS_DATA, Data);
}

u32 XNn_model_top_Get_Conv2d_2652_bias_conv2d_2652_bias(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_2652_BIAS_CONV2D_2652_BIAS_DATA);
    return Data;
}

void XNn_model_top_Set_Conv2d_2654_weight_conv2d_2654_weight(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_2654_WEIGHT_CONV2D_2654_WEIGHT_DATA, Data);
}

u32 XNn_model_top_Get_Conv2d_2654_weight_conv2d_2654_weight(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_2654_WEIGHT_CONV2D_2654_WEIGHT_DATA);
    return Data;
}

void XNn_model_top_Set_Conv2d_2654_bias_conv2d_2654_bias(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_2654_BIAS_CONV2D_2654_BIAS_DATA, Data);
}

u32 XNn_model_top_Get_Conv2d_2654_bias_conv2d_2654_bias(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_2654_BIAS_CONV2D_2654_BIAS_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_2150_weight_dense_2150_weight(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_2150_WEIGHT_DENSE_2150_WEIGHT_DATA, Data);
}

u32 XNn_model_top_Get_Dense_2150_weight_dense_2150_weight(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_2150_WEIGHT_DENSE_2150_WEIGHT_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_2150_bias_dense_2150_bias(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_2150_BIAS_DENSE_2150_BIAS_DATA, Data);
}

u32 XNn_model_top_Get_Dense_2150_bias_dense_2150_bias(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_2150_BIAS_DENSE_2150_BIAS_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_2152_weight_dense_2152_weight(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_2152_WEIGHT_DENSE_2152_WEIGHT_DATA, Data);
}

u32 XNn_model_top_Get_Dense_2152_weight_dense_2152_weight(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_2152_WEIGHT_DENSE_2152_WEIGHT_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_2152_bias_dense_2152_bias(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_2152_BIAS_DENSE_2152_BIAS_DATA, Data);
}

u32 XNn_model_top_Get_Dense_2152_bias_dense_2152_bias(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_2152_BIAS_DENSE_2152_BIAS_DATA);
    return Data;
}

void XNn_model_top_Set_Conv2d_2653_weight_conv2d_2653_weight(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_2653_WEIGHT_CONV2D_2653_WEIGHT_DATA, Data);
}

u32 XNn_model_top_Get_Conv2d_2653_weight_conv2d_2653_weight(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_2653_WEIGHT_CONV2D_2653_WEIGHT_DATA);
    return Data;
}

void XNn_model_top_Set_Conv2d_2653_bias_conv2d_2653_bias(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_2653_BIAS_CONV2D_2653_BIAS_DATA, Data);
}

u32 XNn_model_top_Get_Conv2d_2653_bias_conv2d_2653_bias(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_2653_BIAS_CONV2D_2653_BIAS_DATA);
    return Data;
}

void XNn_model_top_Set_Conv2d_2655_weight_conv2d_2655_weight(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_2655_WEIGHT_CONV2D_2655_WEIGHT_DATA, Data);
}

u32 XNn_model_top_Get_Conv2d_2655_weight_conv2d_2655_weight(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_2655_WEIGHT_CONV2D_2655_WEIGHT_DATA);
    return Data;
}

void XNn_model_top_Set_Conv2d_2655_bias_conv2d_2655_bias(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_2655_BIAS_CONV2D_2655_BIAS_DATA, Data);
}

u32 XNn_model_top_Get_Conv2d_2655_bias_conv2d_2655_bias(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_2655_BIAS_CONV2D_2655_BIAS_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_2151_weight_dense_2151_weight(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_2151_WEIGHT_DENSE_2151_WEIGHT_DATA, Data);
}

u32 XNn_model_top_Get_Dense_2151_weight_dense_2151_weight(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_2151_WEIGHT_DENSE_2151_WEIGHT_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_2151_bias_dense_2151_bias(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_2151_BIAS_DENSE_2151_BIAS_DATA, Data);
}

u32 XNn_model_top_Get_Dense_2151_bias_dense_2151_bias(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_2151_BIAS_DENSE_2151_BIAS_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_2153_weight_dense_2153_weight(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_2153_WEIGHT_DENSE_2153_WEIGHT_DATA, Data);
}

u32 XNn_model_top_Get_Dense_2153_weight_dense_2153_weight(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_2153_WEIGHT_DENSE_2153_WEIGHT_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_2153_bias_dense_2153_bias(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_2153_BIAS_DENSE_2153_BIAS_DATA, Data);
}

u32 XNn_model_top_Get_Dense_2153_bias_dense_2153_bias(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_2153_BIAS_DENSE_2153_BIAS_DATA);
    return Data;
}

void XNn_model_top_Set_Conv2d_2656_weight_conv2d_2656_weight(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_2656_WEIGHT_CONV2D_2656_WEIGHT_DATA, Data);
}

u32 XNn_model_top_Get_Conv2d_2656_weight_conv2d_2656_weight(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_2656_WEIGHT_CONV2D_2656_WEIGHT_DATA);
    return Data;
}

void XNn_model_top_Set_Conv2d_2656_bias_conv2d_2656_bias(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_2656_BIAS_CONV2D_2656_BIAS_DATA, Data);
}

u32 XNn_model_top_Get_Conv2d_2656_bias_conv2d_2656_bias(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_2656_BIAS_CONV2D_2656_BIAS_DATA);
    return Data;
}

void XNn_model_top_Set_Conv2d_2657_weight_conv2d_2657_weight(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_2657_WEIGHT_CONV2D_2657_WEIGHT_DATA, Data);
}

u32 XNn_model_top_Get_Conv2d_2657_weight_conv2d_2657_weight(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_2657_WEIGHT_CONV2D_2657_WEIGHT_DATA);
    return Data;
}

void XNn_model_top_Set_Conv2d_2657_bias_conv2d_2657_bias(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_2657_BIAS_CONV2D_2657_BIAS_DATA, Data);
}

u32 XNn_model_top_Get_Conv2d_2657_bias_conv2d_2657_bias(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_2657_BIAS_CONV2D_2657_BIAS_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_2154_weight_dense_2154_weight(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_2154_WEIGHT_DENSE_2154_WEIGHT_DATA, Data);
}

u32 XNn_model_top_Get_Dense_2154_weight_dense_2154_weight(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_2154_WEIGHT_DENSE_2154_WEIGHT_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_2154_bias_dense_2154_bias(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_2154_BIAS_DENSE_2154_BIAS_DATA, Data);
}

u32 XNn_model_top_Get_Dense_2154_bias_dense_2154_bias(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_2154_BIAS_DENSE_2154_BIAS_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_2155_weight_dense_2155_weight(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_2155_WEIGHT_DENSE_2155_WEIGHT_DATA, Data);
}

u32 XNn_model_top_Get_Dense_2155_weight_dense_2155_weight(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_2155_WEIGHT_DENSE_2155_WEIGHT_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_2155_bias_dense_2155_bias(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_2155_BIAS_DENSE_2155_BIAS_DATA, Data);
}

u32 XNn_model_top_Get_Dense_2155_bias_dense_2155_bias(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_2155_BIAS_DENSE_2155_BIAS_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_2156_weight_dense_2156_weight(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_2156_WEIGHT_DENSE_2156_WEIGHT_DATA, Data);
}

u32 XNn_model_top_Get_Dense_2156_weight_dense_2156_weight(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_2156_WEIGHT_DENSE_2156_WEIGHT_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_2156_bias_dense_2156_bias(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_2156_BIAS_DENSE_2156_BIAS_DATA, Data);
}

u32 XNn_model_top_Get_Dense_2156_bias_dense_2156_bias(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_2156_BIAS_DENSE_2156_BIAS_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_2157_weight_dense_2157_weight(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_2157_WEIGHT_DENSE_2157_WEIGHT_DATA, Data);
}

u32 XNn_model_top_Get_Dense_2157_weight_dense_2157_weight(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_2157_WEIGHT_DENSE_2157_WEIGHT_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_2157_bias_dense_2157_bias(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_2157_BIAS_DENSE_2157_BIAS_DATA, Data);
}

u32 XNn_model_top_Get_Dense_2157_bias_dense_2157_bias(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_2157_BIAS_DENSE_2157_BIAS_DATA);
    return Data;
}

void XNn_model_top_InterruptGlobalEnable(XNn_model_top *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_GIE, 1);
}

void XNn_model_top_InterruptGlobalDisable(XNn_model_top *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_GIE, 0);
}

void XNn_model_top_InterruptEnable(XNn_model_top *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_IER);
    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_IER, Register | Mask);
}

void XNn_model_top_InterruptDisable(XNn_model_top *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_IER);
    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_IER, Register & (~Mask));
}

void XNn_model_top_InterruptClear(XNn_model_top *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_ISR, Mask);
}

u32 XNn_model_top_InterruptGetEnabled(XNn_model_top *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_IER);
}

u32 XNn_model_top_InterruptGetStatus(XNn_model_top *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_ISR);
}

