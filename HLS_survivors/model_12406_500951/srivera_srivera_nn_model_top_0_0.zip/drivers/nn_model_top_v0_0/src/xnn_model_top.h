// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2019.2.1 (64-bit)
// Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef XNN_MODEL_TOP_H
#define XNN_MODEL_TOP_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xnn_model_top_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
#else
typedef struct {
    u16 DeviceId;
    u32 Control_BaseAddress;
} XNn_model_top_Config;
#endif

typedef struct {
    u32 Control_BaseAddress;
    u32 IsReady;
} XNn_model_top;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XNn_model_top_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XNn_model_top_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XNn_model_top_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XNn_model_top_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
int XNn_model_top_Initialize(XNn_model_top *InstancePtr, u16 DeviceId);
XNn_model_top_Config* XNn_model_top_LookupConfig(u16 DeviceId);
int XNn_model_top_CfgInitialize(XNn_model_top *InstancePtr, XNn_model_top_Config *ConfigPtr);
#else
int XNn_model_top_Initialize(XNn_model_top *InstancePtr, const char* InstanceName);
int XNn_model_top_Release(XNn_model_top *InstancePtr);
#endif

void XNn_model_top_Start(XNn_model_top *InstancePtr);
u32 XNn_model_top_IsDone(XNn_model_top *InstancePtr);
u32 XNn_model_top_IsIdle(XNn_model_top *InstancePtr);
u32 XNn_model_top_IsReady(XNn_model_top *InstancePtr);
void XNn_model_top_EnableAutoRestart(XNn_model_top *InstancePtr);
void XNn_model_top_DisableAutoRestart(XNn_model_top *InstancePtr);
u32 XNn_model_top_Get_return(XNn_model_top *InstancePtr);

void XNn_model_top_Set_Input1_input1(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Input1_input1(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Input2_input2(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Input2_input2(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3346_conv2d_3346(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3346_conv2d_3346(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3349_conv2d_3349(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3349_conv2d_3349(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_2823_max_pooling2d_2823(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_2823_max_pooling2d_2823(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_2825_max_pooling2d_2825(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_2825_max_pooling2d_2825(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2701_dense_2701(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2701_dense_2701(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2703_dense_2703(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2703_dense_2703(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3347_conv2d_3347(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3347_conv2d_3347(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3350_conv2d_3350(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3350_conv2d_3350(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_2824_max_pooling2d_2824(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_2824_max_pooling2d_2824(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_2826_max_pooling2d_2826(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_2826_max_pooling2d_2826(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2702_dense_2702(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2702_dense_2702(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2704_dense_2704(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2704_dense_2704(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3348_conv2d_3348(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3348_conv2d_3348(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3351_conv2d_3351(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3351_conv2d_3351(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Concatenate_584_concatenate_584(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Concatenate_584_concatenate_584(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3352_conv2d_3352(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3352_conv2d_3352(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_2827_max_pooling2d_2827(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_2827_max_pooling2d_2827(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2705_dense_2705(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2705_dense_2705(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2706_dense_2706(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2706_dense_2706(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2707_dense_2707(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2707_dense_2707(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2708_dense_2708(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2708_dense_2708(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Flatten_300_flatten_300(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Flatten_300_flatten_300(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2709_dense_2709(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2709_dense_2709(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2710_dense_2710(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2710_dense_2710(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3346_weight_conv2d_3346_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3346_weight_conv2d_3346_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3346_bias_conv2d_3346_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3346_bias_conv2d_3346_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3349_weight_conv2d_3349_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3349_weight_conv2d_3349_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3349_bias_conv2d_3349_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3349_bias_conv2d_3349_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2701_weight_dense_2701_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2701_weight_dense_2701_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2701_bias_dense_2701_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2701_bias_dense_2701_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2703_weight_dense_2703_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2703_weight_dense_2703_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2703_bias_dense_2703_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2703_bias_dense_2703_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3347_weight_conv2d_3347_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3347_weight_conv2d_3347_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3347_bias_conv2d_3347_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3347_bias_conv2d_3347_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3350_weight_conv2d_3350_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3350_weight_conv2d_3350_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3350_bias_conv2d_3350_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3350_bias_conv2d_3350_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2702_weight_dense_2702_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2702_weight_dense_2702_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2702_bias_dense_2702_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2702_bias_dense_2702_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2704_weight_dense_2704_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2704_weight_dense_2704_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2704_bias_dense_2704_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2704_bias_dense_2704_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3348_weight_conv2d_3348_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3348_weight_conv2d_3348_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3348_bias_conv2d_3348_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3348_bias_conv2d_3348_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3351_weight_conv2d_3351_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3351_weight_conv2d_3351_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3351_bias_conv2d_3351_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3351_bias_conv2d_3351_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3352_weight_conv2d_3352_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3352_weight_conv2d_3352_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3352_bias_conv2d_3352_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3352_bias_conv2d_3352_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2705_weight_dense_2705_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2705_weight_dense_2705_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2705_bias_dense_2705_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2705_bias_dense_2705_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2706_weight_dense_2706_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2706_weight_dense_2706_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2706_bias_dense_2706_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2706_bias_dense_2706_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2707_weight_dense_2707_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2707_weight_dense_2707_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2707_bias_dense_2707_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2707_bias_dense_2707_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2708_weight_dense_2708_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2708_weight_dense_2708_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2708_bias_dense_2708_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2708_bias_dense_2708_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2709_weight_dense_2709_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2709_weight_dense_2709_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2709_bias_dense_2709_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2709_bias_dense_2709_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2710_weight_dense_2710_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2710_weight_dense_2710_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2710_bias_dense_2710_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2710_bias_dense_2710_bias(XNn_model_top *InstancePtr);

void XNn_model_top_InterruptGlobalEnable(XNn_model_top *InstancePtr);
void XNn_model_top_InterruptGlobalDisable(XNn_model_top *InstancePtr);
void XNn_model_top_InterruptEnable(XNn_model_top *InstancePtr, u32 Mask);
void XNn_model_top_InterruptDisable(XNn_model_top *InstancePtr, u32 Mask);
void XNn_model_top_InterruptClear(XNn_model_top *InstancePtr, u32 Mask);
u32 XNn_model_top_InterruptGetEnabled(XNn_model_top *InstancePtr);
u32 XNn_model_top_InterruptGetStatus(XNn_model_top *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
