// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2019.2.1 (64-bit)
// Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef XNN_MODEL_TOP_H
#define XNN_MODEL_TOP_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xnn_model_top_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
#else
typedef struct {
    u16 DeviceId;
    u32 Control_BaseAddress;
} XNn_model_top_Config;
#endif

typedef struct {
    u32 Control_BaseAddress;
    u32 IsReady;
} XNn_model_top;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XNn_model_top_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XNn_model_top_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XNn_model_top_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XNn_model_top_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
int XNn_model_top_Initialize(XNn_model_top *InstancePtr, u16 DeviceId);
XNn_model_top_Config* XNn_model_top_LookupConfig(u16 DeviceId);
int XNn_model_top_CfgInitialize(XNn_model_top *InstancePtr, XNn_model_top_Config *ConfigPtr);
#else
int XNn_model_top_Initialize(XNn_model_top *InstancePtr, const char* InstanceName);
int XNn_model_top_Release(XNn_model_top *InstancePtr);
#endif

void XNn_model_top_Start(XNn_model_top *InstancePtr);
u32 XNn_model_top_IsDone(XNn_model_top *InstancePtr);
u32 XNn_model_top_IsIdle(XNn_model_top *InstancePtr);
u32 XNn_model_top_IsReady(XNn_model_top *InstancePtr);
void XNn_model_top_EnableAutoRestart(XNn_model_top *InstancePtr);
void XNn_model_top_DisableAutoRestart(XNn_model_top *InstancePtr);
u32 XNn_model_top_Get_return(XNn_model_top *InstancePtr);

void XNn_model_top_Set_Input1_input1(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Input1_input1(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Input2_input2(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Input2_input2(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_63_dense_63(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_63_dense_63(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_65_dense_65(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_65_dense_65(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_64_dense_64(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_64_dense_64(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_66_dense_66(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_66_dense_66(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Concatenate_7_concatenate_7(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Concatenate_7_concatenate_7(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_15_conv2d_15(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_15_conv2d_15(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_16_conv2d_16(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_16_conv2d_16(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_10_max_pooling2d_10(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_10_max_pooling2d_10(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_17_conv2d_17(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_17_conv2d_17(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_18_conv2d_18(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_18_conv2d_18(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_11_max_pooling2d_11(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_11_max_pooling2d_11(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_19_conv2d_19(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_19_conv2d_19(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_20_conv2d_20(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_20_conv2d_20(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Flatten_3_flatten_3(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Flatten_3_flatten_3(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_67_dense_67(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_67_dense_67(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_68_dense_68(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_68_dense_68(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_63_weight_dense_63_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_63_weight_dense_63_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_63_bias_dense_63_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_63_bias_dense_63_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_65_weight_dense_65_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_65_weight_dense_65_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_65_bias_dense_65_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_65_bias_dense_65_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_64_weight_dense_64_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_64_weight_dense_64_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_64_bias_dense_64_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_64_bias_dense_64_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_66_weight_dense_66_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_66_weight_dense_66_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_66_bias_dense_66_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_66_bias_dense_66_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_15_weight_conv2d_15_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_15_weight_conv2d_15_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_15_bias_conv2d_15_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_15_bias_conv2d_15_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_16_weight_conv2d_16_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_16_weight_conv2d_16_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_16_bias_conv2d_16_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_16_bias_conv2d_16_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_17_weight_conv2d_17_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_17_weight_conv2d_17_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_17_bias_conv2d_17_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_17_bias_conv2d_17_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_18_weight_conv2d_18_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_18_weight_conv2d_18_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_18_bias_conv2d_18_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_18_bias_conv2d_18_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_19_weight_conv2d_19_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_19_weight_conv2d_19_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_19_bias_conv2d_19_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_19_bias_conv2d_19_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_20_weight_conv2d_20_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_20_weight_conv2d_20_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_20_bias_conv2d_20_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_20_bias_conv2d_20_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_67_weight_dense_67_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_67_weight_dense_67_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_67_bias_dense_67_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_67_bias_dense_67_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_68_weight_dense_68_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_68_weight_dense_68_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_68_bias_dense_68_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_68_bias_dense_68_bias(XNn_model_top *InstancePtr);

void XNn_model_top_InterruptGlobalEnable(XNn_model_top *InstancePtr);
void XNn_model_top_InterruptGlobalDisable(XNn_model_top *InstancePtr);
void XNn_model_top_InterruptEnable(XNn_model_top *InstancePtr, u32 Mask);
void XNn_model_top_InterruptDisable(XNn_model_top *InstancePtr, u32 Mask);
void XNn_model_top_InterruptClear(XNn_model_top *InstancePtr, u32 Mask);
u32 XNn_model_top_InterruptGetEnabled(XNn_model_top *InstancePtr);
u32 XNn_model_top_InterruptGetStatus(XNn_model_top *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
