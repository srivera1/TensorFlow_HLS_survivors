// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2019.2.1 (64-bit)
// Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef XNN_MODEL_TOP_H
#define XNN_MODEL_TOP_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xnn_model_top_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
#else
typedef struct {
    u16 DeviceId;
    u32 Control_BaseAddress;
} XNn_model_top_Config;
#endif

typedef struct {
    u32 Control_BaseAddress;
    u32 IsReady;
} XNn_model_top;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XNn_model_top_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XNn_model_top_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XNn_model_top_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XNn_model_top_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
int XNn_model_top_Initialize(XNn_model_top *InstancePtr, u16 DeviceId);
XNn_model_top_Config* XNn_model_top_LookupConfig(u16 DeviceId);
int XNn_model_top_CfgInitialize(XNn_model_top *InstancePtr, XNn_model_top_Config *ConfigPtr);
#else
int XNn_model_top_Initialize(XNn_model_top *InstancePtr, const char* InstanceName);
int XNn_model_top_Release(XNn_model_top *InstancePtr);
#endif

void XNn_model_top_Start(XNn_model_top *InstancePtr);
u32 XNn_model_top_IsDone(XNn_model_top *InstancePtr);
u32 XNn_model_top_IsIdle(XNn_model_top *InstancePtr);
u32 XNn_model_top_IsReady(XNn_model_top *InstancePtr);
void XNn_model_top_EnableAutoRestart(XNn_model_top *InstancePtr);
void XNn_model_top_DisableAutoRestart(XNn_model_top *InstancePtr);
u32 XNn_model_top_Get_return(XNn_model_top *InstancePtr);

void XNn_model_top_Set_Input1_input1(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Input1_input1(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Input2_input2(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Input2_input2(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_895_conv2d_895(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_895_conv2d_895(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_897_conv2d_897(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_897_conv2d_897(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_762_max_pooling2d_762(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_762_max_pooling2d_762(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_763_max_pooling2d_763(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_763_max_pooling2d_763(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_744_dense_744(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_744_dense_744(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_745_dense_745(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_745_dense_745(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_896_conv2d_896(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_896_conv2d_896(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_898_conv2d_898(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_898_conv2d_898(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Concatenate_159_concatenate_159(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Concatenate_159_concatenate_159(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_904_conv2d_904(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_904_conv2d_904(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_902_conv2d_902(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_902_conv2d_902(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_768_max_pooling2d_768(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_768_max_pooling2d_768(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_766_max_pooling2d_766(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_766_max_pooling2d_766(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_749_dense_749(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_749_dense_749(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_903_conv2d_903(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_903_conv2d_903(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_905_conv2d_905(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_905_conv2d_905(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_767_max_pooling2d_767(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_767_max_pooling2d_767(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_769_max_pooling2d_769(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_769_max_pooling2d_769(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_748_dense_748(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_748_dense_748(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_750_dense_750(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_750_dense_750(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Concatenate_161_concatenate_161(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Concatenate_161_concatenate_161(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Flatten_85_flatten_85(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Flatten_85_flatten_85(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_751_dense_751(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_751_dense_751(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_752_dense_752(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_752_dense_752(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_895_weight_conv2d_895_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_895_weight_conv2d_895_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_895_bias_conv2d_895_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_895_bias_conv2d_895_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_897_weight_conv2d_897_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_897_weight_conv2d_897_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_897_bias_conv2d_897_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_897_bias_conv2d_897_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_744_weight_dense_744_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_744_weight_dense_744_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_744_bias_dense_744_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_744_bias_dense_744_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_745_weight_dense_745_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_745_weight_dense_745_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_745_bias_dense_745_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_745_bias_dense_745_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_896_weight_conv2d_896_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_896_weight_conv2d_896_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_896_bias_conv2d_896_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_896_bias_conv2d_896_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_898_weight_conv2d_898_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_898_weight_conv2d_898_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_898_bias_conv2d_898_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_898_bias_conv2d_898_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_904_weight_conv2d_904_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_904_weight_conv2d_904_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_904_bias_conv2d_904_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_904_bias_conv2d_904_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_902_weight_conv2d_902_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_902_weight_conv2d_902_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_902_bias_conv2d_902_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_902_bias_conv2d_902_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_749_weight_dense_749_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_749_weight_dense_749_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_749_bias_dense_749_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_749_bias_dense_749_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_903_weight_conv2d_903_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_903_weight_conv2d_903_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_903_bias_conv2d_903_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_903_bias_conv2d_903_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_905_weight_conv2d_905_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_905_weight_conv2d_905_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_905_bias_conv2d_905_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_905_bias_conv2d_905_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_748_weight_dense_748_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_748_weight_dense_748_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_748_bias_dense_748_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_748_bias_dense_748_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_750_weight_dense_750_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_750_weight_dense_750_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_750_bias_dense_750_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_750_bias_dense_750_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_751_weight_dense_751_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_751_weight_dense_751_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_751_bias_dense_751_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_751_bias_dense_751_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_752_weight_dense_752_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_752_weight_dense_752_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_752_bias_dense_752_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_752_bias_dense_752_bias(XNn_model_top *InstancePtr);

void XNn_model_top_InterruptGlobalEnable(XNn_model_top *InstancePtr);
void XNn_model_top_InterruptGlobalDisable(XNn_model_top *InstancePtr);
void XNn_model_top_InterruptEnable(XNn_model_top *InstancePtr, u32 Mask);
void XNn_model_top_InterruptDisable(XNn_model_top *InstancePtr, u32 Mask);
void XNn_model_top_InterruptClear(XNn_model_top *InstancePtr, u32 Mask);
u32 XNn_model_top_InterruptGetEnabled(XNn_model_top *InstancePtr);
u32 XNn_model_top_InterruptGetStatus(XNn_model_top *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
