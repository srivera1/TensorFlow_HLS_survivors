// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2019.2.1 (64-bit)
// Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef XNN_MODEL_TOP_H
#define XNN_MODEL_TOP_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xnn_model_top_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
#else
typedef struct {
    u16 DeviceId;
    u32 Control_BaseAddress;
} XNn_model_top_Config;
#endif

typedef struct {
    u32 Control_BaseAddress;
    u32 IsReady;
} XNn_model_top;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XNn_model_top_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XNn_model_top_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XNn_model_top_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XNn_model_top_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
int XNn_model_top_Initialize(XNn_model_top *InstancePtr, u16 DeviceId);
XNn_model_top_Config* XNn_model_top_LookupConfig(u16 DeviceId);
int XNn_model_top_CfgInitialize(XNn_model_top *InstancePtr, XNn_model_top_Config *ConfigPtr);
#else
int XNn_model_top_Initialize(XNn_model_top *InstancePtr, const char* InstanceName);
int XNn_model_top_Release(XNn_model_top *InstancePtr);
#endif

void XNn_model_top_Start(XNn_model_top *InstancePtr);
u32 XNn_model_top_IsDone(XNn_model_top *InstancePtr);
u32 XNn_model_top_IsIdle(XNn_model_top *InstancePtr);
u32 XNn_model_top_IsReady(XNn_model_top *InstancePtr);
void XNn_model_top_EnableAutoRestart(XNn_model_top *InstancePtr);
void XNn_model_top_DisableAutoRestart(XNn_model_top *InstancePtr);
u32 XNn_model_top_Get_return(XNn_model_top *InstancePtr);

void XNn_model_top_Set_Input1_input1(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Input1_input1(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Input2_input2(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Input2_input2(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3509_conv2d_3509(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3509_conv2d_3509(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3515_conv2d_3515(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3515_conv2d_3515(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_2810_max_pooling2d_2810(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_2810_max_pooling2d_2810(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_2815_max_pooling2d_2815(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_2815_max_pooling2d_2815(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2629_dense_2629(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2629_dense_2629(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2633_dense_2633(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2633_dense_2633(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3510_conv2d_3510(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3510_conv2d_3510(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3516_conv2d_3516(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3516_conv2d_3516(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_2811_max_pooling2d_2811(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_2811_max_pooling2d_2811(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_2816_max_pooling2d_2816(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_2816_max_pooling2d_2816(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2630_dense_2630(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2630_dense_2630(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2634_dense_2634(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2634_dense_2634(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3511_conv2d_3511(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3511_conv2d_3511(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3517_conv2d_3517(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3517_conv2d_3517(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_2812_max_pooling2d_2812(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_2812_max_pooling2d_2812(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_2817_max_pooling2d_2817(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_2817_max_pooling2d_2817(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2631_dense_2631(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2631_dense_2631(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_2818_max_pooling2d_2818(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_2818_max_pooling2d_2818(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_2813_max_pooling2d_2813(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_2813_max_pooling2d_2813(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2635_dense_2635(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2635_dense_2635(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2632_dense_2632(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2632_dense_2632(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2636_dense_2636(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2636_dense_2636(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Concatenate_275_concatenate_275(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Concatenate_275_concatenate_275(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Flatten_98_flatten_98(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Flatten_98_flatten_98(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2637_dense_2637(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2637_dense_2637(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2638_dense_2638(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2638_dense_2638(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3509_weight_conv2d_3509_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3509_weight_conv2d_3509_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3509_bias_conv2d_3509_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3509_bias_conv2d_3509_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3515_weight_conv2d_3515_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3515_weight_conv2d_3515_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3515_bias_conv2d_3515_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3515_bias_conv2d_3515_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2629_weight_dense_2629_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2629_weight_dense_2629_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2629_bias_dense_2629_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2629_bias_dense_2629_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2633_weight_dense_2633_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2633_weight_dense_2633_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2633_bias_dense_2633_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2633_bias_dense_2633_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3510_weight_conv2d_3510_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3510_weight_conv2d_3510_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3510_bias_conv2d_3510_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3510_bias_conv2d_3510_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3516_weight_conv2d_3516_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3516_weight_conv2d_3516_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3516_bias_conv2d_3516_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3516_bias_conv2d_3516_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2630_weight_dense_2630_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2630_weight_dense_2630_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2630_bias_dense_2630_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2630_bias_dense_2630_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2634_weight_dense_2634_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2634_weight_dense_2634_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2634_bias_dense_2634_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2634_bias_dense_2634_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3511_weight_conv2d_3511_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3511_weight_conv2d_3511_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3511_bias_conv2d_3511_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3511_bias_conv2d_3511_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3517_weight_conv2d_3517_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3517_weight_conv2d_3517_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3517_bias_conv2d_3517_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3517_bias_conv2d_3517_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2631_weight_dense_2631_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2631_weight_dense_2631_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2631_bias_dense_2631_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2631_bias_dense_2631_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2635_weight_dense_2635_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2635_weight_dense_2635_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2635_bias_dense_2635_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2635_bias_dense_2635_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2632_weight_dense_2632_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2632_weight_dense_2632_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2632_bias_dense_2632_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2632_bias_dense_2632_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2636_weight_dense_2636_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2636_weight_dense_2636_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2636_bias_dense_2636_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2636_bias_dense_2636_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2637_weight_dense_2637_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2637_weight_dense_2637_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2637_bias_dense_2637_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2637_bias_dense_2637_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2638_weight_dense_2638_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2638_weight_dense_2638_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2638_bias_dense_2638_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2638_bias_dense_2638_bias(XNn_model_top *InstancePtr);

void XNn_model_top_InterruptGlobalEnable(XNn_model_top *InstancePtr);
void XNn_model_top_InterruptGlobalDisable(XNn_model_top *InstancePtr);
void XNn_model_top_InterruptEnable(XNn_model_top *InstancePtr, u32 Mask);
void XNn_model_top_InterruptDisable(XNn_model_top *InstancePtr, u32 Mask);
void XNn_model_top_InterruptClear(XNn_model_top *InstancePtr, u32 Mask);
u32 XNn_model_top_InterruptGetEnabled(XNn_model_top *InstancePtr);
u32 XNn_model_top_InterruptGetStatus(XNn_model_top *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
