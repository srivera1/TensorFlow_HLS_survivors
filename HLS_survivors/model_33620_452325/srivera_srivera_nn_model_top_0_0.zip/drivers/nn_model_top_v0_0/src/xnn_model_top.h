// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2019.2.1 (64-bit)
// Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef XNN_MODEL_TOP_H
#define XNN_MODEL_TOP_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xnn_model_top_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
#else
typedef struct {
    u16 DeviceId;
    u32 Control_BaseAddress;
} XNn_model_top_Config;
#endif

typedef struct {
    u32 Control_BaseAddress;
    u32 IsReady;
} XNn_model_top;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XNn_model_top_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XNn_model_top_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XNn_model_top_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XNn_model_top_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
int XNn_model_top_Initialize(XNn_model_top *InstancePtr, u16 DeviceId);
XNn_model_top_Config* XNn_model_top_LookupConfig(u16 DeviceId);
int XNn_model_top_CfgInitialize(XNn_model_top *InstancePtr, XNn_model_top_Config *ConfigPtr);
#else
int XNn_model_top_Initialize(XNn_model_top *InstancePtr, const char* InstanceName);
int XNn_model_top_Release(XNn_model_top *InstancePtr);
#endif

void XNn_model_top_Start(XNn_model_top *InstancePtr);
u32 XNn_model_top_IsDone(XNn_model_top *InstancePtr);
u32 XNn_model_top_IsIdle(XNn_model_top *InstancePtr);
u32 XNn_model_top_IsReady(XNn_model_top *InstancePtr);
void XNn_model_top_EnableAutoRestart(XNn_model_top *InstancePtr);
void XNn_model_top_DisableAutoRestart(XNn_model_top *InstancePtr);
u32 XNn_model_top_Get_return(XNn_model_top *InstancePtr);

void XNn_model_top_Set_Input1_input1(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Input1_input1(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Input2_input2(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Input2_input2(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3240_conv2d_3240(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3240_conv2d_3240(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3243_conv2d_3243(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3243_conv2d_3243(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_2729_max_pooling2d_2729(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_2729_max_pooling2d_2729(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_2731_max_pooling2d_2731(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_2731_max_pooling2d_2731(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2612_dense_2612(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2612_dense_2612(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2614_dense_2614(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2614_dense_2614(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3241_conv2d_3241(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3241_conv2d_3241(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3244_conv2d_3244(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3244_conv2d_3244(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_2730_max_pooling2d_2730(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_2730_max_pooling2d_2730(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_2732_max_pooling2d_2732(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_2732_max_pooling2d_2732(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2613_dense_2613(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2613_dense_2613(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2615_dense_2615(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2615_dense_2615(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3242_conv2d_3242(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3242_conv2d_3242(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3245_conv2d_3245(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3245_conv2d_3245(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Concatenate_570_concatenate_570(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Concatenate_570_concatenate_570(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3246_conv2d_3246(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3246_conv2d_3246(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_2733_max_pooling2d_2733(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_2733_max_pooling2d_2733(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2616_dense_2616(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2616_dense_2616(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2617_dense_2617(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2617_dense_2617(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Flatten_290_flatten_290(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Flatten_290_flatten_290(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2618_dense_2618(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2618_dense_2618(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2619_dense_2619(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2619_dense_2619(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3240_weight_conv2d_3240_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3240_weight_conv2d_3240_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3240_bias_conv2d_3240_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3240_bias_conv2d_3240_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3243_weight_conv2d_3243_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3243_weight_conv2d_3243_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3243_bias_conv2d_3243_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3243_bias_conv2d_3243_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2612_weight_dense_2612_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2612_weight_dense_2612_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2612_bias_dense_2612_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2612_bias_dense_2612_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2614_weight_dense_2614_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2614_weight_dense_2614_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2614_bias_dense_2614_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2614_bias_dense_2614_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3241_weight_conv2d_3241_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3241_weight_conv2d_3241_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3241_bias_conv2d_3241_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3241_bias_conv2d_3241_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3244_weight_conv2d_3244_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3244_weight_conv2d_3244_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3244_bias_conv2d_3244_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3244_bias_conv2d_3244_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2613_weight_dense_2613_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2613_weight_dense_2613_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2613_bias_dense_2613_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2613_bias_dense_2613_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2615_weight_dense_2615_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2615_weight_dense_2615_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2615_bias_dense_2615_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2615_bias_dense_2615_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3242_weight_conv2d_3242_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3242_weight_conv2d_3242_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3242_bias_conv2d_3242_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3242_bias_conv2d_3242_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3245_weight_conv2d_3245_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3245_weight_conv2d_3245_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3245_bias_conv2d_3245_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3245_bias_conv2d_3245_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3246_weight_conv2d_3246_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3246_weight_conv2d_3246_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3246_bias_conv2d_3246_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3246_bias_conv2d_3246_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2616_weight_dense_2616_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2616_weight_dense_2616_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2616_bias_dense_2616_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2616_bias_dense_2616_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2617_weight_dense_2617_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2617_weight_dense_2617_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2617_bias_dense_2617_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2617_bias_dense_2617_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2618_weight_dense_2618_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2618_weight_dense_2618_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2618_bias_dense_2618_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2618_bias_dense_2618_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2619_weight_dense_2619_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2619_weight_dense_2619_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2619_bias_dense_2619_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2619_bias_dense_2619_bias(XNn_model_top *InstancePtr);

void XNn_model_top_InterruptGlobalEnable(XNn_model_top *InstancePtr);
void XNn_model_top_InterruptGlobalDisable(XNn_model_top *InstancePtr);
void XNn_model_top_InterruptEnable(XNn_model_top *InstancePtr, u32 Mask);
void XNn_model_top_InterruptDisable(XNn_model_top *InstancePtr, u32 Mask);
void XNn_model_top_InterruptClear(XNn_model_top *InstancePtr, u32 Mask);
u32 XNn_model_top_InterruptGetEnabled(XNn_model_top *InstancePtr);
u32 XNn_model_top_InterruptGetStatus(XNn_model_top *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
