// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2019.2.1 (64-bit)
// Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef XNN_MODEL_TOP_H
#define XNN_MODEL_TOP_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xnn_model_top_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
#else
typedef struct {
    u16 DeviceId;
    u32 Control_BaseAddress;
} XNn_model_top_Config;
#endif

typedef struct {
    u32 Control_BaseAddress;
    u32 IsReady;
} XNn_model_top;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XNn_model_top_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XNn_model_top_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XNn_model_top_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XNn_model_top_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
int XNn_model_top_Initialize(XNn_model_top *InstancePtr, u16 DeviceId);
XNn_model_top_Config* XNn_model_top_LookupConfig(u16 DeviceId);
int XNn_model_top_CfgInitialize(XNn_model_top *InstancePtr, XNn_model_top_Config *ConfigPtr);
#else
int XNn_model_top_Initialize(XNn_model_top *InstancePtr, const char* InstanceName);
int XNn_model_top_Release(XNn_model_top *InstancePtr);
#endif

void XNn_model_top_Start(XNn_model_top *InstancePtr);
u32 XNn_model_top_IsDone(XNn_model_top *InstancePtr);
u32 XNn_model_top_IsIdle(XNn_model_top *InstancePtr);
u32 XNn_model_top_IsReady(XNn_model_top *InstancePtr);
void XNn_model_top_EnableAutoRestart(XNn_model_top *InstancePtr);
void XNn_model_top_DisableAutoRestart(XNn_model_top *InstancePtr);
u32 XNn_model_top_Get_return(XNn_model_top *InstancePtr);

void XNn_model_top_Set_Input1_input1(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Input1_input1(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Input2_input2(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Input2_input2(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2473_conv2d_2473(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2473_conv2d_2473(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2474_conv2d_2474(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2474_conv2d_2474(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_2091_max_pooling2d_2091(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_2091_max_pooling2d_2091(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_2092_max_pooling2d_2092(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_2092_max_pooling2d_2092(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2013_dense_2013(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2013_dense_2013(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2014_dense_2014(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2014_dense_2014(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Concatenate_434_concatenate_434(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Concatenate_434_concatenate_434(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2475_conv2d_2475(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2475_conv2d_2475(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_2093_max_pooling2d_2093(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_2093_max_pooling2d_2093(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2015_dense_2015(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2015_dense_2015(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2476_conv2d_2476(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2476_conv2d_2476(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_2094_max_pooling2d_2094(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_2094_max_pooling2d_2094(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2016_dense_2016(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2016_dense_2016(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_2095_max_pooling2d_2095(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_2095_max_pooling2d_2095(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2017_dense_2017(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2017_dense_2017(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Flatten_225_flatten_225(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Flatten_225_flatten_225(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2018_dense_2018(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2018_dense_2018(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2019_dense_2019(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2019_dense_2019(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2473_weight_conv2d_2473_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2473_weight_conv2d_2473_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2473_bias_conv2d_2473_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2473_bias_conv2d_2473_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2474_weight_conv2d_2474_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2474_weight_conv2d_2474_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2474_bias_conv2d_2474_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2474_bias_conv2d_2474_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2013_weight_dense_2013_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2013_weight_dense_2013_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2013_bias_dense_2013_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2013_bias_dense_2013_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2014_weight_dense_2014_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2014_weight_dense_2014_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2014_bias_dense_2014_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2014_bias_dense_2014_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2475_weight_conv2d_2475_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2475_weight_conv2d_2475_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2475_bias_conv2d_2475_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2475_bias_conv2d_2475_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2015_weight_dense_2015_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2015_weight_dense_2015_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2015_bias_dense_2015_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2015_bias_dense_2015_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2476_weight_conv2d_2476_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2476_weight_conv2d_2476_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2476_bias_conv2d_2476_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2476_bias_conv2d_2476_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2016_weight_dense_2016_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2016_weight_dense_2016_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2016_bias_dense_2016_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2016_bias_dense_2016_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2017_weight_dense_2017_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2017_weight_dense_2017_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2017_bias_dense_2017_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2017_bias_dense_2017_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2018_weight_dense_2018_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2018_weight_dense_2018_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2018_bias_dense_2018_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2018_bias_dense_2018_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2019_weight_dense_2019_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2019_weight_dense_2019_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2019_bias_dense_2019_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2019_bias_dense_2019_bias(XNn_model_top *InstancePtr);

void XNn_model_top_InterruptGlobalEnable(XNn_model_top *InstancePtr);
void XNn_model_top_InterruptGlobalDisable(XNn_model_top *InstancePtr);
void XNn_model_top_InterruptEnable(XNn_model_top *InstancePtr, u32 Mask);
void XNn_model_top_InterruptDisable(XNn_model_top *InstancePtr, u32 Mask);
void XNn_model_top_InterruptClear(XNn_model_top *InstancePtr, u32 Mask);
u32 XNn_model_top_InterruptGetEnabled(XNn_model_top *InstancePtr);
u32 XNn_model_top_InterruptGetStatus(XNn_model_top *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
