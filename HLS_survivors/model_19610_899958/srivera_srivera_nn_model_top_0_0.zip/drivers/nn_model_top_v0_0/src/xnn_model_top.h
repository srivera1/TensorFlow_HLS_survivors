// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2019.2.1 (64-bit)
// Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef XNN_MODEL_TOP_H
#define XNN_MODEL_TOP_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xnn_model_top_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
#else
typedef struct {
    u16 DeviceId;
    u32 Control_BaseAddress;
} XNn_model_top_Config;
#endif

typedef struct {
    u32 Control_BaseAddress;
    u32 IsReady;
} XNn_model_top;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XNn_model_top_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XNn_model_top_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XNn_model_top_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XNn_model_top_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
int XNn_model_top_Initialize(XNn_model_top *InstancePtr, u16 DeviceId);
XNn_model_top_Config* XNn_model_top_LookupConfig(u16 DeviceId);
int XNn_model_top_CfgInitialize(XNn_model_top *InstancePtr, XNn_model_top_Config *ConfigPtr);
#else
int XNn_model_top_Initialize(XNn_model_top *InstancePtr, const char* InstanceName);
int XNn_model_top_Release(XNn_model_top *InstancePtr);
#endif

void XNn_model_top_Start(XNn_model_top *InstancePtr);
u32 XNn_model_top_IsDone(XNn_model_top *InstancePtr);
u32 XNn_model_top_IsIdle(XNn_model_top *InstancePtr);
u32 XNn_model_top_IsReady(XNn_model_top *InstancePtr);
void XNn_model_top_EnableAutoRestart(XNn_model_top *InstancePtr);
void XNn_model_top_DisableAutoRestart(XNn_model_top *InstancePtr);
u32 XNn_model_top_Get_return(XNn_model_top *InstancePtr);

void XNn_model_top_Set_Input2_input2(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Input2_input2(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Input1_input1(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Input1_input1(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_6113_conv2d_6113(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_6113_conv2d_6113(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_6108_conv2d_6108(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_6108_conv2d_6108(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_4841_max_pooling2d_4841(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_4841_max_pooling2d_4841(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_4836_max_pooling2d_4836(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_4836_max_pooling2d_4836(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_4559_dense_4559(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_4559_dense_4559(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_4555_dense_4555(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_4555_dense_4555(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_6114_conv2d_6114(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_6114_conv2d_6114(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_6109_conv2d_6109(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_6109_conv2d_6109(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_4842_max_pooling2d_4842(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_4842_max_pooling2d_4842(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_4837_max_pooling2d_4837(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_4837_max_pooling2d_4837(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_4560_dense_4560(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_4560_dense_4560(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_4556_dense_4556(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_4556_dense_4556(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_6115_conv2d_6115(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_6115_conv2d_6115(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_6110_conv2d_6110(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_6110_conv2d_6110(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_4843_max_pooling2d_4843(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_4843_max_pooling2d_4843(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_4838_max_pooling2d_4838(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_4838_max_pooling2d_4838(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_4561_dense_4561(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_4561_dense_4561(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_4839_max_pooling2d_4839(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_4839_max_pooling2d_4839(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_4844_max_pooling2d_4844(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_4844_max_pooling2d_4844(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_4557_dense_4557(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_4557_dense_4557(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_4562_dense_4562(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_4562_dense_4562(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_4558_dense_4558(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_4558_dense_4558(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_4563_dense_4563(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_4563_dense_4563(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Concatenate_471_concatenate_471(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Concatenate_471_concatenate_471(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Flatten_174_flatten_174(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Flatten_174_flatten_174(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_4564_dense_4564(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_4564_dense_4564(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_4565_dense_4565(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_4565_dense_4565(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_6113_weight_conv2d_6113_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_6113_weight_conv2d_6113_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_6113_bias_conv2d_6113_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_6113_bias_conv2d_6113_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_6108_weight_conv2d_6108_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_6108_weight_conv2d_6108_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_6108_bias_conv2d_6108_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_6108_bias_conv2d_6108_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_4559_weight_dense_4559_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_4559_weight_dense_4559_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_4559_bias_dense_4559_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_4559_bias_dense_4559_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_4555_weight_dense_4555_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_4555_weight_dense_4555_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_4555_bias_dense_4555_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_4555_bias_dense_4555_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_6114_weight_conv2d_6114_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_6114_weight_conv2d_6114_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_6114_bias_conv2d_6114_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_6114_bias_conv2d_6114_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_6109_weight_conv2d_6109_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_6109_weight_conv2d_6109_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_6109_bias_conv2d_6109_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_6109_bias_conv2d_6109_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_4560_weight_dense_4560_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_4560_weight_dense_4560_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_4560_bias_dense_4560_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_4560_bias_dense_4560_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_4556_weight_dense_4556_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_4556_weight_dense_4556_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_4556_bias_dense_4556_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_4556_bias_dense_4556_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_6115_weight_conv2d_6115_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_6115_weight_conv2d_6115_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_6115_bias_conv2d_6115_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_6115_bias_conv2d_6115_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_6110_weight_conv2d_6110_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_6110_weight_conv2d_6110_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_6110_bias_conv2d_6110_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_6110_bias_conv2d_6110_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_4561_weight_dense_4561_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_4561_weight_dense_4561_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_4561_bias_dense_4561_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_4561_bias_dense_4561_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_4557_weight_dense_4557_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_4557_weight_dense_4557_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_4557_bias_dense_4557_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_4557_bias_dense_4557_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_4562_weight_dense_4562_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_4562_weight_dense_4562_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_4562_bias_dense_4562_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_4562_bias_dense_4562_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_4558_weight_dense_4558_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_4558_weight_dense_4558_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_4558_bias_dense_4558_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_4558_bias_dense_4558_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_4563_weight_dense_4563_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_4563_weight_dense_4563_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_4563_bias_dense_4563_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_4563_bias_dense_4563_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_4564_weight_dense_4564_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_4564_weight_dense_4564_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_4564_bias_dense_4564_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_4564_bias_dense_4564_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_4565_weight_dense_4565_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_4565_weight_dense_4565_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_4565_bias_dense_4565_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_4565_bias_dense_4565_bias(XNn_model_top *InstancePtr);

void XNn_model_top_InterruptGlobalEnable(XNn_model_top *InstancePtr);
void XNn_model_top_InterruptGlobalDisable(XNn_model_top *InstancePtr);
void XNn_model_top_InterruptEnable(XNn_model_top *InstancePtr, u32 Mask);
void XNn_model_top_InterruptDisable(XNn_model_top *InstancePtr, u32 Mask);
void XNn_model_top_InterruptClear(XNn_model_top *InstancePtr, u32 Mask);
u32 XNn_model_top_InterruptGetEnabled(XNn_model_top *InstancePtr);
u32 XNn_model_top_InterruptGetStatus(XNn_model_top *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
