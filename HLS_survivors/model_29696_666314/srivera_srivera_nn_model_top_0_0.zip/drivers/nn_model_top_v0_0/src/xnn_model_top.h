// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2019.2.1 (64-bit)
// Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef XNN_MODEL_TOP_H
#define XNN_MODEL_TOP_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xnn_model_top_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
#else
typedef struct {
    u16 DeviceId;
    u32 Control_BaseAddress;
} XNn_model_top_Config;
#endif

typedef struct {
    u32 Control_BaseAddress;
    u32 IsReady;
} XNn_model_top;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XNn_model_top_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XNn_model_top_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XNn_model_top_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XNn_model_top_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
int XNn_model_top_Initialize(XNn_model_top *InstancePtr, u16 DeviceId);
XNn_model_top_Config* XNn_model_top_LookupConfig(u16 DeviceId);
int XNn_model_top_CfgInitialize(XNn_model_top *InstancePtr, XNn_model_top_Config *ConfigPtr);
#else
int XNn_model_top_Initialize(XNn_model_top *InstancePtr, const char* InstanceName);
int XNn_model_top_Release(XNn_model_top *InstancePtr);
#endif

void XNn_model_top_Start(XNn_model_top *InstancePtr);
u32 XNn_model_top_IsDone(XNn_model_top *InstancePtr);
u32 XNn_model_top_IsIdle(XNn_model_top *InstancePtr);
u32 XNn_model_top_IsReady(XNn_model_top *InstancePtr);
void XNn_model_top_EnableAutoRestart(XNn_model_top *InstancePtr);
void XNn_model_top_DisableAutoRestart(XNn_model_top *InstancePtr);
u32 XNn_model_top_Get_return(XNn_model_top *InstancePtr);

void XNn_model_top_Set_Input1_input1(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Input1_input1(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Input2_input2(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Input2_input2(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3216_conv2d_3216(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3216_conv2d_3216(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3218_conv2d_3218(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3218_conv2d_3218(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_2709_max_pooling2d_2709(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_2709_max_pooling2d_2709(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_2711_max_pooling2d_2711(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_2711_max_pooling2d_2711(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2592_dense_2592(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2592_dense_2592(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2594_dense_2594(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2594_dense_2594(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3217_conv2d_3217(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3217_conv2d_3217(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3219_conv2d_3219(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3219_conv2d_3219(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_2710_max_pooling2d_2710(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_2710_max_pooling2d_2710(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_2712_max_pooling2d_2712(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_2712_max_pooling2d_2712(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2593_dense_2593(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2593_dense_2593(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2595_dense_2595(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2595_dense_2595(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Concatenate_566_concatenate_566(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Concatenate_566_concatenate_566(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3220_conv2d_3220(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3220_conv2d_3220(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_2713_max_pooling2d_2713(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_2713_max_pooling2d_2713(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3223_conv2d_3223(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3223_conv2d_3223(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2596_dense_2596(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2596_dense_2596(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_2715_max_pooling2d_2715(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_2715_max_pooling2d_2715(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_2714_max_pooling2d_2714(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_2714_max_pooling2d_2714(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_2716_max_pooling2d_2716(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_2716_max_pooling2d_2716(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2597_dense_2597(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2597_dense_2597(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2598_dense_2598(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2598_dense_2598(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Concatenate_567_concatenate_567(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Concatenate_567_concatenate_567(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Flatten_288_flatten_288(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Flatten_288_flatten_288(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2599_dense_2599(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2599_dense_2599(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2600_dense_2600(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2600_dense_2600(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2601_dense_2601(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2601_dense_2601(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3216_weight_conv2d_3216_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3216_weight_conv2d_3216_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3216_bias_conv2d_3216_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3216_bias_conv2d_3216_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3218_weight_conv2d_3218_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3218_weight_conv2d_3218_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3218_bias_conv2d_3218_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3218_bias_conv2d_3218_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2592_weight_dense_2592_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2592_weight_dense_2592_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2592_bias_dense_2592_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2592_bias_dense_2592_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2594_weight_dense_2594_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2594_weight_dense_2594_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2594_bias_dense_2594_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2594_bias_dense_2594_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3217_weight_conv2d_3217_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3217_weight_conv2d_3217_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3217_bias_conv2d_3217_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3217_bias_conv2d_3217_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3219_weight_conv2d_3219_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3219_weight_conv2d_3219_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3219_bias_conv2d_3219_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3219_bias_conv2d_3219_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2593_weight_dense_2593_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2593_weight_dense_2593_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2593_bias_dense_2593_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2593_bias_dense_2593_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2595_weight_dense_2595_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2595_weight_dense_2595_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2595_bias_dense_2595_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2595_bias_dense_2595_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3220_weight_conv2d_3220_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3220_weight_conv2d_3220_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3220_bias_conv2d_3220_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3220_bias_conv2d_3220_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3223_weight_conv2d_3223_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3223_weight_conv2d_3223_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_3223_bias_conv2d_3223_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_3223_bias_conv2d_3223_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2596_weight_dense_2596_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2596_weight_dense_2596_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2596_bias_dense_2596_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2596_bias_dense_2596_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2597_weight_dense_2597_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2597_weight_dense_2597_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2597_bias_dense_2597_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2597_bias_dense_2597_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2598_weight_dense_2598_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2598_weight_dense_2598_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2598_bias_dense_2598_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2598_bias_dense_2598_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2599_weight_dense_2599_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2599_weight_dense_2599_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2599_bias_dense_2599_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2599_bias_dense_2599_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2600_weight_dense_2600_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2600_weight_dense_2600_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2600_bias_dense_2600_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2600_bias_dense_2600_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2601_weight_dense_2601_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2601_weight_dense_2601_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2601_bias_dense_2601_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2601_bias_dense_2601_bias(XNn_model_top *InstancePtr);

void XNn_model_top_InterruptGlobalEnable(XNn_model_top *InstancePtr);
void XNn_model_top_InterruptGlobalDisable(XNn_model_top *InstancePtr);
void XNn_model_top_InterruptEnable(XNn_model_top *InstancePtr, u32 Mask);
void XNn_model_top_InterruptDisable(XNn_model_top *InstancePtr, u32 Mask);
void XNn_model_top_InterruptClear(XNn_model_top *InstancePtr, u32 Mask);
u32 XNn_model_top_InterruptGetEnabled(XNn_model_top *InstancePtr);
u32 XNn_model_top_InterruptGetStatus(XNn_model_top *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
