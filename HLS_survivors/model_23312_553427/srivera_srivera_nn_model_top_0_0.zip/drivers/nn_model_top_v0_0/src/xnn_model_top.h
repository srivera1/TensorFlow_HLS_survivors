// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2019.2.1 (64-bit)
// Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef XNN_MODEL_TOP_H
#define XNN_MODEL_TOP_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xnn_model_top_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
#else
typedef struct {
    u16 DeviceId;
    u32 Control_BaseAddress;
} XNn_model_top_Config;
#endif

typedef struct {
    u32 Control_BaseAddress;
    u32 IsReady;
} XNn_model_top;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XNn_model_top_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XNn_model_top_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XNn_model_top_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XNn_model_top_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
int XNn_model_top_Initialize(XNn_model_top *InstancePtr, u16 DeviceId);
XNn_model_top_Config* XNn_model_top_LookupConfig(u16 DeviceId);
int XNn_model_top_CfgInitialize(XNn_model_top *InstancePtr, XNn_model_top_Config *ConfigPtr);
#else
int XNn_model_top_Initialize(XNn_model_top *InstancePtr, const char* InstanceName);
int XNn_model_top_Release(XNn_model_top *InstancePtr);
#endif

void XNn_model_top_Start(XNn_model_top *InstancePtr);
u32 XNn_model_top_IsDone(XNn_model_top *InstancePtr);
u32 XNn_model_top_IsIdle(XNn_model_top *InstancePtr);
u32 XNn_model_top_IsReady(XNn_model_top *InstancePtr);
void XNn_model_top_EnableAutoRestart(XNn_model_top *InstancePtr);
void XNn_model_top_DisableAutoRestart(XNn_model_top *InstancePtr);
u32 XNn_model_top_Get_return(XNn_model_top *InstancePtr);

void XNn_model_top_Set_Input1_input1(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Input1_input1(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Input2_input2(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Input2_input2(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2212_conv2d_2212(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2212_conv2d_2212(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2213_conv2d_2213(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2213_conv2d_2213(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_1850_max_pooling2d_1850(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_1850_max_pooling2d_1850(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_1851_max_pooling2d_1851(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_1851_max_pooling2d_1851(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1800_dense_1800(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1800_dense_1800(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1801_dense_1801(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1801_dense_1801(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Concatenate_385_concatenate_385(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Concatenate_385_concatenate_385(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2214_conv2d_2214(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2214_conv2d_2214(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_1852_max_pooling2d_1852(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_1852_max_pooling2d_1852(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1802_dense_1802(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1802_dense_1802(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2215_conv2d_2215(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2215_conv2d_2215(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_1853_max_pooling2d_1853(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_1853_max_pooling2d_1853(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1803_dense_1803(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1803_dense_1803(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_1854_max_pooling2d_1854(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_1854_max_pooling2d_1854(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_1855_max_pooling2d_1855(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_1855_max_pooling2d_1855(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1804_dense_1804(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1804_dense_1804(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1805_dense_1805(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1805_dense_1805(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Concatenate_386_concatenate_386(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Concatenate_386_concatenate_386(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1806_dense_1806(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1806_dense_1806(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1808_dense_1808(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1808_dense_1808(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1807_dense_1807(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1807_dense_1807(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1809_dense_1809(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1809_dense_1809(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Concatenate_387_concatenate_387(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Concatenate_387_concatenate_387(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Flatten_198_flatten_198(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Flatten_198_flatten_198(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1810_dense_1810(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1810_dense_1810(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1811_dense_1811(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1811_dense_1811(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2212_weight_conv2d_2212_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2212_weight_conv2d_2212_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2212_bias_conv2d_2212_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2212_bias_conv2d_2212_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2213_weight_conv2d_2213_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2213_weight_conv2d_2213_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2213_bias_conv2d_2213_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2213_bias_conv2d_2213_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1800_weight_dense_1800_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1800_weight_dense_1800_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1800_bias_dense_1800_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1800_bias_dense_1800_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1801_weight_dense_1801_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1801_weight_dense_1801_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1801_bias_dense_1801_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1801_bias_dense_1801_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2214_weight_conv2d_2214_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2214_weight_conv2d_2214_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2214_bias_conv2d_2214_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2214_bias_conv2d_2214_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1802_weight_dense_1802_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1802_weight_dense_1802_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1802_bias_dense_1802_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1802_bias_dense_1802_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2215_weight_conv2d_2215_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2215_weight_conv2d_2215_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2215_bias_conv2d_2215_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2215_bias_conv2d_2215_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1803_weight_dense_1803_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1803_weight_dense_1803_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1803_bias_dense_1803_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1803_bias_dense_1803_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1804_weight_dense_1804_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1804_weight_dense_1804_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1804_bias_dense_1804_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1804_bias_dense_1804_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1805_weight_dense_1805_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1805_weight_dense_1805_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1805_bias_dense_1805_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1805_bias_dense_1805_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1806_weight_dense_1806_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1806_weight_dense_1806_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1806_bias_dense_1806_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1806_bias_dense_1806_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1808_weight_dense_1808_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1808_weight_dense_1808_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1808_bias_dense_1808_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1808_bias_dense_1808_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1807_weight_dense_1807_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1807_weight_dense_1807_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1807_bias_dense_1807_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1807_bias_dense_1807_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1809_weight_dense_1809_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1809_weight_dense_1809_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1809_bias_dense_1809_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1809_bias_dense_1809_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1810_weight_dense_1810_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1810_weight_dense_1810_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1810_bias_dense_1810_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1810_bias_dense_1810_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1811_weight_dense_1811_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1811_weight_dense_1811_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1811_bias_dense_1811_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1811_bias_dense_1811_bias(XNn_model_top *InstancePtr);

void XNn_model_top_InterruptGlobalEnable(XNn_model_top *InstancePtr);
void XNn_model_top_InterruptGlobalDisable(XNn_model_top *InstancePtr);
void XNn_model_top_InterruptEnable(XNn_model_top *InstancePtr, u32 Mask);
void XNn_model_top_InterruptDisable(XNn_model_top *InstancePtr, u32 Mask);
void XNn_model_top_InterruptClear(XNn_model_top *InstancePtr, u32 Mask);
u32 XNn_model_top_InterruptGetEnabled(XNn_model_top *InstancePtr);
u32 XNn_model_top_InterruptGetStatus(XNn_model_top *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
