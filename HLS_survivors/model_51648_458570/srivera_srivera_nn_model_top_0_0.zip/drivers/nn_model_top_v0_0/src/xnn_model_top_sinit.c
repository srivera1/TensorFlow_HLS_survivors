// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2019.2.1 (64-bit)
// Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#include "xparameters.h"
#include "xnn_model_top.h"

extern XNn_model_top_Config XNn_model_top_ConfigTable[];

XNn_model_top_Config *XNn_model_top_LookupConfig(u16 DeviceId) {
	XNn_model_top_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XNN_MODEL_TOP_NUM_INSTANCES; Index++) {
		if (XNn_model_top_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XNn_model_top_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XNn_model_top_Initialize(XNn_model_top *InstancePtr, u16 DeviceId) {
	XNn_model_top_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XNn_model_top_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XNn_model_top_CfgInitialize(InstancePtr, ConfigPtr);
}

#endif

