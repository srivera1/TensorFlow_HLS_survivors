// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2019.2.1 (64-bit)
// Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef XNN_MODEL_TOP_H
#define XNN_MODEL_TOP_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xnn_model_top_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
#else
typedef struct {
    u16 DeviceId;
    u32 Control_BaseAddress;
} XNn_model_top_Config;
#endif

typedef struct {
    u32 Control_BaseAddress;
    u32 IsReady;
} XNn_model_top;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XNn_model_top_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XNn_model_top_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XNn_model_top_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XNn_model_top_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
int XNn_model_top_Initialize(XNn_model_top *InstancePtr, u16 DeviceId);
XNn_model_top_Config* XNn_model_top_LookupConfig(u16 DeviceId);
int XNn_model_top_CfgInitialize(XNn_model_top *InstancePtr, XNn_model_top_Config *ConfigPtr);
#else
int XNn_model_top_Initialize(XNn_model_top *InstancePtr, const char* InstanceName);
int XNn_model_top_Release(XNn_model_top *InstancePtr);
#endif

void XNn_model_top_Start(XNn_model_top *InstancePtr);
u32 XNn_model_top_IsDone(XNn_model_top *InstancePtr);
u32 XNn_model_top_IsIdle(XNn_model_top *InstancePtr);
u32 XNn_model_top_IsReady(XNn_model_top *InstancePtr);
void XNn_model_top_EnableAutoRestart(XNn_model_top *InstancePtr);
void XNn_model_top_DisableAutoRestart(XNn_model_top *InstancePtr);
u32 XNn_model_top_Get_return(XNn_model_top *InstancePtr);

void XNn_model_top_Set_Input_input(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Input_input(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_7313_conv2d_7313(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_7313_conv2d_7313(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_5176_max_pooling2d_5176(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_5176_max_pooling2d_5176(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_5775_dense_5775(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_5775_dense_5775(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_7314_conv2d_7314(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_7314_conv2d_7314(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_7315_conv2d_7315(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_7315_conv2d_7315(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_5177_max_pooling2d_5177(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_5177_max_pooling2d_5177(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_5178_max_pooling2d_5178(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_5178_max_pooling2d_5178(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_5776_dense_5776(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_5776_dense_5776(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_5777_dense_5777(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_5777_dense_5777(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Concatenate_507_concatenate_507(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Concatenate_507_concatenate_507(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_7316_conv2d_7316(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_7316_conv2d_7316(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_5179_max_pooling2d_5179(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_5179_max_pooling2d_5179(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_5778_dense_5778(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_5778_dense_5778(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_5180_max_pooling2d_5180(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_5180_max_pooling2d_5180(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_5779_dense_5779(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_5779_dense_5779(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_5780_dense_5780(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_5780_dense_5780(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_5781_dense_5781(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_5781_dense_5781(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_5782_dense_5782(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_5782_dense_5782(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_5783_dense_5783(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_5783_dense_5783(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_5784_dense_5784(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_5784_dense_5784(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_5785_dense_5785(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_5785_dense_5785(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_5786_dense_5786(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_5786_dense_5786(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_5787_dense_5787(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_5787_dense_5787(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_5788_dense_5788(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_5788_dense_5788(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_5789_dense_5789(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_5789_dense_5789(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_5790_dense_5790(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_5790_dense_5790(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Flatten_347_flatten_347(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Flatten_347_flatten_347(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_5791_dense_5791(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_5791_dense_5791(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_5792_dense_5792(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_5792_dense_5792(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_7313_weight_conv2d_7313_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_7313_weight_conv2d_7313_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_7313_bias_conv2d_7313_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_7313_bias_conv2d_7313_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_5775_weight_dense_5775_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_5775_weight_dense_5775_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_5775_bias_dense_5775_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_5775_bias_dense_5775_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_7314_weight_conv2d_7314_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_7314_weight_conv2d_7314_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_7314_bias_conv2d_7314_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_7314_bias_conv2d_7314_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_7315_weight_conv2d_7315_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_7315_weight_conv2d_7315_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_7315_bias_conv2d_7315_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_7315_bias_conv2d_7315_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_5776_weight_dense_5776_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_5776_weight_dense_5776_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_5776_bias_dense_5776_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_5776_bias_dense_5776_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_5777_weight_dense_5777_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_5777_weight_dense_5777_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_5777_bias_dense_5777_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_5777_bias_dense_5777_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_7316_weight_conv2d_7316_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_7316_weight_conv2d_7316_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_7316_bias_conv2d_7316_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_7316_bias_conv2d_7316_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_5778_weight_dense_5778_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_5778_weight_dense_5778_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_5778_bias_dense_5778_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_5778_bias_dense_5778_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_5779_weight_dense_5779_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_5779_weight_dense_5779_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_5779_bias_dense_5779_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_5779_bias_dense_5779_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_5780_weight_dense_5780_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_5780_weight_dense_5780_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_5780_bias_dense_5780_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_5780_bias_dense_5780_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_5781_weight_dense_5781_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_5781_weight_dense_5781_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_5781_bias_dense_5781_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_5781_bias_dense_5781_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_5782_weight_dense_5782_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_5782_weight_dense_5782_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_5782_bias_dense_5782_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_5782_bias_dense_5782_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_5783_weight_dense_5783_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_5783_weight_dense_5783_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_5783_bias_dense_5783_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_5783_bias_dense_5783_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_5784_weight_dense_5784_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_5784_weight_dense_5784_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_5784_bias_dense_5784_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_5784_bias_dense_5784_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_5785_weight_dense_5785_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_5785_weight_dense_5785_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_5785_bias_dense_5785_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_5785_bias_dense_5785_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_5786_weight_dense_5786_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_5786_weight_dense_5786_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_5786_bias_dense_5786_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_5786_bias_dense_5786_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_5787_weight_dense_5787_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_5787_weight_dense_5787_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_5787_bias_dense_5787_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_5787_bias_dense_5787_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_5788_weight_dense_5788_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_5788_weight_dense_5788_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_5788_bias_dense_5788_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_5788_bias_dense_5788_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_5789_weight_dense_5789_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_5789_weight_dense_5789_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_5789_bias_dense_5789_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_5789_bias_dense_5789_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_5790_weight_dense_5790_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_5790_weight_dense_5790_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_5790_bias_dense_5790_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_5790_bias_dense_5790_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_5791_weight_dense_5791_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_5791_weight_dense_5791_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_5791_bias_dense_5791_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_5791_bias_dense_5791_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_5792_weight_dense_5792_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_5792_weight_dense_5792_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_5792_bias_dense_5792_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_5792_bias_dense_5792_bias(XNn_model_top *InstancePtr);

void XNn_model_top_InterruptGlobalEnable(XNn_model_top *InstancePtr);
void XNn_model_top_InterruptGlobalDisable(XNn_model_top *InstancePtr);
void XNn_model_top_InterruptEnable(XNn_model_top *InstancePtr, u32 Mask);
void XNn_model_top_InterruptDisable(XNn_model_top *InstancePtr, u32 Mask);
void XNn_model_top_InterruptClear(XNn_model_top *InstancePtr, u32 Mask);
u32 XNn_model_top_InterruptGetEnabled(XNn_model_top *InstancePtr);
u32 XNn_model_top_InterruptGetStatus(XNn_model_top *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
