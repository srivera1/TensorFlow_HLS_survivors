// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2019.2.1 (64-bit)
// Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef XNN_MODEL_TOP_H
#define XNN_MODEL_TOP_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xnn_model_top_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
#else
typedef struct {
    u16 DeviceId;
    u32 Control_BaseAddress;
} XNn_model_top_Config;
#endif

typedef struct {
    u32 Control_BaseAddress;
    u32 IsReady;
} XNn_model_top;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XNn_model_top_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XNn_model_top_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XNn_model_top_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XNn_model_top_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
int XNn_model_top_Initialize(XNn_model_top *InstancePtr, u16 DeviceId);
XNn_model_top_Config* XNn_model_top_LookupConfig(u16 DeviceId);
int XNn_model_top_CfgInitialize(XNn_model_top *InstancePtr, XNn_model_top_Config *ConfigPtr);
#else
int XNn_model_top_Initialize(XNn_model_top *InstancePtr, const char* InstanceName);
int XNn_model_top_Release(XNn_model_top *InstancePtr);
#endif

void XNn_model_top_Start(XNn_model_top *InstancePtr);
u32 XNn_model_top_IsDone(XNn_model_top *InstancePtr);
u32 XNn_model_top_IsIdle(XNn_model_top *InstancePtr);
u32 XNn_model_top_IsReady(XNn_model_top *InstancePtr);
void XNn_model_top_EnableAutoRestart(XNn_model_top *InstancePtr);
void XNn_model_top_DisableAutoRestart(XNn_model_top *InstancePtr);
u32 XNn_model_top_Get_return(XNn_model_top *InstancePtr);

void XNn_model_top_Set_Input1_input1(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Input1_input1(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Input2_input2(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Input2_input2(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_36_conv2d_36(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_36_conv2d_36(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_38_conv2d_38(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_38_conv2d_38(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_25_max_pooling2d_25(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_25_max_pooling2d_25(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_27_max_pooling2d_27(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_27_max_pooling2d_27(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_26_dense_26(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_26_dense_26(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_28_dense_28(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_28_dense_28(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_37_conv2d_37(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_37_conv2d_37(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_39_conv2d_39(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_39_conv2d_39(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_26_max_pooling2d_26(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_26_max_pooling2d_26(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_28_max_pooling2d_28(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_28_max_pooling2d_28(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_27_dense_27(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_27_dense_27(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_29_dense_29(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_29_dense_29(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Concatenate_8_concatenate_8(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Concatenate_8_concatenate_8(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_40_conv2d_40(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_40_conv2d_40(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_43_conv2d_43(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_43_conv2d_43(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_29_max_pooling2d_29(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_29_max_pooling2d_29(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_31_max_pooling2d_31(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_31_max_pooling2d_31(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_30_dense_30(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_30_dense_30(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_32_dense_32(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_32_dense_32(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_30_max_pooling2d_30(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_30_max_pooling2d_30(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_32_max_pooling2d_32(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_32_max_pooling2d_32(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_31_dense_31(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_31_dense_31(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_33_dense_33(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_33_dense_33(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Concatenate_9_concatenate_9(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Concatenate_9_concatenate_9(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Flatten_3_flatten_3(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Flatten_3_flatten_3(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_34_dense_34(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_34_dense_34(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_35_dense_35(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_35_dense_35(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_36_dense_36(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_36_dense_36(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_36_weight_conv2d_36_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_36_weight_conv2d_36_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_36_bias_conv2d_36_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_36_bias_conv2d_36_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_38_weight_conv2d_38_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_38_weight_conv2d_38_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_38_bias_conv2d_38_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_38_bias_conv2d_38_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_26_weight_dense_26_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_26_weight_dense_26_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_26_bias_dense_26_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_26_bias_dense_26_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_28_weight_dense_28_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_28_weight_dense_28_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_28_bias_dense_28_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_28_bias_dense_28_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_37_weight_conv2d_37_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_37_weight_conv2d_37_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_37_bias_conv2d_37_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_37_bias_conv2d_37_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_39_weight_conv2d_39_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_39_weight_conv2d_39_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_39_bias_conv2d_39_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_39_bias_conv2d_39_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_27_weight_dense_27_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_27_weight_dense_27_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_27_bias_dense_27_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_27_bias_dense_27_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_29_weight_dense_29_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_29_weight_dense_29_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_29_bias_dense_29_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_29_bias_dense_29_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_40_weight_conv2d_40_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_40_weight_conv2d_40_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_40_bias_conv2d_40_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_40_bias_conv2d_40_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_43_weight_conv2d_43_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_43_weight_conv2d_43_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_43_bias_conv2d_43_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_43_bias_conv2d_43_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_30_weight_dense_30_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_30_weight_dense_30_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_30_bias_dense_30_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_30_bias_dense_30_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_32_weight_dense_32_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_32_weight_dense_32_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_32_bias_dense_32_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_32_bias_dense_32_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_31_weight_dense_31_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_31_weight_dense_31_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_31_bias_dense_31_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_31_bias_dense_31_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_33_weight_dense_33_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_33_weight_dense_33_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_33_bias_dense_33_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_33_bias_dense_33_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_34_weight_dense_34_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_34_weight_dense_34_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_34_bias_dense_34_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_34_bias_dense_34_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_35_weight_dense_35_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_35_weight_dense_35_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_35_bias_dense_35_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_35_bias_dense_35_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_36_weight_dense_36_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_36_weight_dense_36_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_36_bias_dense_36_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_36_bias_dense_36_bias(XNn_model_top *InstancePtr);

void XNn_model_top_InterruptGlobalEnable(XNn_model_top *InstancePtr);
void XNn_model_top_InterruptGlobalDisable(XNn_model_top *InstancePtr);
void XNn_model_top_InterruptEnable(XNn_model_top *InstancePtr, u32 Mask);
void XNn_model_top_InterruptDisable(XNn_model_top *InstancePtr, u32 Mask);
void XNn_model_top_InterruptClear(XNn_model_top *InstancePtr, u32 Mask);
u32 XNn_model_top_InterruptGetEnabled(XNn_model_top *InstancePtr);
u32 XNn_model_top_InterruptGetStatus(XNn_model_top *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
