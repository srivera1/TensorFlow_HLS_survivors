// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2019.2.1 (64-bit)
// Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef XNN_MODEL_TOP_H
#define XNN_MODEL_TOP_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xnn_model_top_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
#else
typedef struct {
    u16 DeviceId;
    u32 Control_BaseAddress;
} XNn_model_top_Config;
#endif

typedef struct {
    u32 Control_BaseAddress;
    u32 IsReady;
} XNn_model_top;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XNn_model_top_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XNn_model_top_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XNn_model_top_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XNn_model_top_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
int XNn_model_top_Initialize(XNn_model_top *InstancePtr, u16 DeviceId);
XNn_model_top_Config* XNn_model_top_LookupConfig(u16 DeviceId);
int XNn_model_top_CfgInitialize(XNn_model_top *InstancePtr, XNn_model_top_Config *ConfigPtr);
#else
int XNn_model_top_Initialize(XNn_model_top *InstancePtr, const char* InstanceName);
int XNn_model_top_Release(XNn_model_top *InstancePtr);
#endif

void XNn_model_top_Start(XNn_model_top *InstancePtr);
u32 XNn_model_top_IsDone(XNn_model_top *InstancePtr);
u32 XNn_model_top_IsIdle(XNn_model_top *InstancePtr);
u32 XNn_model_top_IsReady(XNn_model_top *InstancePtr);
void XNn_model_top_EnableAutoRestart(XNn_model_top *InstancePtr);
void XNn_model_top_DisableAutoRestart(XNn_model_top *InstancePtr);
u32 XNn_model_top_Get_return(XNn_model_top *InstancePtr);

void XNn_model_top_Set_Input2_input2(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Input2_input2(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Input1_input1(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Input1_input1(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2509_conv2d_2509(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2509_conv2d_2509(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2506_conv2d_2506(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2506_conv2d_2506(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_2119_max_pooling2d_2119(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_2119_max_pooling2d_2119(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_2117_max_pooling2d_2117(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_2117_max_pooling2d_2117(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2041_dense_2041(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2041_dense_2041(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2507_conv2d_2507(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2507_conv2d_2507(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2510_conv2d_2510(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2510_conv2d_2510(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_2118_max_pooling2d_2118(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_2118_max_pooling2d_2118(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_2120_max_pooling2d_2120(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_2120_max_pooling2d_2120(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2040_dense_2040(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2040_dense_2040(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2042_dense_2042(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2042_dense_2042(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2508_conv2d_2508(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2508_conv2d_2508(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2511_conv2d_2511(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2511_conv2d_2511(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Concatenate_440_concatenate_440(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Concatenate_440_concatenate_440(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2512_conv2d_2512(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2512_conv2d_2512(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2515_conv2d_2515(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2515_conv2d_2515(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_2121_max_pooling2d_2121(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_2121_max_pooling2d_2121(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_2123_max_pooling2d_2123(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_2123_max_pooling2d_2123(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2043_dense_2043(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2043_dense_2043(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2045_dense_2045(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2045_dense_2045(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2044_dense_2044(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2044_dense_2044(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2046_dense_2046(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2046_dense_2046(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Concatenate_441_concatenate_441(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Concatenate_441_concatenate_441(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Flatten_227_flatten_227(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Flatten_227_flatten_227(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2047_dense_2047(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2047_dense_2047(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2048_dense_2048(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2048_dense_2048(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2509_weight_conv2d_2509_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2509_weight_conv2d_2509_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2509_bias_conv2d_2509_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2509_bias_conv2d_2509_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2506_weight_conv2d_2506_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2506_weight_conv2d_2506_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2506_bias_conv2d_2506_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2506_bias_conv2d_2506_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2041_weight_dense_2041_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2041_weight_dense_2041_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2041_bias_dense_2041_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2041_bias_dense_2041_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2507_weight_conv2d_2507_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2507_weight_conv2d_2507_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2507_bias_conv2d_2507_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2507_bias_conv2d_2507_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2510_weight_conv2d_2510_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2510_weight_conv2d_2510_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2510_bias_conv2d_2510_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2510_bias_conv2d_2510_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2040_weight_dense_2040_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2040_weight_dense_2040_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2040_bias_dense_2040_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2040_bias_dense_2040_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2042_weight_dense_2042_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2042_weight_dense_2042_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2042_bias_dense_2042_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2042_bias_dense_2042_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2508_weight_conv2d_2508_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2508_weight_conv2d_2508_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2508_bias_conv2d_2508_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2508_bias_conv2d_2508_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2511_weight_conv2d_2511_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2511_weight_conv2d_2511_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2511_bias_conv2d_2511_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2511_bias_conv2d_2511_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2512_weight_conv2d_2512_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2512_weight_conv2d_2512_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2512_bias_conv2d_2512_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2512_bias_conv2d_2512_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2515_weight_conv2d_2515_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2515_weight_conv2d_2515_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2515_bias_conv2d_2515_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2515_bias_conv2d_2515_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2043_weight_dense_2043_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2043_weight_dense_2043_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2043_bias_dense_2043_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2043_bias_dense_2043_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2045_weight_dense_2045_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2045_weight_dense_2045_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2045_bias_dense_2045_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2045_bias_dense_2045_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2044_weight_dense_2044_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2044_weight_dense_2044_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2044_bias_dense_2044_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2044_bias_dense_2044_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2046_weight_dense_2046_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2046_weight_dense_2046_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2046_bias_dense_2046_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2046_bias_dense_2046_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2047_weight_dense_2047_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2047_weight_dense_2047_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2047_bias_dense_2047_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2047_bias_dense_2047_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2048_weight_dense_2048_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2048_weight_dense_2048_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2048_bias_dense_2048_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2048_bias_dense_2048_bias(XNn_model_top *InstancePtr);

void XNn_model_top_InterruptGlobalEnable(XNn_model_top *InstancePtr);
void XNn_model_top_InterruptGlobalDisable(XNn_model_top *InstancePtr);
void XNn_model_top_InterruptEnable(XNn_model_top *InstancePtr, u32 Mask);
void XNn_model_top_InterruptDisable(XNn_model_top *InstancePtr, u32 Mask);
void XNn_model_top_InterruptClear(XNn_model_top *InstancePtr, u32 Mask);
u32 XNn_model_top_InterruptGetEnabled(XNn_model_top *InstancePtr);
u32 XNn_model_top_InterruptGetStatus(XNn_model_top *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
