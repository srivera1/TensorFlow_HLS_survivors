// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2019.2 (64-bit)
// Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef XNN_MODEL_TOP_H
#define XNN_MODEL_TOP_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xnn_model_top_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
#else
typedef struct {
    u16 DeviceId;
    u32 Control_BaseAddress;
} XNn_model_top_Config;
#endif

typedef struct {
    u32 Control_BaseAddress;
    u32 IsReady;
} XNn_model_top;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XNn_model_top_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XNn_model_top_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XNn_model_top_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XNn_model_top_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
int XNn_model_top_Initialize(XNn_model_top *InstancePtr, u16 DeviceId);
XNn_model_top_Config* XNn_model_top_LookupConfig(u16 DeviceId);
int XNn_model_top_CfgInitialize(XNn_model_top *InstancePtr, XNn_model_top_Config *ConfigPtr);
#else
int XNn_model_top_Initialize(XNn_model_top *InstancePtr, const char* InstanceName);
int XNn_model_top_Release(XNn_model_top *InstancePtr);
#endif

void XNn_model_top_Start(XNn_model_top *InstancePtr);
u32 XNn_model_top_IsDone(XNn_model_top *InstancePtr);
u32 XNn_model_top_IsIdle(XNn_model_top *InstancePtr);
u32 XNn_model_top_IsReady(XNn_model_top *InstancePtr);
void XNn_model_top_EnableAutoRestart(XNn_model_top *InstancePtr);
void XNn_model_top_DisableAutoRestart(XNn_model_top *InstancePtr);
u32 XNn_model_top_Get_return(XNn_model_top *InstancePtr);

void XNn_model_top_Set_Input_input(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Input_input(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_1796_conv2d_1796(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_1796_conv2d_1796(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_1800_conv2d_1800(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_1800_conv2d_1800(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_1454_max_pooling2d_1454(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_1454_max_pooling2d_1454(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_1458_max_pooling2d_1458(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_1458_max_pooling2d_1458(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1367_dense_1367(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1367_dense_1367(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1371_dense_1371(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1371_dense_1371(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_1797_conv2d_1797(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_1797_conv2d_1797(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_1801_conv2d_1801(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_1801_conv2d_1801(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_1455_max_pooling2d_1455(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_1455_max_pooling2d_1455(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_1459_max_pooling2d_1459(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_1459_max_pooling2d_1459(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1368_dense_1368(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1368_dense_1368(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1372_dense_1372(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1372_dense_1372(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_1798_conv2d_1798(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_1798_conv2d_1798(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_1802_conv2d_1802(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_1802_conv2d_1802(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_1456_max_pooling2d_1456(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_1456_max_pooling2d_1456(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_1460_max_pooling2d_1460(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_1460_max_pooling2d_1460(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1369_dense_1369(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1369_dense_1369(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1373_dense_1373(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1373_dense_1373(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_1457_max_pooling2d_1457(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_1457_max_pooling2d_1457(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_1461_max_pooling2d_1461(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_1461_max_pooling2d_1461(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1370_dense_1370(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1370_dense_1370(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1374_dense_1374(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1374_dense_1374(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Concatenate_114_concatenate_114(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Concatenate_114_concatenate_114(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Flatten_43_flatten_43(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Flatten_43_flatten_43(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1375_dense_1375(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1375_dense_1375(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1376_dense_1376(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1376_dense_1376(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_1796_weight_conv2d_1796_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_1796_weight_conv2d_1796_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_1796_bias_conv2d_1796_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_1796_bias_conv2d_1796_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_1800_weight_conv2d_1800_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_1800_weight_conv2d_1800_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_1800_bias_conv2d_1800_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_1800_bias_conv2d_1800_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1367_weight_dense_1367_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1367_weight_dense_1367_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1367_bias_dense_1367_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1367_bias_dense_1367_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1371_weight_dense_1371_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1371_weight_dense_1371_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1371_bias_dense_1371_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1371_bias_dense_1371_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_1797_weight_conv2d_1797_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_1797_weight_conv2d_1797_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_1797_bias_conv2d_1797_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_1797_bias_conv2d_1797_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_1801_weight_conv2d_1801_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_1801_weight_conv2d_1801_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_1801_bias_conv2d_1801_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_1801_bias_conv2d_1801_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1368_weight_dense_1368_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1368_weight_dense_1368_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1368_bias_dense_1368_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1368_bias_dense_1368_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1372_weight_dense_1372_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1372_weight_dense_1372_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1372_bias_dense_1372_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1372_bias_dense_1372_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_1798_weight_conv2d_1798_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_1798_weight_conv2d_1798_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_1798_bias_conv2d_1798_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_1798_bias_conv2d_1798_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_1802_weight_conv2d_1802_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_1802_weight_conv2d_1802_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_1802_bias_conv2d_1802_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_1802_bias_conv2d_1802_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1369_weight_dense_1369_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1369_weight_dense_1369_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1369_bias_dense_1369_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1369_bias_dense_1369_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1373_weight_dense_1373_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1373_weight_dense_1373_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1373_bias_dense_1373_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1373_bias_dense_1373_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1370_weight_dense_1370_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1370_weight_dense_1370_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1370_bias_dense_1370_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1370_bias_dense_1370_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1374_weight_dense_1374_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1374_weight_dense_1374_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1374_bias_dense_1374_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1374_bias_dense_1374_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1375_weight_dense_1375_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1375_weight_dense_1375_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1375_bias_dense_1375_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1375_bias_dense_1375_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1376_weight_dense_1376_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1376_weight_dense_1376_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1376_bias_dense_1376_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1376_bias_dense_1376_bias(XNn_model_top *InstancePtr);

void XNn_model_top_InterruptGlobalEnable(XNn_model_top *InstancePtr);
void XNn_model_top_InterruptGlobalDisable(XNn_model_top *InstancePtr);
void XNn_model_top_InterruptEnable(XNn_model_top *InstancePtr, u32 Mask);
void XNn_model_top_InterruptDisable(XNn_model_top *InstancePtr, u32 Mask);
void XNn_model_top_InterruptClear(XNn_model_top *InstancePtr, u32 Mask);
u32 XNn_model_top_InterruptGetEnabled(XNn_model_top *InstancePtr);
u32 XNn_model_top_InterruptGetStatus(XNn_model_top *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
