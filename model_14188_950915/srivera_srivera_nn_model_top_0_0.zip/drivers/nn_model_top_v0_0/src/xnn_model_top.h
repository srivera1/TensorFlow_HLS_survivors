// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2019.2.1 (64-bit)
// Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef XNN_MODEL_TOP_H
#define XNN_MODEL_TOP_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xnn_model_top_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
#else
typedef struct {
    u16 DeviceId;
    u32 Control_BaseAddress;
} XNn_model_top_Config;
#endif

typedef struct {
    u32 Control_BaseAddress;
    u32 IsReady;
} XNn_model_top;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XNn_model_top_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XNn_model_top_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XNn_model_top_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XNn_model_top_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
int XNn_model_top_Initialize(XNn_model_top *InstancePtr, u16 DeviceId);
XNn_model_top_Config* XNn_model_top_LookupConfig(u16 DeviceId);
int XNn_model_top_CfgInitialize(XNn_model_top *InstancePtr, XNn_model_top_Config *ConfigPtr);
#else
int XNn_model_top_Initialize(XNn_model_top *InstancePtr, const char* InstanceName);
int XNn_model_top_Release(XNn_model_top *InstancePtr);
#endif

void XNn_model_top_Start(XNn_model_top *InstancePtr);
u32 XNn_model_top_IsDone(XNn_model_top *InstancePtr);
u32 XNn_model_top_IsIdle(XNn_model_top *InstancePtr);
u32 XNn_model_top_IsReady(XNn_model_top *InstancePtr);
void XNn_model_top_EnableAutoRestart(XNn_model_top *InstancePtr);
void XNn_model_top_DisableAutoRestart(XNn_model_top *InstancePtr);
u32 XNn_model_top_Get_return(XNn_model_top *InstancePtr);

void XNn_model_top_Set_Input2_input2(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Input2_input2(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Input1_input1(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Input1_input1(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2827_conv2d_2827(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2827_conv2d_2827(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2825_conv2d_2825(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2825_conv2d_2825(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_2394_max_pooling2d_2394(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_2394_max_pooling2d_2394(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_2392_max_pooling2d_2392(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_2392_max_pooling2d_2392(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2291_dense_2291(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2291_dense_2291(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2826_conv2d_2826(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2826_conv2d_2826(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2828_conv2d_2828(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2828_conv2d_2828(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_2393_max_pooling2d_2393(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_2393_max_pooling2d_2393(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_2395_max_pooling2d_2395(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_2395_max_pooling2d_2395(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2290_dense_2290(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2290_dense_2290(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2292_dense_2292(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2292_dense_2292(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Concatenate_498_concatenate_498(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Concatenate_498_concatenate_498(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2829_conv2d_2829(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2829_conv2d_2829(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2831_conv2d_2831(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2831_conv2d_2831(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_2396_max_pooling2d_2396(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_2396_max_pooling2d_2396(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_2397_max_pooling2d_2397(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_2397_max_pooling2d_2397(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2293_dense_2293(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2293_dense_2293(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2294_dense_2294(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2294_dense_2294(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Concatenate_499_concatenate_499(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Concatenate_499_concatenate_499(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_2398_max_pooling2d_2398(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_2398_max_pooling2d_2398(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2295_dense_2295(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2295_dense_2295(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2296_dense_2296(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2296_dense_2296(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Flatten_256_flatten_256(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Flatten_256_flatten_256(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2297_dense_2297(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2297_dense_2297(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2298_dense_2298(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2298_dense_2298(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2827_weight_conv2d_2827_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2827_weight_conv2d_2827_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2827_bias_conv2d_2827_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2827_bias_conv2d_2827_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2825_weight_conv2d_2825_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2825_weight_conv2d_2825_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2825_bias_conv2d_2825_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2825_bias_conv2d_2825_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2291_weight_dense_2291_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2291_weight_dense_2291_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2291_bias_dense_2291_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2291_bias_dense_2291_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2826_weight_conv2d_2826_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2826_weight_conv2d_2826_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2826_bias_conv2d_2826_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2826_bias_conv2d_2826_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2828_weight_conv2d_2828_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2828_weight_conv2d_2828_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2828_bias_conv2d_2828_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2828_bias_conv2d_2828_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2290_weight_dense_2290_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2290_weight_dense_2290_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2290_bias_dense_2290_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2290_bias_dense_2290_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2292_weight_dense_2292_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2292_weight_dense_2292_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2292_bias_dense_2292_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2292_bias_dense_2292_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2829_weight_conv2d_2829_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2829_weight_conv2d_2829_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2829_bias_conv2d_2829_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2829_bias_conv2d_2829_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2831_weight_conv2d_2831_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2831_weight_conv2d_2831_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2831_bias_conv2d_2831_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2831_bias_conv2d_2831_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2293_weight_dense_2293_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2293_weight_dense_2293_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2293_bias_dense_2293_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2293_bias_dense_2293_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2294_weight_dense_2294_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2294_weight_dense_2294_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2294_bias_dense_2294_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2294_bias_dense_2294_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2295_weight_dense_2295_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2295_weight_dense_2295_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2295_bias_dense_2295_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2295_bias_dense_2295_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2296_weight_dense_2296_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2296_weight_dense_2296_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2296_bias_dense_2296_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2296_bias_dense_2296_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2297_weight_dense_2297_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2297_weight_dense_2297_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2297_bias_dense_2297_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2297_bias_dense_2297_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2298_weight_dense_2298_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2298_weight_dense_2298_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_2298_bias_dense_2298_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_2298_bias_dense_2298_bias(XNn_model_top *InstancePtr);

void XNn_model_top_InterruptGlobalEnable(XNn_model_top *InstancePtr);
void XNn_model_top_InterruptGlobalDisable(XNn_model_top *InstancePtr);
void XNn_model_top_InterruptEnable(XNn_model_top *InstancePtr, u32 Mask);
void XNn_model_top_InterruptDisable(XNn_model_top *InstancePtr, u32 Mask);
void XNn_model_top_InterruptClear(XNn_model_top *InstancePtr, u32 Mask);
u32 XNn_model_top_InterruptGetEnabled(XNn_model_top *InstancePtr);
u32 XNn_model_top_InterruptGetStatus(XNn_model_top *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
