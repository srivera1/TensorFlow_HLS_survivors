// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2019.2.1 (64-bit)
// Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
// ==============================================================
/***************************** Include Files *********************************/
#include "xnn_model_top.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XNn_model_top_CfgInitialize(XNn_model_top *InstancePtr, XNn_model_top_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XNn_model_top_Start(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_AP_CTRL) & 0x80;
    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XNn_model_top_IsDone(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XNn_model_top_IsIdle(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XNn_model_top_IsReady(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XNn_model_top_EnableAutoRestart(XNn_model_top *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XNn_model_top_DisableAutoRestart(XNn_model_top *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_AP_CTRL, 0);
}

u32 XNn_model_top_Get_return(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_AP_RETURN);
    return Data;
}
void XNn_model_top_Set_Input2_input2(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_INPUT2_INPUT2_DATA, Data);
}

u32 XNn_model_top_Get_Input2_input2(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_INPUT2_INPUT2_DATA);
    return Data;
}

void XNn_model_top_Set_Input1_input1(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_INPUT1_INPUT1_DATA, Data);
}

u32 XNn_model_top_Get_Input1_input1(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_INPUT1_INPUT1_DATA);
    return Data;
}

void XNn_model_top_Set_Conv2d_2827_conv2d_2827(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_2827_CONV2D_2827_DATA, Data);
}

u32 XNn_model_top_Get_Conv2d_2827_conv2d_2827(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_2827_CONV2D_2827_DATA);
    return Data;
}

void XNn_model_top_Set_Conv2d_2825_conv2d_2825(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_2825_CONV2D_2825_DATA, Data);
}

u32 XNn_model_top_Get_Conv2d_2825_conv2d_2825(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_2825_CONV2D_2825_DATA);
    return Data;
}

void XNn_model_top_Set_Max_pooling2d_2394_max_pooling2d_2394(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_MAX_POOLING2D_2394_MAX_POOLING2D_2394_DATA, Data);
}

u32 XNn_model_top_Get_Max_pooling2d_2394_max_pooling2d_2394(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_MAX_POOLING2D_2394_MAX_POOLING2D_2394_DATA);
    return Data;
}

void XNn_model_top_Set_Max_pooling2d_2392_max_pooling2d_2392(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_MAX_POOLING2D_2392_MAX_POOLING2D_2392_DATA, Data);
}

u32 XNn_model_top_Get_Max_pooling2d_2392_max_pooling2d_2392(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_MAX_POOLING2D_2392_MAX_POOLING2D_2392_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_2291_dense_2291(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_2291_DENSE_2291_DATA, Data);
}

u32 XNn_model_top_Get_Dense_2291_dense_2291(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_2291_DENSE_2291_DATA);
    return Data;
}

void XNn_model_top_Set_Conv2d_2826_conv2d_2826(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_2826_CONV2D_2826_DATA, Data);
}

u32 XNn_model_top_Get_Conv2d_2826_conv2d_2826(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_2826_CONV2D_2826_DATA);
    return Data;
}

void XNn_model_top_Set_Conv2d_2828_conv2d_2828(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_2828_CONV2D_2828_DATA, Data);
}

u32 XNn_model_top_Get_Conv2d_2828_conv2d_2828(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_2828_CONV2D_2828_DATA);
    return Data;
}

void XNn_model_top_Set_Max_pooling2d_2393_max_pooling2d_2393(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_MAX_POOLING2D_2393_MAX_POOLING2D_2393_DATA, Data);
}

u32 XNn_model_top_Get_Max_pooling2d_2393_max_pooling2d_2393(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_MAX_POOLING2D_2393_MAX_POOLING2D_2393_DATA);
    return Data;
}

void XNn_model_top_Set_Max_pooling2d_2395_max_pooling2d_2395(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_MAX_POOLING2D_2395_MAX_POOLING2D_2395_DATA, Data);
}

u32 XNn_model_top_Get_Max_pooling2d_2395_max_pooling2d_2395(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_MAX_POOLING2D_2395_MAX_POOLING2D_2395_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_2290_dense_2290(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_2290_DENSE_2290_DATA, Data);
}

u32 XNn_model_top_Get_Dense_2290_dense_2290(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_2290_DENSE_2290_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_2292_dense_2292(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_2292_DENSE_2292_DATA, Data);
}

u32 XNn_model_top_Get_Dense_2292_dense_2292(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_2292_DENSE_2292_DATA);
    return Data;
}

void XNn_model_top_Set_Concatenate_498_concatenate_498(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONCATENATE_498_CONCATENATE_498_DATA, Data);
}

u32 XNn_model_top_Get_Concatenate_498_concatenate_498(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONCATENATE_498_CONCATENATE_498_DATA);
    return Data;
}

void XNn_model_top_Set_Conv2d_2829_conv2d_2829(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_2829_CONV2D_2829_DATA, Data);
}

u32 XNn_model_top_Get_Conv2d_2829_conv2d_2829(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_2829_CONV2D_2829_DATA);
    return Data;
}

void XNn_model_top_Set_Conv2d_2831_conv2d_2831(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_2831_CONV2D_2831_DATA, Data);
}

u32 XNn_model_top_Get_Conv2d_2831_conv2d_2831(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_2831_CONV2D_2831_DATA);
    return Data;
}

void XNn_model_top_Set_Max_pooling2d_2396_max_pooling2d_2396(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_MAX_POOLING2D_2396_MAX_POOLING2D_2396_DATA, Data);
}

u32 XNn_model_top_Get_Max_pooling2d_2396_max_pooling2d_2396(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_MAX_POOLING2D_2396_MAX_POOLING2D_2396_DATA);
    return Data;
}

void XNn_model_top_Set_Max_pooling2d_2397_max_pooling2d_2397(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_MAX_POOLING2D_2397_MAX_POOLING2D_2397_DATA, Data);
}

u32 XNn_model_top_Get_Max_pooling2d_2397_max_pooling2d_2397(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_MAX_POOLING2D_2397_MAX_POOLING2D_2397_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_2293_dense_2293(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_2293_DENSE_2293_DATA, Data);
}

u32 XNn_model_top_Get_Dense_2293_dense_2293(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_2293_DENSE_2293_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_2294_dense_2294(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_2294_DENSE_2294_DATA, Data);
}

u32 XNn_model_top_Get_Dense_2294_dense_2294(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_2294_DENSE_2294_DATA);
    return Data;
}

void XNn_model_top_Set_Concatenate_499_concatenate_499(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONCATENATE_499_CONCATENATE_499_DATA, Data);
}

u32 XNn_model_top_Get_Concatenate_499_concatenate_499(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONCATENATE_499_CONCATENATE_499_DATA);
    return Data;
}

void XNn_model_top_Set_Max_pooling2d_2398_max_pooling2d_2398(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_MAX_POOLING2D_2398_MAX_POOLING2D_2398_DATA, Data);
}

u32 XNn_model_top_Get_Max_pooling2d_2398_max_pooling2d_2398(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_MAX_POOLING2D_2398_MAX_POOLING2D_2398_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_2295_dense_2295(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_2295_DENSE_2295_DATA, Data);
}

u32 XNn_model_top_Get_Dense_2295_dense_2295(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_2295_DENSE_2295_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_2296_dense_2296(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_2296_DENSE_2296_DATA, Data);
}

u32 XNn_model_top_Get_Dense_2296_dense_2296(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_2296_DENSE_2296_DATA);
    return Data;
}

void XNn_model_top_Set_Flatten_256_flatten_256(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_FLATTEN_256_FLATTEN_256_DATA, Data);
}

u32 XNn_model_top_Get_Flatten_256_flatten_256(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_FLATTEN_256_FLATTEN_256_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_2297_dense_2297(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_2297_DENSE_2297_DATA, Data);
}

u32 XNn_model_top_Get_Dense_2297_dense_2297(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_2297_DENSE_2297_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_2298_dense_2298(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_2298_DENSE_2298_DATA, Data);
}

u32 XNn_model_top_Get_Dense_2298_dense_2298(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_2298_DENSE_2298_DATA);
    return Data;
}

void XNn_model_top_Set_Conv2d_2827_weight_conv2d_2827_weight(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_2827_WEIGHT_CONV2D_2827_WEIGHT_DATA, Data);
}

u32 XNn_model_top_Get_Conv2d_2827_weight_conv2d_2827_weight(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_2827_WEIGHT_CONV2D_2827_WEIGHT_DATA);
    return Data;
}

void XNn_model_top_Set_Conv2d_2827_bias_conv2d_2827_bias(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_2827_BIAS_CONV2D_2827_BIAS_DATA, Data);
}

u32 XNn_model_top_Get_Conv2d_2827_bias_conv2d_2827_bias(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_2827_BIAS_CONV2D_2827_BIAS_DATA);
    return Data;
}

void XNn_model_top_Set_Conv2d_2825_weight_conv2d_2825_weight(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_2825_WEIGHT_CONV2D_2825_WEIGHT_DATA, Data);
}

u32 XNn_model_top_Get_Conv2d_2825_weight_conv2d_2825_weight(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_2825_WEIGHT_CONV2D_2825_WEIGHT_DATA);
    return Data;
}

void XNn_model_top_Set_Conv2d_2825_bias_conv2d_2825_bias(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_2825_BIAS_CONV2D_2825_BIAS_DATA, Data);
}

u32 XNn_model_top_Get_Conv2d_2825_bias_conv2d_2825_bias(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_2825_BIAS_CONV2D_2825_BIAS_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_2291_weight_dense_2291_weight(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_2291_WEIGHT_DENSE_2291_WEIGHT_DATA, Data);
}

u32 XNn_model_top_Get_Dense_2291_weight_dense_2291_weight(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_2291_WEIGHT_DENSE_2291_WEIGHT_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_2291_bias_dense_2291_bias(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_2291_BIAS_DENSE_2291_BIAS_DATA, Data);
}

u32 XNn_model_top_Get_Dense_2291_bias_dense_2291_bias(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_2291_BIAS_DENSE_2291_BIAS_DATA);
    return Data;
}

void XNn_model_top_Set_Conv2d_2826_weight_conv2d_2826_weight(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_2826_WEIGHT_CONV2D_2826_WEIGHT_DATA, Data);
}

u32 XNn_model_top_Get_Conv2d_2826_weight_conv2d_2826_weight(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_2826_WEIGHT_CONV2D_2826_WEIGHT_DATA);
    return Data;
}

void XNn_model_top_Set_Conv2d_2826_bias_conv2d_2826_bias(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_2826_BIAS_CONV2D_2826_BIAS_DATA, Data);
}

u32 XNn_model_top_Get_Conv2d_2826_bias_conv2d_2826_bias(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_2826_BIAS_CONV2D_2826_BIAS_DATA);
    return Data;
}

void XNn_model_top_Set_Conv2d_2828_weight_conv2d_2828_weight(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_2828_WEIGHT_CONV2D_2828_WEIGHT_DATA, Data);
}

u32 XNn_model_top_Get_Conv2d_2828_weight_conv2d_2828_weight(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_2828_WEIGHT_CONV2D_2828_WEIGHT_DATA);
    return Data;
}

void XNn_model_top_Set_Conv2d_2828_bias_conv2d_2828_bias(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_2828_BIAS_CONV2D_2828_BIAS_DATA, Data);
}

u32 XNn_model_top_Get_Conv2d_2828_bias_conv2d_2828_bias(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_2828_BIAS_CONV2D_2828_BIAS_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_2290_weight_dense_2290_weight(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_2290_WEIGHT_DENSE_2290_WEIGHT_DATA, Data);
}

u32 XNn_model_top_Get_Dense_2290_weight_dense_2290_weight(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_2290_WEIGHT_DENSE_2290_WEIGHT_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_2290_bias_dense_2290_bias(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_2290_BIAS_DENSE_2290_BIAS_DATA, Data);
}

u32 XNn_model_top_Get_Dense_2290_bias_dense_2290_bias(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_2290_BIAS_DENSE_2290_BIAS_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_2292_weight_dense_2292_weight(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_2292_WEIGHT_DENSE_2292_WEIGHT_DATA, Data);
}

u32 XNn_model_top_Get_Dense_2292_weight_dense_2292_weight(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_2292_WEIGHT_DENSE_2292_WEIGHT_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_2292_bias_dense_2292_bias(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_2292_BIAS_DENSE_2292_BIAS_DATA, Data);
}

u32 XNn_model_top_Get_Dense_2292_bias_dense_2292_bias(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_2292_BIAS_DENSE_2292_BIAS_DATA);
    return Data;
}

void XNn_model_top_Set_Conv2d_2829_weight_conv2d_2829_weight(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_2829_WEIGHT_CONV2D_2829_WEIGHT_DATA, Data);
}

u32 XNn_model_top_Get_Conv2d_2829_weight_conv2d_2829_weight(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_2829_WEIGHT_CONV2D_2829_WEIGHT_DATA);
    return Data;
}

void XNn_model_top_Set_Conv2d_2829_bias_conv2d_2829_bias(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_2829_BIAS_CONV2D_2829_BIAS_DATA, Data);
}

u32 XNn_model_top_Get_Conv2d_2829_bias_conv2d_2829_bias(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_2829_BIAS_CONV2D_2829_BIAS_DATA);
    return Data;
}

void XNn_model_top_Set_Conv2d_2831_weight_conv2d_2831_weight(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_2831_WEIGHT_CONV2D_2831_WEIGHT_DATA, Data);
}

u32 XNn_model_top_Get_Conv2d_2831_weight_conv2d_2831_weight(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_2831_WEIGHT_CONV2D_2831_WEIGHT_DATA);
    return Data;
}

void XNn_model_top_Set_Conv2d_2831_bias_conv2d_2831_bias(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_2831_BIAS_CONV2D_2831_BIAS_DATA, Data);
}

u32 XNn_model_top_Get_Conv2d_2831_bias_conv2d_2831_bias(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_2831_BIAS_CONV2D_2831_BIAS_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_2293_weight_dense_2293_weight(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_2293_WEIGHT_DENSE_2293_WEIGHT_DATA, Data);
}

u32 XNn_model_top_Get_Dense_2293_weight_dense_2293_weight(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_2293_WEIGHT_DENSE_2293_WEIGHT_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_2293_bias_dense_2293_bias(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_2293_BIAS_DENSE_2293_BIAS_DATA, Data);
}

u32 XNn_model_top_Get_Dense_2293_bias_dense_2293_bias(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_2293_BIAS_DENSE_2293_BIAS_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_2294_weight_dense_2294_weight(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_2294_WEIGHT_DENSE_2294_WEIGHT_DATA, Data);
}

u32 XNn_model_top_Get_Dense_2294_weight_dense_2294_weight(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_2294_WEIGHT_DENSE_2294_WEIGHT_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_2294_bias_dense_2294_bias(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_2294_BIAS_DENSE_2294_BIAS_DATA, Data);
}

u32 XNn_model_top_Get_Dense_2294_bias_dense_2294_bias(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_2294_BIAS_DENSE_2294_BIAS_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_2295_weight_dense_2295_weight(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_2295_WEIGHT_DENSE_2295_WEIGHT_DATA, Data);
}

u32 XNn_model_top_Get_Dense_2295_weight_dense_2295_weight(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_2295_WEIGHT_DENSE_2295_WEIGHT_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_2295_bias_dense_2295_bias(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_2295_BIAS_DENSE_2295_BIAS_DATA, Data);
}

u32 XNn_model_top_Get_Dense_2295_bias_dense_2295_bias(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_2295_BIAS_DENSE_2295_BIAS_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_2296_weight_dense_2296_weight(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_2296_WEIGHT_DENSE_2296_WEIGHT_DATA, Data);
}

u32 XNn_model_top_Get_Dense_2296_weight_dense_2296_weight(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_2296_WEIGHT_DENSE_2296_WEIGHT_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_2296_bias_dense_2296_bias(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_2296_BIAS_DENSE_2296_BIAS_DATA, Data);
}

u32 XNn_model_top_Get_Dense_2296_bias_dense_2296_bias(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_2296_BIAS_DENSE_2296_BIAS_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_2297_weight_dense_2297_weight(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_2297_WEIGHT_DENSE_2297_WEIGHT_DATA, Data);
}

u32 XNn_model_top_Get_Dense_2297_weight_dense_2297_weight(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_2297_WEIGHT_DENSE_2297_WEIGHT_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_2297_bias_dense_2297_bias(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_2297_BIAS_DENSE_2297_BIAS_DATA, Data);
}

u32 XNn_model_top_Get_Dense_2297_bias_dense_2297_bias(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_2297_BIAS_DENSE_2297_BIAS_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_2298_weight_dense_2298_weight(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_2298_WEIGHT_DENSE_2298_WEIGHT_DATA, Data);
}

u32 XNn_model_top_Get_Dense_2298_weight_dense_2298_weight(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_2298_WEIGHT_DENSE_2298_WEIGHT_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_2298_bias_dense_2298_bias(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_2298_BIAS_DENSE_2298_BIAS_DATA, Data);
}

u32 XNn_model_top_Get_Dense_2298_bias_dense_2298_bias(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_2298_BIAS_DENSE_2298_BIAS_DATA);
    return Data;
}

void XNn_model_top_InterruptGlobalEnable(XNn_model_top *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_GIE, 1);
}

void XNn_model_top_InterruptGlobalDisable(XNn_model_top *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_GIE, 0);
}

void XNn_model_top_InterruptEnable(XNn_model_top *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_IER);
    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_IER, Register | Mask);
}

void XNn_model_top_InterruptDisable(XNn_model_top *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_IER);
    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_IER, Register & (~Mask));
}

void XNn_model_top_InterruptClear(XNn_model_top *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_ISR, Mask);
}

u32 XNn_model_top_InterruptGetEnabled(XNn_model_top *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_IER);
}

u32 XNn_model_top_InterruptGetStatus(XNn_model_top *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_ISR);
}

