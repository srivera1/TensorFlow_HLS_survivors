// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2019.2.1 (64-bit)
// Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef XNN_MODEL_TOP_H
#define XNN_MODEL_TOP_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xnn_model_top_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
#else
typedef struct {
    u16 DeviceId;
    u32 Control_BaseAddress;
} XNn_model_top_Config;
#endif

typedef struct {
    u32 Control_BaseAddress;
    u32 IsReady;
} XNn_model_top;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XNn_model_top_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XNn_model_top_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XNn_model_top_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XNn_model_top_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
int XNn_model_top_Initialize(XNn_model_top *InstancePtr, u16 DeviceId);
XNn_model_top_Config* XNn_model_top_LookupConfig(u16 DeviceId);
int XNn_model_top_CfgInitialize(XNn_model_top *InstancePtr, XNn_model_top_Config *ConfigPtr);
#else
int XNn_model_top_Initialize(XNn_model_top *InstancePtr, const char* InstanceName);
int XNn_model_top_Release(XNn_model_top *InstancePtr);
#endif

void XNn_model_top_Start(XNn_model_top *InstancePtr);
u32 XNn_model_top_IsDone(XNn_model_top *InstancePtr);
u32 XNn_model_top_IsIdle(XNn_model_top *InstancePtr);
u32 XNn_model_top_IsReady(XNn_model_top *InstancePtr);
void XNn_model_top_EnableAutoRestart(XNn_model_top *InstancePtr);
void XNn_model_top_DisableAutoRestart(XNn_model_top *InstancePtr);
u32 XNn_model_top_Get_return(XNn_model_top *InstancePtr);

void XNn_model_top_Set_Input1_input1(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Input1_input1(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Input2_input2(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Input2_input2(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2064_conv2d_2064(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2064_conv2d_2064(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2066_conv2d_2066(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2066_conv2d_2066(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_1642_max_pooling2d_1642(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_1642_max_pooling2d_1642(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_1643_max_pooling2d_1643(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_1643_max_pooling2d_1643(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1533_dense_1533(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1533_dense_1533(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1534_dense_1534(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1534_dense_1534(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2065_conv2d_2065(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2065_conv2d_2065(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2067_conv2d_2067(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2067_conv2d_2067(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Concatenate_159_concatenate_159(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Concatenate_159_concatenate_159(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2068_conv2d_2068(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2068_conv2d_2068(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2069_conv2d_2069(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2069_conv2d_2069(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_1644_max_pooling2d_1644(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_1644_max_pooling2d_1644(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_1645_max_pooling2d_1645(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_1645_max_pooling2d_1645(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Max_pooling2d_1646_max_pooling2d_1646(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Max_pooling2d_1646_max_pooling2d_1646(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Flatten_53_flatten_53(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Flatten_53_flatten_53(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1535_dense_1535(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1535_dense_1535(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1536_dense_1536(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1536_dense_1536(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2064_weight_conv2d_2064_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2064_weight_conv2d_2064_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2064_bias_conv2d_2064_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2064_bias_conv2d_2064_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2066_weight_conv2d_2066_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2066_weight_conv2d_2066_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2066_bias_conv2d_2066_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2066_bias_conv2d_2066_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1533_weight_dense_1533_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1533_weight_dense_1533_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1533_bias_dense_1533_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1533_bias_dense_1533_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1534_weight_dense_1534_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1534_weight_dense_1534_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1534_bias_dense_1534_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1534_bias_dense_1534_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2065_weight_conv2d_2065_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2065_weight_conv2d_2065_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2065_bias_conv2d_2065_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2065_bias_conv2d_2065_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2067_weight_conv2d_2067_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2067_weight_conv2d_2067_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2067_bias_conv2d_2067_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2067_bias_conv2d_2067_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2068_weight_conv2d_2068_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2068_weight_conv2d_2068_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2068_bias_conv2d_2068_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2068_bias_conv2d_2068_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2069_weight_conv2d_2069_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2069_weight_conv2d_2069_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Conv2d_2069_bias_conv2d_2069_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Conv2d_2069_bias_conv2d_2069_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1535_weight_dense_1535_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1535_weight_dense_1535_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1535_bias_dense_1535_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1535_bias_dense_1535_bias(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1536_weight_dense_1536_weight(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1536_weight_dense_1536_weight(XNn_model_top *InstancePtr);
void XNn_model_top_Set_Dense_1536_bias_dense_1536_bias(XNn_model_top *InstancePtr, u32 Data);
u32 XNn_model_top_Get_Dense_1536_bias_dense_1536_bias(XNn_model_top *InstancePtr);

void XNn_model_top_InterruptGlobalEnable(XNn_model_top *InstancePtr);
void XNn_model_top_InterruptGlobalDisable(XNn_model_top *InstancePtr);
void XNn_model_top_InterruptEnable(XNn_model_top *InstancePtr, u32 Mask);
void XNn_model_top_InterruptDisable(XNn_model_top *InstancePtr, u32 Mask);
void XNn_model_top_InterruptClear(XNn_model_top *InstancePtr, u32 Mask);
u32 XNn_model_top_InterruptGetEnabled(XNn_model_top *InstancePtr);
u32 XNn_model_top_InterruptGetStatus(XNn_model_top *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
