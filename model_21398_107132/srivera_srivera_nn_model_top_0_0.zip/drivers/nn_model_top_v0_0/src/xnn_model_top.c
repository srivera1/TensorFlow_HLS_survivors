// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2019.2.1 (64-bit)
// Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
// ==============================================================
/***************************** Include Files *********************************/
#include "xnn_model_top.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XNn_model_top_CfgInitialize(XNn_model_top *InstancePtr, XNn_model_top_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XNn_model_top_Start(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_AP_CTRL) & 0x80;
    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XNn_model_top_IsDone(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XNn_model_top_IsIdle(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XNn_model_top_IsReady(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XNn_model_top_EnableAutoRestart(XNn_model_top *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XNn_model_top_DisableAutoRestart(XNn_model_top *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_AP_CTRL, 0);
}

u32 XNn_model_top_Get_return(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_AP_RETURN);
    return Data;
}
void XNn_model_top_Set_Input1_input1(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_INPUT1_INPUT1_DATA, Data);
}

u32 XNn_model_top_Get_Input1_input1(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_INPUT1_INPUT1_DATA);
    return Data;
}

void XNn_model_top_Set_Input2_input2(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_INPUT2_INPUT2_DATA, Data);
}

u32 XNn_model_top_Get_Input2_input2(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_INPUT2_INPUT2_DATA);
    return Data;
}

void XNn_model_top_Set_Conv2d_2064_conv2d_2064(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_2064_CONV2D_2064_DATA, Data);
}

u32 XNn_model_top_Get_Conv2d_2064_conv2d_2064(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_2064_CONV2D_2064_DATA);
    return Data;
}

void XNn_model_top_Set_Conv2d_2066_conv2d_2066(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_2066_CONV2D_2066_DATA, Data);
}

u32 XNn_model_top_Get_Conv2d_2066_conv2d_2066(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_2066_CONV2D_2066_DATA);
    return Data;
}

void XNn_model_top_Set_Max_pooling2d_1642_max_pooling2d_1642(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_MAX_POOLING2D_1642_MAX_POOLING2D_1642_DATA, Data);
}

u32 XNn_model_top_Get_Max_pooling2d_1642_max_pooling2d_1642(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_MAX_POOLING2D_1642_MAX_POOLING2D_1642_DATA);
    return Data;
}

void XNn_model_top_Set_Max_pooling2d_1643_max_pooling2d_1643(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_MAX_POOLING2D_1643_MAX_POOLING2D_1643_DATA, Data);
}

u32 XNn_model_top_Get_Max_pooling2d_1643_max_pooling2d_1643(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_MAX_POOLING2D_1643_MAX_POOLING2D_1643_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_1533_dense_1533(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_1533_DENSE_1533_DATA, Data);
}

u32 XNn_model_top_Get_Dense_1533_dense_1533(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_1533_DENSE_1533_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_1534_dense_1534(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_1534_DENSE_1534_DATA, Data);
}

u32 XNn_model_top_Get_Dense_1534_dense_1534(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_1534_DENSE_1534_DATA);
    return Data;
}

void XNn_model_top_Set_Conv2d_2065_conv2d_2065(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_2065_CONV2D_2065_DATA, Data);
}

u32 XNn_model_top_Get_Conv2d_2065_conv2d_2065(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_2065_CONV2D_2065_DATA);
    return Data;
}

void XNn_model_top_Set_Conv2d_2067_conv2d_2067(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_2067_CONV2D_2067_DATA, Data);
}

u32 XNn_model_top_Get_Conv2d_2067_conv2d_2067(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_2067_CONV2D_2067_DATA);
    return Data;
}

void XNn_model_top_Set_Concatenate_159_concatenate_159(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONCATENATE_159_CONCATENATE_159_DATA, Data);
}

u32 XNn_model_top_Get_Concatenate_159_concatenate_159(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONCATENATE_159_CONCATENATE_159_DATA);
    return Data;
}

void XNn_model_top_Set_Conv2d_2068_conv2d_2068(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_2068_CONV2D_2068_DATA, Data);
}

u32 XNn_model_top_Get_Conv2d_2068_conv2d_2068(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_2068_CONV2D_2068_DATA);
    return Data;
}

void XNn_model_top_Set_Conv2d_2069_conv2d_2069(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_2069_CONV2D_2069_DATA, Data);
}

u32 XNn_model_top_Get_Conv2d_2069_conv2d_2069(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_2069_CONV2D_2069_DATA);
    return Data;
}

void XNn_model_top_Set_Max_pooling2d_1644_max_pooling2d_1644(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_MAX_POOLING2D_1644_MAX_POOLING2D_1644_DATA, Data);
}

u32 XNn_model_top_Get_Max_pooling2d_1644_max_pooling2d_1644(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_MAX_POOLING2D_1644_MAX_POOLING2D_1644_DATA);
    return Data;
}

void XNn_model_top_Set_Max_pooling2d_1645_max_pooling2d_1645(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_MAX_POOLING2D_1645_MAX_POOLING2D_1645_DATA, Data);
}

u32 XNn_model_top_Get_Max_pooling2d_1645_max_pooling2d_1645(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_MAX_POOLING2D_1645_MAX_POOLING2D_1645_DATA);
    return Data;
}

void XNn_model_top_Set_Max_pooling2d_1646_max_pooling2d_1646(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_MAX_POOLING2D_1646_MAX_POOLING2D_1646_DATA, Data);
}

u32 XNn_model_top_Get_Max_pooling2d_1646_max_pooling2d_1646(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_MAX_POOLING2D_1646_MAX_POOLING2D_1646_DATA);
    return Data;
}

void XNn_model_top_Set_Flatten_53_flatten_53(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_FLATTEN_53_FLATTEN_53_DATA, Data);
}

u32 XNn_model_top_Get_Flatten_53_flatten_53(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_FLATTEN_53_FLATTEN_53_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_1535_dense_1535(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_1535_DENSE_1535_DATA, Data);
}

u32 XNn_model_top_Get_Dense_1535_dense_1535(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_1535_DENSE_1535_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_1536_dense_1536(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_1536_DENSE_1536_DATA, Data);
}

u32 XNn_model_top_Get_Dense_1536_dense_1536(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_1536_DENSE_1536_DATA);
    return Data;
}

void XNn_model_top_Set_Conv2d_2064_weight_conv2d_2064_weight(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_2064_WEIGHT_CONV2D_2064_WEIGHT_DATA, Data);
}

u32 XNn_model_top_Get_Conv2d_2064_weight_conv2d_2064_weight(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_2064_WEIGHT_CONV2D_2064_WEIGHT_DATA);
    return Data;
}

void XNn_model_top_Set_Conv2d_2064_bias_conv2d_2064_bias(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_2064_BIAS_CONV2D_2064_BIAS_DATA, Data);
}

u32 XNn_model_top_Get_Conv2d_2064_bias_conv2d_2064_bias(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_2064_BIAS_CONV2D_2064_BIAS_DATA);
    return Data;
}

void XNn_model_top_Set_Conv2d_2066_weight_conv2d_2066_weight(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_2066_WEIGHT_CONV2D_2066_WEIGHT_DATA, Data);
}

u32 XNn_model_top_Get_Conv2d_2066_weight_conv2d_2066_weight(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_2066_WEIGHT_CONV2D_2066_WEIGHT_DATA);
    return Data;
}

void XNn_model_top_Set_Conv2d_2066_bias_conv2d_2066_bias(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_2066_BIAS_CONV2D_2066_BIAS_DATA, Data);
}

u32 XNn_model_top_Get_Conv2d_2066_bias_conv2d_2066_bias(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_2066_BIAS_CONV2D_2066_BIAS_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_1533_weight_dense_1533_weight(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_1533_WEIGHT_DENSE_1533_WEIGHT_DATA, Data);
}

u32 XNn_model_top_Get_Dense_1533_weight_dense_1533_weight(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_1533_WEIGHT_DENSE_1533_WEIGHT_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_1533_bias_dense_1533_bias(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_1533_BIAS_DENSE_1533_BIAS_DATA, Data);
}

u32 XNn_model_top_Get_Dense_1533_bias_dense_1533_bias(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_1533_BIAS_DENSE_1533_BIAS_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_1534_weight_dense_1534_weight(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_1534_WEIGHT_DENSE_1534_WEIGHT_DATA, Data);
}

u32 XNn_model_top_Get_Dense_1534_weight_dense_1534_weight(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_1534_WEIGHT_DENSE_1534_WEIGHT_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_1534_bias_dense_1534_bias(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_1534_BIAS_DENSE_1534_BIAS_DATA, Data);
}

u32 XNn_model_top_Get_Dense_1534_bias_dense_1534_bias(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_1534_BIAS_DENSE_1534_BIAS_DATA);
    return Data;
}

void XNn_model_top_Set_Conv2d_2065_weight_conv2d_2065_weight(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_2065_WEIGHT_CONV2D_2065_WEIGHT_DATA, Data);
}

u32 XNn_model_top_Get_Conv2d_2065_weight_conv2d_2065_weight(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_2065_WEIGHT_CONV2D_2065_WEIGHT_DATA);
    return Data;
}

void XNn_model_top_Set_Conv2d_2065_bias_conv2d_2065_bias(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_2065_BIAS_CONV2D_2065_BIAS_DATA, Data);
}

u32 XNn_model_top_Get_Conv2d_2065_bias_conv2d_2065_bias(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_2065_BIAS_CONV2D_2065_BIAS_DATA);
    return Data;
}

void XNn_model_top_Set_Conv2d_2067_weight_conv2d_2067_weight(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_2067_WEIGHT_CONV2D_2067_WEIGHT_DATA, Data);
}

u32 XNn_model_top_Get_Conv2d_2067_weight_conv2d_2067_weight(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_2067_WEIGHT_CONV2D_2067_WEIGHT_DATA);
    return Data;
}

void XNn_model_top_Set_Conv2d_2067_bias_conv2d_2067_bias(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_2067_BIAS_CONV2D_2067_BIAS_DATA, Data);
}

u32 XNn_model_top_Get_Conv2d_2067_bias_conv2d_2067_bias(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_2067_BIAS_CONV2D_2067_BIAS_DATA);
    return Data;
}

void XNn_model_top_Set_Conv2d_2068_weight_conv2d_2068_weight(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_2068_WEIGHT_CONV2D_2068_WEIGHT_DATA, Data);
}

u32 XNn_model_top_Get_Conv2d_2068_weight_conv2d_2068_weight(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_2068_WEIGHT_CONV2D_2068_WEIGHT_DATA);
    return Data;
}

void XNn_model_top_Set_Conv2d_2068_bias_conv2d_2068_bias(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_2068_BIAS_CONV2D_2068_BIAS_DATA, Data);
}

u32 XNn_model_top_Get_Conv2d_2068_bias_conv2d_2068_bias(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_2068_BIAS_CONV2D_2068_BIAS_DATA);
    return Data;
}

void XNn_model_top_Set_Conv2d_2069_weight_conv2d_2069_weight(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_2069_WEIGHT_CONV2D_2069_WEIGHT_DATA, Data);
}

u32 XNn_model_top_Get_Conv2d_2069_weight_conv2d_2069_weight(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_2069_WEIGHT_CONV2D_2069_WEIGHT_DATA);
    return Data;
}

void XNn_model_top_Set_Conv2d_2069_bias_conv2d_2069_bias(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_2069_BIAS_CONV2D_2069_BIAS_DATA, Data);
}

u32 XNn_model_top_Get_Conv2d_2069_bias_conv2d_2069_bias(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_CONV2D_2069_BIAS_CONV2D_2069_BIAS_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_1535_weight_dense_1535_weight(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_1535_WEIGHT_DENSE_1535_WEIGHT_DATA, Data);
}

u32 XNn_model_top_Get_Dense_1535_weight_dense_1535_weight(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_1535_WEIGHT_DENSE_1535_WEIGHT_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_1535_bias_dense_1535_bias(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_1535_BIAS_DENSE_1535_BIAS_DATA, Data);
}

u32 XNn_model_top_Get_Dense_1535_bias_dense_1535_bias(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_1535_BIAS_DENSE_1535_BIAS_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_1536_weight_dense_1536_weight(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_1536_WEIGHT_DENSE_1536_WEIGHT_DATA, Data);
}

u32 XNn_model_top_Get_Dense_1536_weight_dense_1536_weight(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_1536_WEIGHT_DENSE_1536_WEIGHT_DATA);
    return Data;
}

void XNn_model_top_Set_Dense_1536_bias_dense_1536_bias(XNn_model_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_1536_BIAS_DENSE_1536_BIAS_DATA, Data);
}

u32 XNn_model_top_Get_Dense_1536_bias_dense_1536_bias(XNn_model_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_DENSE_1536_BIAS_DENSE_1536_BIAS_DATA);
    return Data;
}

void XNn_model_top_InterruptGlobalEnable(XNn_model_top *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_GIE, 1);
}

void XNn_model_top_InterruptGlobalDisable(XNn_model_top *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_GIE, 0);
}

void XNn_model_top_InterruptEnable(XNn_model_top *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_IER);
    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_IER, Register | Mask);
}

void XNn_model_top_InterruptDisable(XNn_model_top *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_IER);
    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_IER, Register & (~Mask));
}

void XNn_model_top_InterruptClear(XNn_model_top *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XNn_model_top_WriteReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_ISR, Mask);
}

u32 XNn_model_top_InterruptGetEnabled(XNn_model_top *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_IER);
}

u32 XNn_model_top_InterruptGetStatus(XNn_model_top *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XNn_model_top_ReadReg(InstancePtr->Control_BaseAddress, XNN_MODEL_TOP_CONTROL_ADDR_ISR);
}

